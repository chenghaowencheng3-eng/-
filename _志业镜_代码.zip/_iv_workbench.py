# -*- coding: utf-8 -*-
"""🎙 志业镜 · 专业访谈工作台

把「和一个读过这个专业的人聊一次」变成**一条能落盘、能进牌堆的数据**。

【为什么要有这个东西】
牌上的七维画像现在只有 94 个专业有，而且是**手写进去的**：
从 2016 年的第一版一路改到现在，一次改一个。
161 张牌里 67 张一个画像都没有，农学那 5 个**全是空的**。
想覆盖 883 个官方专业——**手写是不可能的。**

所以唯一能让覆盖率自己长起来的办法，
是让「加一个专业」这件事**便宜到可以一次次做**：
找一个真读过它的人，问七个问题，落盘，重建。

【它和「反过来问你」不是一回事】
  志业镜问的是**你**：你为了一个东西最长熬了多久 → 得到**你的**七维。
  工作台问的是**这个专业**：它要你背多少 → 得到**这个专业的**七维。
两者都是 1—5，**方向相反**。混起来会得到一堆看着能用、
其实量错对象的数据，而且**它不会报错。**

【怎么用】
    # 看还缺哪些、建议先问谁
    python _iv_workbench.py --status

    # 交互式问一个专业（一条一条来）
    python _iv_workbench.py 农学

    # 从文件录入（一次一批，适合把纸上的记录搬进来）
    python _iv_workbench.py --from-file _访谈草稿.json

    # 校验现有记录，一处坏数据都不放过
    python _iv_workbench.py --validate

【为什么每条都要「依据」】
这和对话版那条守卫是同一个道理：**一个分数背后得有一句真话。**
工作台里填的「依据」是那位受访者说的原话——
没有它，这条记录就退化成「谁觉得是这样」，也就没了比 `dims_tier=C2`
（公开资料整理）更高的价值。**有依据才是 C1。**
"""
import argparse
import io
import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from _mirror_core import (DEMAND_LEVELS,  # noqa: E402
                          check_interview_record,
                          check_demand_answers, demand_questions)

STORE = "_major_interviews.json"
MAJORS = "_majors.json"
TIER_INTERVIEW = "C1"        # 有真人依据 = 访谈核实过
TIER_NO_QUOTE = "C2"         # 数据能看，但没有依据 → 只当公开整理


def _utf8():
    try:
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                                      errors="replace")
    except Exception:                                        # noqa: BLE001
        pass


def load_store():
    if not os.path.exists(STORE):
        return {"records": [], "note": ""}
    with open(STORE, encoding="utf-8") as f:
        d = json.load(f)
    d.setdefault("records", [])
    return d


def save_store(d):
    """原子写：先写临时文件再替换。

    【为什么不直接覆盖】
    这个是**唯一的数据源**。写坏一次就全丢了。
    写到一半断电／抛异常，直接覆盖会让文件和记录一起没了。
    """
    tmp = STORE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=2)
    os.replace(tmp, STORE)


def load_majors():
    with open(MAJORS, encoding="utf-8") as f:
        d = json.load(f)
    return d.get("majors") or []


def validate_record(rec, names):
    """一条记录能不能用。**规则在 _mirror_core 里，这里只是转发。**

    【为什么不在这个文件里自己写一套】
    写 `_major_interviews.json` 的有两个地方：这里和装配器。
    第一版只有这里校验，装配器全盘信任——于是一份被这里拒收、
    但仍然躺在文件里的坏记录，**被装配器直接并进了牌堆**。
    规则必须有且只有一份。
    """
    return check_interview_record(rec, names)


def tier_of(rec):
    """有依据才是访谈核实（C1）；没依据的只能算公开整理（C2）。

    【为什么这一条要卡在代码里，而不是靠人自觉】
    整个牌堆的可信度就建在「C1 是问出来的」上面。
    只要有一条没依据的记录混成 C1，那个标记就再也不可信了。
    """
    ev = [e for e in (rec.get("evidence") or []) if (e or "").strip()]
    return TIER_INTERVIEW if ev else TIER_NO_QUOTE


def coverage(recs=None):
    """现状：谁有画像、谁没有、按门类分布。"""
    M = load_majors()
    recs = recs if recs is not None else load_store()["records"]
    got = {}
    for r in recs:
        got[r["major"]] = r
    have, miss = [], []
    for m in M:
        nm = m.get("_name") or m.get("n")
        (have if m.get("dims") else miss).append(nm)
    by_gate = {}
    for m in M:
        nm = m.get("_name") or m.get("n")
        g = m.get("门类") or "?"
        by_gate.setdefault(g, [0, 0])
        by_gate[g][1] += 1
        if m.get("dims"):
            by_gate[g][0] += 1
    return {"have": have, "miss": miss, "by_gate": by_gate, "records": got}


def cmd_status():
    c = coverage()
    print(f"牌堆 {len(c['have']) + len(c['miss'])} 个专业，"
          f"有七维画像的 {len(c['have'])} 个，"
          f"没有的 {len(c['miss'])} 个")
    print(f"访谈记录 {len(c['records'])} 条")
    print()
    print("按门类（有/总），**空的排前面**：")
    rows = sorted(c["by_gate"].items(), key=lambda kv: (kv[1][0] / kv[1][1],
                                                       -kv[1][1]))
    for g, (a, b) in rows:
        bar = "█" * a + "·" * (b - a)
        flag = "　← 整块空" if a == 0 else ""
        print(f"   {g:<6} {a:>2}/{b:<3} {bar}{flag}")
    print()
    print(f"没有画像的 {len(c['miss'])} 个，前 30 个：")
    for i in range(0, min(30, len(c["miss"])), 6):
        print("   " + "　".join(f"{x:<10}" for x in
                                c["miss"][i:i + 6]))
    print()
    print("建议先问谁：**门类里一个都没有的那些**——一个门类补齐一个，"
          "那个门类才不再是空的。")
    print()
    print("七道题（问专业，不是问人）：")
    for q in demand_questions():
        print(f"   [{q['dimension']}] {q['question']}")
        print("        " + "　".join(f"{lv['score']}={lv['label']}"
                                    for lv in q["levels"]))


def _ask_one(q):
    print()
    print(f"── {q['dimension']} ──")
    print(f"   {q['question']}")
    for lv in q["levels"]:
        print(f"     {lv['score']}  {lv['label']:<4} {lv['means']}")
    print("     ?  说不好／没聊到 → 记「不知道」")
    while True:
        raw = input("   1-5 或 ? ：").strip()
        if raw in ("?", "", "不知道", "说不好", "x", "X"):
            return None
        if raw.isdigit() and 1 <= int(raw) <= 5:
            return int(raw)
        print("   只能填 1-5，或者 ? 表示不知道")


def cmd_interactive(major):
    M = load_majors()
    names = {m.get("_name") or m.get("n") for m in M}
    if major not in names:
        print(f"库里没有「{major}」。")
        # 就在官方目录里的（还没做成牌）也允许录入——
        # **这正是覆盖率长起来的方式**：先把材料收着
        print("（如果它在官方目录里但还没做成牌，本轮还不能录；"
              "先记成一条待办。）")
        return 1
    print(f"志业镜 · 专业访谈工作台　→　{major}")
    print("=" * 66)
    print("下面七题问的是**这个专业的要求**，不是受访者本人。")
    print("每一题都请对方讲**他记得的具体事**——那是依据，比分数重要。")
    who = input("受访者身份（如：临床医学大三／已工作两年）：").strip()
    dims, ev = [], []
    for q in demand_questions():
        v = _ask_one(q)
        dims.append(v)
        if v is not None:
            e = input("   他说了什么让你这么判？（原话，可留空）：").strip()
            ev.append(f"{q['dimension']}：{e}" if e else "")
    note = input("其它要记的（可留空）：").strip()
    rec = {"major": major, "dims": dims,
           "who": who, "on": time.strftime("%Y-%m-%d"),
           "evidence": [e for e in ev if e], "note": note,
           "tier": TIER_INTERVIEW if any(ev) else TIER_NO_QUOTE}
    return _save([rec])


def _save(recs):
    M = load_majors()
    names = {m.get("_name") or m.get("n") for m in M}
    d = load_store()
    have = {r["major"]: r for r in d["records"]}
    n_new = n_bad = 0
    for r in recs:
        errs = validate_record(r, names)
        if errs:
            n_bad += 1
            print(f"  ✗ 「{r.get('major')}」没写进去：")
            for e in errs:
                print(f"       {e}")
            continue
        r["tier"] = tier_of(r)
        if r["major"] in have:
            print(f"  · 「{r['major']}」已有记录，覆盖掉旧的")
            d["records"] = [x for x in d["records"]
                            if x["major"] != r["major"]]
        d["records"].append(r)
        have[r["major"]] = r
        n_new += 1
        print(f"  ✓ 「{r['major']}」记下 {r['dims']}　等级 {r['tier']}"
              f"　依据 {len(r['evidence'])} 条")
    if n_new:
        save_store(d)
        print(f"\n  落盘了 {n_new} 条 → {STORE}")
        print("  下一步：重建牌堆，它才会进到牌里。")
        print("     python _build_major_game.py && python _assemble_majors.py")
    if n_bad:
        print(f"\n  {n_bad} 条没写进去——**坏数据一条也不许进**。")
        return 1
    return 0


def cmd_from_file(path):
    with open(path, encoding="utf-8") as f:
        d = json.load(f)
    recs = d if isinstance(d, list) else (d.get("records") or [])
    print(f"从 {path} 读到 {len(recs)} 条")
    return _save(recs)


def cmd_init():
    """建一个空库。

    【为什么要单独有这个】
    没有记录文件时，工作台会自己造一个默认的——但那是**读的时候**。
    要删掉测试数据、重新开始时，得有个明确的入口，
    而不是让人手写一个 json。
    """
    if os.path.exists(STORE) and load_store()["records"]:
        n = len(load_store()["records"])
        print(f"{STORE} 里已经有 {n} 条记录，**没有动它**。")
        print("  要真的清空，先自己备份再删这个文件。")
        return 1
    save_store({"records": [],
                "note": "志业镜专业访谈记录。每条都要有 who / on / evidence。"
                        "evidence 是受访者的原话——**有依据才是 C1。**"})
    print(f"建好了空库：{STORE}")
    return 0


def cmd_validate():
    M = load_majors()
    names = {m.get("_name") or m.get("n") for m in M}
    d = load_store()
    recs = d["records"]
    print(f"{STORE}：{len(recs)} 条")
    if not recs:
        print("  （还没有记录。跑 `--status` 看该先问谁。）")
        return 0
    bad = 0
    seen = set()
    for r in recs:
        errs = validate_record(r, names)
        if r.get("major") in seen:
            errs.append("同一个专业有多条记录——后写的会盖掉先写的")
        seen.add(r.get("major"))
        t = tier_of(r)
        if r.get("tier") and r["tier"] != t:
            errs.append(f"标的等级是 {r['tier']}，按依据算应该是 {t}")
        if errs:
            bad += 1
            print(f"  ✗ 「{r.get('major')}」")
            for e in errs:
                print(f"       {e}")
    if bad:
        print(f"\n  ✗ {bad} 条不合格")
        return 1
    c = coverage(recs)
    print(f"  ✓ 全部合格。这些专业本来没有画像，"
          f"现在有了 {len([r for r in recs])} 个：")
    for r in recs:
        print(f"     {r['major']:<14} {r['dims']}　{r['tier']}"
              f"　{r.get('who', '')}")
    print()
    print(f"  牌堆里有画像的：{len(c['have'])} 个"
          f"（跑重建之后才会真的生效）")
    return 0


def main():
    _utf8()
    ap = argparse.ArgumentParser(
        description="志业镜 · 专业访谈工作台（问专业，不是问人）")
    ap.add_argument("major", nargs="?", help="要访谈的专业名")
    ap.add_argument("--status", action="store_true",
                    help="看覆盖现状，和该先问谁")
    ap.add_argument("--from-file", metavar="JSON",
                    help="从 json 一次录一批")
    ap.add_argument("--validate", action="store_true",
                    help="校验现有记录")
    ap.add_argument("--init", action="store_true",
                    help="建一个空库（已有记录时不会动它）")
    a = ap.parse_args()
    if a.init:
        return cmd_init()
    if a.status:
        cmd_status()
        return 0
    if a.validate:
        return cmd_validate()
    if a.from_file:
        return cmd_from_file(a.from_file)
    if a.major:
        return cmd_interactive(a.major)
    ap.print_help()
    return 0


if __name__ == "__main__":
    sys.exit(main())
