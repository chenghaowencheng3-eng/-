# -*- coding: utf-8 -*-
"""「它反过来问你」——七维访谈的界面。**对话版和牌局共用这一份。**

【它为什么必须存在】
用户最早定下的产品主张就是这个：**不是你去问它，是它反过来问你。**
翻牌是它问你「要不要」，访谈是它问你「你是什么样」。
合并成一个应用的时候这一块一度丢了——**丢了它就等于丢了产品的一半。**

【它为什么不自己算分】
判分那件事已经有唯一一处：`_tools_core.interview_run()`。
它处理了三件很容易写错的事：
  · 选项里的分是**稀疏的**（认知负荷只有 2/4/5），非法分要拒不采信
  · 给了分就必须给**核得上的引文**，否则记「不知道」
  · 「没试过 / 说不好」是**合法答案**，记「不知道」，绝不记低分
这里再写一遍判分，就等于把这个仓库栽过好几次的错重犯一次。
所以本模块只负责：**把题出出来、把人选的话变成参数、把结果画出来。**

【和牌局那份的区别】
牌局那份（`_majors_src.interview_page`）走的是「自由写一句话 + 语音识别
维度」那条路，还有 nays / 四步走之类的东西，适合大屏演示。
这一份是**给聊天用的**：一题一屏、选项点一下，走完给结果。
两条路的判分是同一个 `interview_run`，所以**数字不会有两套**。
"""


def interview_questions(dim_names, ask, q_of):
    """把七维整理成「问什么、哪几档」。

    `ask` 是 `_mirror_core.ASK`，`q_of` 是 `{题目: 维度}`。
    """
    _q_of_dim = {d: q for q, d in ask}
    out = []
    for d in dim_names:
        out.append({"dimension": d, "question": _q_of_dim.get(d, d)})
    return out


def interview_options_of(dim, options):
    """取某一维的档位。**返回 (分数, 选项原文) 列表，含「不知道」那一档。**

    【为什么连 None 那一档也要列出来】
    它是**合法答案**，而且必须和别的档一样好点。
    把它藏起来，用户就只能被迫在自己的真实状态里挑一个近似的分——
    那就是在替用户判他的能力。
    """
    return [(s, text) for s, text, _reply in options.get(dim) or []]


def interview_label_of(dim, idx, options):
    """取某一维第 idx 档的 (分数, 原文)。"""
    opts = options.get(dim) or []
    if idx < 0 or idx >= len(opts):
        return None, None
    return opts[idx][0], opts[idx][1]


def interview_result_rows(counts, agree_sample, gaps, long_list, dim_names):
    """把访谈结果整理成**好渲染、也好核对**的几行。

    【长名单为什么不列名字】
    实测：94 份画像里 35 份的一致名单 ≥20 个，最多 83 个。
    「对得上 83 个」不可能是结论——**它说明他答的这几项太宽**。
    挑几个名字出来念，是在把一个说不出话的结果装成有内容。
    """
    rows = []
    if long_list:
        rows.append(
            f"**对上了 {counts['对得上']} 个。**"
            f"这个数太大，等于没说——**不是你适合 "
            f"{counts['对得上']} 个，是你答的这几项确实宽。**")
        rows.append("七项你都答了，能定的方向就不在名单里了。"
                    "**去看几张牌，看哪一张你愿意先试一下。**")
        _sp = ", ".join(dim_names)
        rows.append(f"（这七项是：{_sp}。它的粗细我已经量过，"
                    f"最粗的那几维连 1 分和 2 分都没出现过——"
                    f"**这套画像就这个粗细，我不装细。**）")
    elif counts["对得上"]:
        rows.append(f"**你说的每一项它都要得起的：{counts['对得上']} 个。**"
                    f"这几个可以先去翻一翻。")
        if agree_sample:
            rows.append("　".join(f"`{x}`" for x in agree_sample))
    else:
        rows.append("**一个都对不上。**")
        rows.append("这不是你不行的意思——是**这几张牌要的，"
                    "你都说自己受不了**。落差最小的那几个在下面。")
    if gaps:
        rows.append("**落差最小的几个**")
        for g in gaps[:5]:
            _why = "；".join(g.get("why") or []) or "（没有细节）"
            rows.append(f"- **{g.get('major', '')}**　{_why}")
    # 【这四条是产品立场，不是免责声明】
    rows.append("**说清这几件事：**")
    for line in ("这不是「适合你」。它只说明**它要的，你都说你受得了**。",
                 "它问的是承受力，不是兴趣——**受得了不等于愿意干**。",
                 "答案是你自己说的、**没有校准**，只能当一次自我核对。",
                 "**它一个字都没问你家里、成绩、钱。**"):
        rows.append(f"- {line}")
    return rows


def interview_submit(run_tool, ctx, dimension, score, chosen_text):
    """把「用户点了哪一档」交给**唯一那处判分逻辑**。

    【为什么一定要走 run_tool，而不往 ctx["iv"] 里直接塞分】
    判分那件事有三道关：非法分拒收、引文要核得上、「没试过」记不知道。
    这里直接塞分就等于**绕过三道关**——
    而 `_check_chat_longlist.py` 里第一节专门在验「非法分必须被拒」
    （记忆量填 4 会被记成「不知道」）。绕过它，那条闸门就变成假的了。

    返回工具的真实返回值，方便调用方看发生了什么。
    """
    # 【quote 为什么就等于选项原文】
    # 工具要求 quote 是 answer 的子串（`_iv_norm` 之后）。
    # 用户点的那一档，本身就来自界面，是他真选的东西——
    # 所以把「他选的那句话」同时当 answer 和 quote 是最诚实的做法：
    # **不是我替他造了一句引文，是他确实点了这一句。**
    return run_tool("interview", {"dimension": dimension,
                                  "score": score,
                                  "quote": chosen_text,
                                  "answer": chosen_text}, ctx)


def interview_finish(run_tool, ctx):
    """七个都答完之后取结果。**不填参数 = 只要结果。**

    返回工具的原始 dict（里面有 counts / agree_sample / gaps / long_list）。
    """
    return run_tool("interview", {}, ctx)
