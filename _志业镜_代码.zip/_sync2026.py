# -*- coding: utf-8 -*-
"""把库里的官方目录字段对齐到 2026 版（官方源：gaokao.chsi.com.cn/zyk/zybk）。

【为什么必须做这件事】
应用里写着「分类来自教育部《本科专业目录》」。但我库里的分类是旧的一版，
而官方已经更新到 13 个门类 / 93 个专业类 / 883 个专业，**新增了「交叉学科」门类**。
界面写着「来自官方目录」而目录已过期，这比不写更糟。

【对齐结果（真实核对，不是猜的）】
名字命中官方 161/163；门类、专业类、专业代码三项各只有 2 个错：
  · 交叉工程      工学/交叉工程类/083202  →  交叉学科/交叉工程类/140002
  · 智能医学工程  医学/医学技术类/101011  →  交叉学科/交叉工程类/140007
  · 公安学 / 新闻传播学 是「专业类」名，不是专业名 —— 得处理

【为什么不能只改那 2 条了事】
「卡片=专业」是这个产品的单位。把「公安学类」这种专业类名当成一个专业
摆进牌堆里，等于告诉用户「公安学是一个专业」——**它不是**。
官方那个专业类下面有治安学、侦查学…共 25 个专业。

【这一版先只修数据，不动牌堆】
把那两条标成「类别占位」并注明，下一步再决定是删掉还是换成真专业。
一次只改一件事，改完能验。
"""
import json

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
ROOT = os.path.dirname(os.path.abspath(__file__))
TREE = json.load(open(f"{ROOT}/_official_2026_tree.json", encoding="utf-8"))

# 官方索引：专业名 -> (门类, 专业类, 代码)
BY_NAME = {}
CLASS_OF = {}
for _gn, _d in TREE.items():
    for _cn, _cd in _d["classes"].items():
        CLASS_OF[_cn] = (_gn, _cd["key"])
        for _m in _cd["majors"]:
            BY_NAME[_m["name"]] = (_gn, _cn, _m["code"])

N_GATES = len(TREE)
N_CLASSES = sum(len(d["classes"]) for d in TREE.values())
N_MAJORS = len(BY_NAME)
print(f"官方 2026：门类 {N_GATES} · 专业类 {N_CLASSES} · 专业 {N_MAJORS}")

g = json.load(open(f"{ROOT}/_majors.json", encoding="utf-8"))
majors = g["majors"]

fixed = []
classnames = []
for m in majors:
    nm = m.get("_name")
    if nm in BY_NAME:
        og, oc, code = BY_NAME[nm]
        # 官方的专业类名对「交叉学科」返回的是 '-'，那是它们的数据问题。
        # 专业代码是 1400xx，所以正确名是「交叉工程类」。
        if oc == "-":
            oc = "交叉工程类"
        if (m.get("门类"), m.get("专业类"), m.get("code")) != (og, oc, code):
            fixed.append((nm, m.get("门类"), m.get("专业类"), m.get("code"),
                          og, oc, code))
            m["门类"], m["专业类"], m["code"] = og, oc, code
    else:
        classnames.append(nm)

print(f"\n更正的条目 {len(fixed)} 条：")
for nm, a, b, c, og, oc, code in fixed:
    print(f"  {nm:<12} {a}/{b}/{c}  →  {og}/{oc}/{code}")

print(f"\n名字不是专业名的条目 {len(classnames)} 条：")
for nm in classnames:
    # 它是不是一个专业类的名字？
    if nm + "类" in CLASS_OF:
        print(f"  ★ {nm} —— 官方专业类是「{nm}类」，"
              f"里面有 {len(TREE[CLASS_OF[nm + '类'][0]]['classes'][nm + '类']['majors'])} 个专业")
    else:
        print(f"  ? {nm} —— 官方目录里既不是专业，也不是专业类")

# 门类清单也要更新：加「交叉学科」
old_gates = g["gates"]
new_gates = [gn for gn in TREE]
missing = [gn for gn in new_gates if gn not in old_gates]
extra = [gn for gn in old_gates if gn not in new_gates]
print(f"\n门类：原来 {len(old_gates)} 个 → 官方 {len(new_gates)} 个")
print(f"  新增: {missing}    多余: {extra}")

# 官方目录的总数写进数据，界面就能自己算，不再手写
g["gates"] = new_gates
for gn in new_gates:
    g.setdefault("gate_icon", {}).setdefault(gn, "🧩")
    g.setdefault("gate_desc", {}).setdefault(gn, "官方目录新增的门类")
g["catalog_meta"] = {
    "source": "教育部《普通高等学校本科专业目录》",
    "mirror": "学信网阳光高考专业库 gaokao.chsi.com.cn/zyk/zybk",
    "n_gates": N_GATES,
    "n_classes": N_CLASSES,
    "n_majors": N_MAJORS,
    "note": "专业类名以官方为准；官方对「交叉学科」这个专业类返回的名字是 '-'，"
            "按其专业代码 1400xx 与《研究生教育学科专业目录》的用词写作「交叉工程类」",
}

# in_official 按 2026 重算，并区分「真专业」和「只是名字在目录里」
for m in majors:
    m["in_official"] = 1 if m.get("_name") in BY_NAME else 0
    m["is_class_name"] = 1 if m.get("_name") in classnames else 0

print(f"\nin_official 重算后：{sum(m['in_official'] for m in majors)}/{len(majors)}")
print(f"其中所谓「不在官方」的 {sum(1 for m in majors if not m['in_official'])} 条，"
      f"其实是专业类名: {classnames}")

json.dump(g, open(f"{ROOT}/_majors.json", "w", encoding="utf-8"),
          ensure_ascii=False, indent=1)
print("\n已写回 _majors.json")
