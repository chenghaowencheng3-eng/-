# -*- coding: utf-8 -*-
"""🪞 志业镜 · 对话

一个陪你聊「以后学什么」的智能体。不是问卷，不是推荐器。

【它跟前面几版的关系】
  script.py         —— 问卷式，先问一堆再出报告。用户说太慢、不是他要的。
  牌局版            —— 卡片式，挑卡为主。卡片只是形式，仍然不是「陪他聊」。
  本文件            —— **对话为主。牌局是它的另一种玩法。**

【三条设计决定，都跟「诚实」有关】
1. **模型对专业说的每句事实都必须来自工具返回值。**
   176 个专业 + 97 个职业族塞不进 prompt，硬塞它就会记错、会编。
   做成工具之后，「查不到」是一个**能返回的答案**。
2. **后置守卫。** 模型说的话要过一遍检查：出现「建议你选」「不适合你」
   「能力不足」就丢掉这一轮，保留工具结果。这一条从 script.py 的
   polish() 搬过来——原文注释："宁可不要润色，也不能让立场被悄悄改坏。"
3. **没有 API key 时不许假装在聊。** 退回纯规则模式，并且明说。
   一个假装智能的假人比一个诚实的规则机器人更伤人。
"""

import json
import os
import random
import re
import tempfile

import streamlit as st

st.set_page_config(page_title="志业镜 · 对话", page_icon="🪞", layout="centered")

# 【占位符自己带引号，源码里不能再写一对】
# 组装是逐字符 replace：源码写 `"""__THEME__"""` 的话里面含两处占位符，
# CSS 会被塞两遍、中间的引号把字符串切断（牌局那边正是这么炸的）。
st.markdown(__THEME__, unsafe_allow_html=True)

# ==================================================================
# 数据（装配时注入）
# ==================================================================
MAJOR_DATA = json.loads(r"""__MAJOR_DATA__""")
OCC_DATA = json.loads(r"""__OCC_DATA__""")
OCC_INDEX = json.loads(r"""__OCC_INDEX__""")
# 【学职平台登记了、但还没做详情页的职业】
# 这一份是产品的一条承诺：那类名字点不开，但**它是官方登记过的**，
# 而且平台自己写了「N 个专业都能走到这」。
# 不把它传下去，卡片就只能印个干名字——
# 等于把官方信息降级成缺口。
OCC_NODETAIL = json.loads(r"""__OCC_NODETAIL__""")

MAJORS = MAJOR_DATA["majors"]
GATES = MAJOR_DATA["gates"]
GATE_ICON = MAJOR_DATA["gate_icon"]
BY_NAME = {m["n"]: m for m in MAJORS}

# 职业：主名 + 所有别名都能查到（同一个职业族有多种叫法）
OCC_BY_NAME = {}
for _oid, _r in OCC_DATA.items():
    for _nm in set([_r.get("primary"), _r.get("name")]
                   + (_r.get("names") or [])):
        if _nm:
            OCC_BY_NAME[_nm] = _r
# 【名字 → 职业 id】必须从 `OCC_DATA` 自建。
# 我一开始写的是 `OCC_INDEX.get("occ_by_id")`——**那是 id → 记录的字典**
# （键长这样：`r3ulul3d64sl5sk4`），键根本不是名字。
# 牌局那边是自建的，两边结构不一样；照抄过来就当不成别名表。
# 这类「键和值的角色搞反」的错，症状是**静默查不到**，最难查。
OCC_ALIAS = {}
for _oid, _r in OCC_DATA.items():
    for _nm in set([_r.get("primary"), _r.get("name")]
                   + (_r.get("names") or [])):
        if _nm:
            OCC_ALIAS.setdefault(_nm, _oid)
OCC_MAJORS_STAT = {r["primary"]: {"n_majors": r.get("n_majors"),
                                  "also_called": r.get("names")}
                   for r in OCC_DATA.values()}
# 【`NOT_JOBS` 不在这里定义】
# 它是 `_tools_core.py` 里的（那才是正主，共享模块）。
# 我一度在这里又定义了一份，两处内容恰好一样，所以**没有任何症状**——
# 是 `_审计/_check_name_clash.py` 把「同名定义两次」查出来的。
# 一样不代表安全：哪天改了一处，另一处会**静默盖掉**它，
# 而且症状会出现在完全不相干的地方（这个仓库里 `CATALOG` 那笔账就是）。

MODEL = "deepseek-chat"
BASE_URL = "https://api.deepseek.com"

# 【守卫词表】模型绝不能说的话。
# 前六条是「替用户下结论」，后三条是「按现实条件评判人」——
# 后者最阴，因为它听起来像关心。
BANNED = ("建议你选", "你应该选", "建议选择", "最适合你", "不适合你",
          "你不适合", "你能力不足", "你缺乏", "以你的条件")

# ── 事实守卫用的数字白名单 ──
# 【为什么对话版原来没有这一条】
# 牌局有 fact_guard（输出里的每个数字都必须在牌面数据里出现过），
# **对话版没有**——它的 guard 只查措辞，压根没看工具返回。
# 而稿子第 16 页承诺「试着让它说一个错的数字，看会不会被拦下」——
# **那一页演示的是牌局的能力，搬到对话版上会当场翻车。**
#
# 【为什么能补】
# 材料已经在了：stream_llm 每调一次工具就把
# (工具名, 参数, 返回值) 存进 calls。所以「这个数字工具说过吗」
# 是查得到的，不用猜。
_NUM_STOP = {1, 2, 3}          # 太小、太泛的数字不当证据（「三件事」）
# 这些词单独出现不算「在讲事实」，不用核数字。
# 反过来：**句子里出现这些词，就必须每个数字都核得住。**
_FACT_HINT = ("小时", "年", "月", "周", "分", "票", "%", "％", "率",
              "元", "人", "届", "就业", "薪酬", "起薪", "学费", "规模")
# 【中文数字必须认】
# 第一版 `_numbers` 只认 `\d+`。于是「临床医学要读**五**年」大摇大摆
# 走过去——而模型口语里写「五年」比写「5 年」还常见。
# **漏掉中文数字，等于这条守卫只挡了一半。**
_CN_NUM = {"一": 1, "两": 2, "二": 2, "三": 3, "四": 4, "五": 5,
           "六": 6, "七": 7, "八": 8, "九": 9, "十": 10,
           "百": 100, "千": 1000, "万": 10000}


def _numbers(text):
    """把一句话里的数字都抓出来（含小数、百分号、**中文数字**）。

    中文数字只做**逐字**取（「五」→5、「十」→10）。
    「十五」这种会被读成 10 和 5 两个数——不精确，但**方向是对的**：
    守卫只需要判断「这个数工具说过吗」，
    宁可多取几个去核（核不住就拦），也不漏。
    **这里漏一个数，编的数字就过去了。**
    """
    out = set()
    for m in re.finditer(r"\d+(?:\.\d+)?", text or ""):
        try:
            out.add(float(m.group(0)))
        except ValueError:
            pass
    for m in re.finditer(r"[一二两三四五六七八九十百千万]", text or ""):
        out.add(float(_CN_NUM[m.group(0)]))
    return out


def _all_numbers(calls):
    """工具返回里出现过的所有数字——**这是唯一的事实来源。**"""
    got = set()
    for rec in (calls or []):
        blob = rec[2] if len(rec) > 2 else ""
        for m in re.finditer(r"\d+(?:\.\d+)?", str(blob)):
            try:
                got.add(float(m.group(0)))
            except ValueError:
                pass
    return got


def fact_guard(text, calls, seen=None):
    """输出里的数字必须在工具返回里出现过。

    【和牌局的 fact_guard 同一条规矩】
    数字是唯一能被机械核对的东西。话说得再顺，**凭空多出一个
    「每周 60 小时」就是编的**——而用户看不出来。
    所以宁可把这一轮丢掉，也不让一个编出来的数字过去。

    【为什么还要 seen（跨轮累积的数字）】
    第一版只看**这一轮**的 calls。于是用户问完计算机、聊两句再回头问
    「刚才那个自驱几分」，模型复述 5 分——**明明是它自己查过的数，
    守卫却判成编的，把整句话吞掉。**
    误拦比漏拦更常见，而且更难看：用户会觉得它莫名其妙不说话。
    所以把「这一轮查过的」和「前面查过的」并起来。

    【为什么要把维度名整段遮掉】
    「七维」这个词里有个「七」。模型说「计算机的**七维**里自驱要求是 4 分」
    ——**这是一句完全正确的话**，而「七」不在任何工具返回里，
    于是被当成编的数字拦下。
    「七维」「7 维」是这产品的口头禅，会天天撞。
    所以先把维度名（DIM_NAMES / DIM_SHORT 及其中的数字说法）整段换成空格，
    再核剩下的数——**遮的是维度名本身，不是放宽阈值。**
    """
    t = text or ""
    if not any(h in t for h in _FACT_HINT):
        return True, None
    # 遮掉维度名的说法（「七维」「7 维」「七项」「7 项」「七个维度」）
    t = re.sub(r"[七7]\s*[维项个]", " ", t)
    t = re.sub(r"七个维度", " ", t)
    for _n in DIM_NAMES:
        t = t.replace(_n, " ")
    for _n in DIM_SHORT:
        t = t.replace(_n, " ")

    allowed = _all_numbers(calls) | set(seen or ())
    for n in _numbers(t):
        if n in _NUM_STOP:
            continue
        # 数字在返回里出现过（允许 1% 的浮点误差）
        if any(abs(n - a) <= max(0.01, abs(a) * 0.01) for a in allowed):
            continue
        return False, f"它说了一个工具没给过的数字（{n:g}）——这是编的。"
    return True, None



# ==================================================================
# 志业镜的分析核心（内联）
# ==================================================================
__MIRROR_CODE__


# ==================================================================
# 官方专业目录索引（内联，883 个专业）
# ==================================================================
# 用来回答「官方目录里到底有没有这个专业」——
# 和「我库里有没有这张牌」是两件事。
CAT_IDX = json.loads(r"""__CATALOG__""")
CAT_MAJOR = CAT_IDX.get("_major") or {}
CAT_CLASS = CAT_IDX.get("_class") or {}
# 类内同源出口：{专业类: {方向, 同类专业数, 该类有数据的专业数}}
# 门槛（≥75% 且类内 ≥3 个专业）写在装配器里，是算出来的，不是我挑的。
CLS_EXIT = CAT_IDX.get("_cls_exit") or {}


# ==================================================================
# 工具层（内联）
# ==================================================================
__TOOLS_CODE__


# ==================================================================
# 系统提示词（内联）
# ==================================================================
__PROMPT_CODE__


# ==================================================================
# 卡片（**和牌局共用同一份**，由组装注入）
# ==================================================================
__CARDS_CODE__


# ==================================================================
# 访谈（「它反过来问你」——也共用同一份）
# ==================================================================
__INTERVIEW_CODE__


# ==================================================================
# 界面
# ==================================================================
def card_html(m):
    """把专业画成一张卡。**只给第一眼该看的东西。**

    【这一版改成用共享的 `_cards_core.py`，不再各写一份】
    原来的简版卡有两个真问题：
      1. **完全不显示代价**——而「这条路要花多久、好不好回头」
         是用户最想知道的之一；
      2. 完全不提「模板值」——88 个专业的代价数字是按专业类常见情况
         填的，不标出来就是**拿估计冒充准数**。
    这两件事在牌局那边的卡片里是处理过的，但代码写在 `_majors_src.py` 里，
    对话版拿不到。现在两边共用 `_cards_core.py`：
    紧凑视图靠 `summary_data()`，想看全的展开走 `render_card()`。

    【为什么不禁着按「读报告」来写】
    聊天是往下滚的，一张牌铺六个块就把刚才说的话顶出屏幕了。
    用户要的是「就像在和你说话，纸牌是穿插的操作」——**纸牌是穿插的**。
    """
    d = summary_data(m, DIM_NAMES, DIM_PLAIN)
    rows = []
    if d["dims_hi"]:
        rows.append("<div class='mk'><b>它对人的要求</b><br>"
                    + "<br>".join(f"· {plain} <code>{v}/5</code>"
                                  for _n, plain, v in d["dims_hi"])
                    + "".join(f"<br><span class='dim'>· {plain} "
                              f"<code>{v}/5</code></span>"
                              for _n, plain, v in d["dims_lo"])
                    + "</div>")
    else:
        rows.append("<div class='mk dim'>这个专业还没有「需求画像」"
                    "（161 个里 94 个有）</div>")
    # 代价：**模板值必须当场标出来**
    if d["cost"]:
        _tag = ("　<span class='dim'>⚠ 这几个数是模板值，"
                "按这个专业类常见情况填的，不是实测</span>"
                if d["cost_templated"] else
                (f"　<span class='dim'>等级 {_esc(d['cost_tier'])}</span>"
                 if d["cost_tier"] else ""))
        rows.append(f"<div class='mg'><b>要花多少</b><br>{d['cost']}"
                    f"{_tag}</div>")
    return f"""<div class="mcard">
  <div class="mt">{_esc(d['icon'])} {_esc(d['name'])}</div>
  <div class="ms">{_esc(d['gate'])} · {_esc(d['cls'])} · \
{_esc(d['degree'])} · {_esc(d['years'])} 年</div>
  <div class="mh">{_esc(d['hook'])}</div>
  <div class="mg"><b>学什么</b><br>{_esc(d['core']) or '—'}</div>
  {''.join(rows)}
  {f"<div class='mg'><b>谁适合</b><br>{_esc(d['suits'])}</div>" if d['suits'] else ''}
  {f"<div class='ma'>这个下午就能试：{_esc(d['act'])}</div>" if d['act'] else ''}
  {f"<div class='mg'><b>出来能干什么</b><br>" + '　'.join(_esc(x) for x in d['exits']) + "</div>" if d['exits'] else ''}
</div>"""


def sources_block(m):
    """逐条标出处。**这是「数据以官方源为准并逐条标注出处」那句话的落地。**

    【为什么不能只在卡片底下写一句「来源：见侧栏」】
    一张卡上的信息来自**四个不同来源，可信度差得很远**：
      · 分类/代码/学位  → 教育部官方目录（硬事实）
      · 就业方向        → 学职平台官方登记（政府平台）
      · 四维满意度      → 学信网实名投票（**学生自评，方向性**）
      · 三维星级/推荐指数 → 两位老师的材料（**个人判断，不是数据**）
      · 需求画像 7 维   → 6 个访谈核实 / 88 个公开资料推
      · 代价数字        → 88 个是模板值
    混成一句「来源：多个渠道」就等于没说。所以逐条摊开。

    【另一个刻意的设计】
    「教育部目录覆盖」那一行不是写死的清单，是**从数据算的**：
    用 class2gate（专业类码→门类）反查我这 163 个专业属于哪些**官方在册**
    的专业类。这样以后加专业它会自己更新，不会变成一张过期的表。
    """
    g = MAJOR_DATA
    c2g = g.get("class2gate") or {}
    off_classes = g.get("official_classes") or {}
    cl = m.get("专业类") or ""
    cls_code = next((c for c, n in off_classes.items() if n == cl), None)
    gate_ok = bool(cls_code and c2g.get(cls_code))
    sat = m.get("chsi_sat") or {}
    rows = []

    if gate_ok:
        rows.append(("分类·代码·学位", "官方", "教育部《本科专业目录》"
                     f"（{m.get('门类')} · {m.get('专业类')}"
                     + (f" · {m['code']}" if m.get("code") else "") + "）"))
    else:
        rows.append(("分类", "待核", "不在官方目录里对得上，"
                     "这一项我没核实"))

    if m.get("chsi_jyfx"):
        rows.append(("就业方向", "官方", "学职平台 xz.chsi.com.cn"
                     "（教育部学生服务与素质发展中心）"))
    if sat:
        n = sat.get("total") or 0
        soft = "票少，仅供参考" if n < 300 else ""
        rows.append(("四维满意度", "官方·学生自评",
                     "学信网阳光高考专业库，在读学生实名投票"
                     f"（{n:,} 票{('，' + soft) if soft else ''}）"))
    if m.get("chsi_xsgm"):
        rows.append(("在校生规模", "官方", "同上"))
    if m.get("rating"):
        rows.append(("三维星级", "个人判断",
                     (m["rating"].get("src") or "") + "（**不是数据**）"))
    if m.get("rec_index"):
        rows.append(("推荐指数", "个人判断",
                     (m["rec_index"].get("src") or "") + "（**不是数据**）"))
    if m.get("dims"):
        t = m.get("dims_tier")
        rows.append(("7 维需求画像",
                     "访谈核实" if t == "C1" else "公开资料推",
                     "志业镜原库" + ("（逐个访谈核实过）" if t == "C1"
                                 else "（**没有逐一核实**）")))
    if m.get("cost_hours"):
        rows.append(("代价数字",
                     "模板值" if m.get("cost_templated") else "访谈核实",
                     "**同批数挤在同一个值上，别当准数**"
                     if m.get("cost_templated") else "逐个访谈核实"))
    rows.append(("学什么 / 代价 / 谁适合", "整理",
                 m.get("src") or "公开资料整理"))

    if not rows:
        return
    st.markdown("**这一张卡，每条信息哪来的**")
    for what, kind, src in rows:
        st.markdown(f"- `{what}`　**{kind}**　—— {src}")


def render_assistant(text, shown=()):
    """把模型的话画出来，遇到 [[CARD:x]] 就插一张卡。

    【为什么要这个标记】
    卡片是「它拿给你看的东西」，得由它决定插在哪一句话后面。
    所以让它自己写 `[[CARD:专业名]]`，我按这个切开渲染。
    没有这个标记它就只能干说，那又变回聊天机器人了。
    """
    import re
    parts = re.split(r"\[\[CARD:\s*([^\]]+?)\s*\]\]", text)
    for i, part in enumerate(parts):
        if i % 2 == 0:
            if part.strip():
                st.markdown(part.strip())
        else:
            m = BY_NAME.get(part)
            if m:
                st.markdown(card_html(m), unsafe_allow_html=True)
                # 【牌局那一整套现在都在这里，但收着】
                # 聊天流里塞六个块会把刚才说的话顶出屏幕，所以要紧凑版；
                # 可牌局那边「逐条标出处」「出口分官方/整理」这些
                # **不是装饰，是产品承诺**（数据以官方源为准并逐条标注出处）。
                # 所以给一个展开：想查的人一眼能找到，不想看的人不被打断。
                with st.expander("看全一点（代价、出口、每一句的出处）"):
                    render_card(st, m, DIM_NAMES, DIM_PLAIN,
                                occ_by_name=OCC_BY_NAME,
                                occ_alias=OCC_ALIAS,
                                not_jobs=NOT_JOBS,
                                occ_nodetail=OCC_NODETAIL,
                                sources=sources_block(m))
            else:
                # 模型编了一个不存在的专业名 —— 不画卡，如实说
                st.warning(f"它想给你看「{part}」，但库里没有这个专业。"
                           f"（这种时候不要信它的描述。）")


def _client(key):
    """建 OpenAI 客户端（DeepSeek 兼容 OpenAI 协议）。

    不带 key 就返回 None —— **调用方必须自己处理 None，不许假装能聊。**
    """
    if not key:
        return None
    try:
        from openai import OpenAI
    except ImportError:
        return None
    return OpenAI(api_key=key, base_url=BASE_URL)


def stream_llm(client, messages, ctx, max_rounds=6):
    """跑一轮对话，允许模型来回调工具。

    返回 (最终文本, 本轮工具调用轨迹, 出错信息)
    """
    calls = []
    msgs = list(messages)
    for _ in range(max_rounds):
        try:
            resp = client.chat.completions.create(
                model=MODEL, messages=msgs,
                tools=tool_specs(), tool_choice="auto",
                temperature=0.8, max_tokens=1200)
        except Exception as e:
            return None, calls, f"{type(e).__name__}: {e}"
        msg = resp.choices[0].message
        if not getattr(msg, "tool_calls", None):
            return (msg.content or ""), calls, None
        msgs.append({"role": "assistant",
                     "content": msg.content or "",
                     "tool_calls": [tc.model_dump() for tc in msg.tool_calls]})
        for tc in msg.tool_calls:
            try:
                args = json.loads(tc.function.arguments or "{}")
            except Exception:
                args = {}
            out = run_tool(tc.function.name, args, ctx)
            calls.append((tc.function.name, args,
                          str(out)[:160]))
            # 【把这一轮看到的数字累进 ctx】
            # fact_guard 只看「这一轮查过的」会把**上一轮真查过的数**
            # 判成编的（用户回头问「刚才那个几分」就会撞上），
            # 整句话被吞掉。所以这里跨轮累积。
            ctx.setdefault("seen_nums", set()).update(
                _numbers(json.dumps(out, ensure_ascii=False, default=str)))
            msgs.append({"role": "tool", "tool_call_id": tc.id,
                         "content": json.dumps(out, ensure_ascii=False,
                                               default=str)[:12000]})
    return None, calls, "它连着调了太多工具，我把它叫停了。"


def guard(text, calls, seen=None):
    """后置守卫：模型违反产品底线就丢掉这一轮。

    从 script.py 的 polish() 搬过来。原文注释：
    「宁可不要润色，也不能让立场被悄悄改坏。」

    【两道关，顺序有讲究】
      ① 措辞关（BANNED）——「建议你选」这种，**先查**，
         因为它一眼就能判，不用看工具返回。
      ② 事实关（fact_guard）——数字必须来自工具返回。
         这道关以前**只在牌局里有**，对话版漏了；
         而稿子上承诺的现场演示正好是这一条。
    """
    bad = [w for w in BANNED if w in (text or "")]
    if bad:
        # 【这是内部诊断串，不会印给用户】
        # `why` 在调用处只当布尔用（`if why:`），一个字都不上屏。
        # 但措辞照样收干净：留着一句「这是替你做决定，越线了」，
        # 下一个人很容易顺手把它 st.warning 出去——
        # 而用户明确说过「不需要你管做不做决定」。
        return None, f"措辞关拦下：{'、'.join(bad)}"
    ok, why = fact_guard(text, calls, seen)
    if not ok:
        return None, why
    return text, None


# ==================================================================
# 撞到「不替你选」那道墙的时候，**同一秒把内容补上**
# ==================================================================
# 【为什么要有这一段】
# 用户原话：「那个所谓的不帮你做选择的越界问题很容易，使聊天变死，
# 我希望你能在避免引导做决定的同时，**积极开拓出新的内容**」。
#
# 改之前，撞墙的处理是印一句
# 「这句我不替你说……要不要我陪你把这两条路摆开看看？」
# ——它是客气话，但**球被丢回给用户了**：他没得到任何东西，
# 还得自己想问什么。这就是「聊天变死」的机制。
#
# 现在改成：拦掉那一句的同时，把**同一批事实换个角度**端上去。
# 换的角度全是中性的——摊开、不评判、不排序，所以
# 「不替他做决定」这条线一点没松。
#
# 【为什么角度是抽签而不是固定】
# 固定同一套角度，多撞几次墙就变成新的复读机——
# 而用户抱怨的正是重复。
#
# 【这些数字从哪来】
# 全部来自 `summary_data()` / `card_data()`，也就是**牌上本来就印着**的
# 那几个数（要花多少、它要什么、学什么）。这里不新增任何事实，
# 所以不需要再过一遍事实关。

_ANGLE_TAIL = [
    "**换个角度**：这两条里，**哪一条你已经知道是自己不要的？**"
    "——「不要什么」比「要什么」准得多。",
    "**再往下一层**：去打听一下**真在干这行的人，一整天在干什么**。"
    "专业介绍里那套和实际干活差得远。",
    "**反过来看**：这条路**容不容易回头**？"
    "想换的时候换不动，比选错更麻烦。",
    "**不用等毕业就能试的**：挑一个你这周就能做的小东西做完。"
    "做完你会知道一件真的，比现在想十天都有用。",
]
# 【撞墙计数器】见 `_angle_shift()` 里的说明：
# 不能用 session_state 当种子，刷新后它就归零了。
_WALL_N = 0


def _angle_shift(text):
    """从被拦掉的那句话里挖出「它想推荐谁」，换成中性内容端上去。

    返回 markdown 文本；**挖不出东西就返回 None**，
    让调用方退回到不会撒谎的说法。
    """
    # ① 它想推荐哪个专业
    try:
        hits = [m for nm, m in BY_NAME.items() if nm in (text or "")]
    except NameError:
        hits = []
    # 长名字排在前面，免得「计算机」把「计算机科学与技术」盖掉
    hits.sort(key=lambda m: -len(m.get("n") or ""))
    seen, uniq = set(), []
    for m in hits:
        if m["n"] not in seen:
            seen.add(m["n"])
            uniq.append(m)
    if not uniq:
        return None

    out = ["先把东西放这儿："]
    try:
        for m in uniq[:2]:
            d = summary_data(m, DIM_NAMES, DIM_PLAIN)
            bits = []
            if d["dims_hi"]:
                bits.append("、".join(f"{p} {v}/5"
                                      for _n, p, v in d["dims_hi"]))
            if d["cost"]:
                # 【模板值必须标出来】不标就是拿估计冒充准数
                bits.append(d["cost"].replace("**", "")
                            + ("（模板值，不是实测）"
                               if d["cost_templated"] else ""))
            if d["core"]:
                bits.append(d["core"].replace("**", ""))
            if bits:
                out.append(f"- **{m['n']}**　" + "；".join(bits))
            # 【牌不插进聊天流】卡片是穿插的操作，一次一张，
            # 这里是「撞墙之后的补料」，塞卡会喧宾夺主。
            # 所以只给事实，不提卡片。
    except NameError:
        return None
    # 【角度为什么要轮着换，以及为什么不能用 session_state 当种子】
    # 固定同一句，多撞几次墙就变成新的复读机——
    # 而用户抱怨的正是重复。
    # 我第一版拿 `len(st.session_state.msgs)` 当种子。
    # **那是错的**：那段在 streamlit 里只有**每一次 rerun 都取到同一个值**
    # 才会动，而刷新之后它就是 0——等于永远第一句。
    # 所以改成一个**模块级计数器**：它活在服务进程里，
    # 每撞一次墙就往前走一格，跟会话状态没关系。
    global _WALL_N
    _WALL_N += 1
    out.append(_ANGLE_TAIL[_WALL_N % len(_ANGLE_TAIL)])
    return "\n\n".join(out)


# ==================================================================
# 会话状态
# ==================================================================
def new_ctx():
    return {"majors": MAJORS, "by_name": BY_NAME,
            "occ_by_name": OCC_BY_NAME, "occ_majors_stat": OCC_MAJORS_STAT,
            # 出处核对需要官方目录对照表，**显式传进去**，
            # 免得 tools 层靠全局变量拿到一个它不该依赖的东西
            "major_data": MAJOR_DATA,
            "self_notes": [], "reality_notes": [], "impressions": [],
            "shown": [], "trace": []}


def mirror_fn_factory(ctx):
    def f():
        col = [BY_NAME[x] for x in ctx.get("collected", []) if x in BY_NAME]
        rej = [(BY_NAME[x], rs) for x, rs in ctx.get("rejected", [])
               if x in BY_NAME]
        return read_mirror(col, rej)
    return f


if "ctx" not in st.session_state:
    st.session_state.ctx = new_ctx()
if "msgs" not in st.session_state:
    st.session_state.msgs = []
if "opening_done" not in st.session_state:
    st.session_state.opening_done = False
ctx = st.session_state.ctx
ctx["mirror_fn"] = mirror_fn_factory(ctx)
ctx.setdefault("collected", [])
ctx.setdefault("rejected", [])

# ==================================================================
# 侧栏 —— **要短。用户说过侧栏啰嗦，而且不要旁白。**
# ==================================================================
with st.sidebar:
    st.markdown("## 🪞 志业镜 · 对话")
    # 【这行原来写的是「我不替你挑，也不给你打分」——已删】
    # 那道线在代码里守着就够了；挂在嘴上就成了旁白。
    st.caption("陪你聊「以后学什么」。")

    # 【密钥从哪儿读：三种来源，按云上能不能用排序】
    # ① `st.secrets` —— **Streamlit 云上唯一可行的方式**。
    #    云上的容器不给你设环境变量，但 Secrets 面板里的值会进这里。
    #    以前只读 `os.environ`，所以传到云上就是「没填 key」，
    #    整个应用退化成规则模式——**看起来像没配好，其实是读错了地方。**
    # ② 环境变量 —— 本机跑、或者自建服务器（Docker/Zeabur 之类）走这条。
    # ③ 让用户自己填 —— 兜底。访问者自己贴一个 key，只活在这次会话里。
    #
    # 【访问 st.secrets 必须包 try】
    # 没有 secrets 文件时它会**抛异常**（不是返回空），
    # 而本机跑通常就是没有 secrets 文件的。
    key = ""
    try:
        key = st.secrets.get("DEEPSEEK_API_KEY", "") or ""
    except Exception:                       # noqa: BLE001
        key = ""
    if not key:
        key = os.environ.get("DEEPSEEK_API_KEY", "")
    if not key:
        key = st.text_input("DeepSeek API Key", type="password",
                            placeholder="sk-...")

    _n_c = len(ctx.get("collected", []))
    _n_r = len(ctx.get("rejected", []))
    if _n_c or _n_r:
        st.caption(f"收下 {_n_c} · 排除 {_n_r}")

    st.markdown("---")
    if st.button("🔄 重新开始", width="stretch"):
        st.session_state.ctx = new_ctx()
        st.session_state.msgs = []
        st.session_state.opening_done = False
        st.session_state.pop("iv_ui", None)
        st.rerun()

    # 【入口放在侧栏，和「重新开始」同一层】
    # 用户原话：「选择卡片只是形式之一」——翻牌是它问你「要不要」，
    # 访谈是它问你「你是什么样」。这两件事**没有先后**，
    # 所以入口不该藏在流程深处。
    if st.button("🎙 换我问你几个问题", width="stretch", key="iv_enter"):
        st.session_state.iv_ui = {"i": 0, "ans": {}}
        st.rerun()

    # 底细收进折叠里 —— 该说的都说了，但不占版面
    with st.expander("我手上有什么、没有什么"):
        _off = sum(1 for m in MAJORS if m.get("in_official"))
        _sat = sum(1 for m in MAJORS if m.get("chsi_sat"))
        _jy = sum(1 for m in MAJORS if m.get("chsi_jyfx"))
        _dim = sum(1 for m in MAJORS if m.get("dims"))
        _dim_c1 = sum(1 for m in MAJORS if m.get("dims_tier") == "C1")
        _r1 = sum(1 for m in MAJORS if m.get("rating"))
        _r2 = sum(1 for m in MAJORS if m.get("rec_index"))
        _tpl = sum(1 for m in MAJORS if m.get("cost_templated"))
        _cost = sum(1 for m in MAJORS if m.get("cost_hours"))
        _xs = sum(1 for m in MAJORS if m.get("chsi_xsgm"))
        # 【原来这九条是把每张卡下面那份「来源与底细」又抄了一遍】
        # 现在这里只说**库的整体家底**（每条有多少个专业有），
        # 逐条出处由卡下面的那份负责。两边不再互相重复。
        st.markdown(
            f"- 牌堆 `{len(MAJORS)}` / 官方目录 `883` 个专业；"
            f"`分类·代码·学位` **{_off}** 全部对得上（教育部《本科专业目录》）\n"
            f"- `就业方向` **{_jy}**（学职平台）· "
            f"`在校生规模` **{_xs}**、`四维满意度` **{_sat}**（学信网，"
            f"**学生自评，不是就业率**）\n"
            f"- `7 维需求画像` **{_dim}**（**{_dim_c1}** 条有引文）· "
            f"`代价数字` **{_cost}**（**{_tpl}** 条是模板值）\n"
            f"- `三维星级` **{_r1}** / `推荐指数` **{_r2}** —— "
            f"**两位老师各自的判断，不是数据**")
        st.caption("我没有的东西也一并说清楚：**选科要求**（权威源在各省"
                   "考试院）、**薪资数字**（平台上那个「薪酬」是在读学生"
                   "打的分，不是钱）。有牌的专业，卡下面都逐条写着它是"
                   "从哪儿来的。")

# ==================================================================
# 「它反过来问你」——访谈占主区，走完回聊天
# ==================================================================
def interview_ui():
    """七个问题的界面。**判分一律走 `interview_run`，这里不自己算。**

    返回 True 表示这一轮访谈接管了主区。
    """
    iv = st.session_state.get("iv_ui")
    if not iv:
        return False
    QS = interview_questions(DIM_NAMES, ASK, Q_OF)
    st.markdown("### 🎙 换我问你")
    st.caption("七个问题，问的都是**你实际干过什么**——不是让你给自己打分。"
               "**「没试过」也是答案**，点它就完了。")

    done = iv["i"] >= len(QS)
    if not done:
        q = QS[iv["i"]]
        _opts = interview_options_of(q["dimension"], OPTIONS)
        st.markdown(f"**{iv['i'] + 1}/{len(QS)}　{q['question']}**")
        _labels = [t for _s, t in _opts]
        _pick = st.radio("选一个最像你的", _labels, index=None,
                         key=f"iv_pick_{iv['i']}",
                         label_visibility="collapsed")
        _back = st.button("← 先不答了", key="iv_quit")
        if _back:
            st.session_state.pop("iv_ui", None)
            st.rerun()
        if _pick is not None:
            _score, _ = interview_label_of(q["dimension"],
                                           _labels.index(_pick), OPTIONS)
            # 【答案走 interview_run，不自己往 ans 里塞】
            # 它负责三件事：非法分不采信、引文要核得上、
            # 「没试过」记「不知道」而不是低分。自己判分就会重犯那些错。
            interview_submit(run_tool, ctx, q["dimension"], _score, _pick)
            iv["ans"][q["dimension"]] = _score
            iv["i"] += 1
            st.rerun()
        return True

    # ── 走完了：出结果 ──
    _r = interview_finish(run_tool, ctx)
    st.markdown("### 答完了，对一遍")
    for line in interview_result_rows(
            _r["counts"], _r["agree_sample"], _r["gaps"],
            _r["long_list"], DIM_NAMES):
        render_assistant(line)
    if st.button("聊点别的", key="iv_done"):
        st.session_state.pop("iv_ui", None)
        st.rerun()
    return True


if not interview_ui():
    # ==================================================================
    # 对话区
    # ==================================================================
    st.markdown("### 🪞 志业镜 · 对话")

    if not st.session_state.opening_done:
        st.session_state.opening_done = True
        # 【开场白为什么要有好几条，而且每次都换】
        # 原来只有写死的一句：「最近有什么事，是你自己愿意多花点时间的？」
        # 用户的反馈是「每次一开始就是有什么愿意多花时间的，烦不烦啊，
        # 能不能更个性化一点」。
        #
        # 那句话有两个毛病：
        #   ① **它在逼人表态。** 让人先定义自己「愿意为什么花时间」——
        #      很多人答不上来，答不上来不是他的问题。
        #   ② **它把门关窄了。** 它假定来的人已经准备好聊兴趣了。
        #      可来的人可能正担心成绩、怕选错、家里有压力，
        #      或者只是想说说话。这些人看到那句话就退了。
        #
        # 所以改成几条**跨开的路**：有的给事、有的给话、有的根本不问。
        # `st.session_state.greeted_before` 记着上次用的哪条——
        # **同一个人下次进来不会看到同一句。**
        _OPENERS = [
            # ① 【把「我能给你什么」摆出来，让他按自己的需要问】
            # 用户的原话：「比如你说『我有什么能帮到您』，根据用户需要回答」。
            #
            # 【为什么这条放第一位】
            # 它不逼人表态——**它先把自己的能力交出去**，
            # 让用户从自己的需要出发挑。
            # 前面几条（问他在忙什么、问他上周三干嘛）虽然宽松，
            # 但**都是在要他先给东西**；这一条不是。
            #
            # 【但不能写成客服腔】
            # 「我有什么能帮到您」是客服话，念出来像电话客服。
            # 所以把它落成**具体的清单**——说得出我到底能干什么，
            # 而不是空问一句「需要什么帮助」。
            # 清单一具体，用户才知道可以问什么。
            "我先说我这儿有什么，你挑着来。\n\n"
            "我能干这些：\n"
            "- **你说个专业名**，我给你翻张牌——它要什么、累在哪、"
            "毕业往哪走\n"
            "- **你想比比两个**，我把它们放一起对\n"
            "- **你心里有个方向但说不清**，那就聊，聊到能说清为止\n"
            "- **你单纯想找人说说话**，那也行，不聊专业也不冷场\n\n"
            "**你想从哪儿开始？**",

            # ② 不问，只把门开着
            "来了。\n\n"
            "这儿不用先想清楚——**说件具体的事就行**：最近在忙什么、"
            "烦什么、在玩什么。\n\n"
            "你要只是想吐槽两句，也接得住。",

            # ② 给一个「最小的事实」，比问「你喜欢什么」好答得多
            "不用自我介绍，也不用想明白才来。\n\n"
            "先从最小的事说起：**上周三下午你在干嘛？**\n\n"
            "上课、打球、打游戏、睡觉、剪视频——"
            "**你说什么我都不觉得这有什么。**",

            # ③ 承认「不知道」是好答案
            "你先说，或者先别说，都行。\n\n"
            "要是你现在的状态是**「我也不知道我想干嘛」**——"
            "那正好，这话我听得最多，**而且它是好答案**，不是坏答案。\n\n"
            "那换个问法：**你最近一次忘了看时间，是在干嘛？**",

            # ④ 迟到的，有的直接看牌
            "你要是已经有个大概方向——说个词就行，我给你翻张牌看看。\n\n"
            "没有也没关系。**那就从你最近在忙的事说起。**",

            # ⑤ 直接给个能立刻动手的小事
            "不聊大道理，先做件小事也行。\n\n"
            "**拿张纸，写三件你今年做过、当时还挺投入的事。**"
            "写完念给我听，或者直接说。\n\n"
            "不用挑「有意义」的——**越琐碎越好，琐碎的才真。**",
        ]

        _n = len(_OPENERS)

        # 【换一条，不重样——而且这个「不重样」必须跨刷新也成立】
        # 第一版我把「上次用的第几条」存在 `session_state` 里。
        # 那是错的：**浏览器每刷新一次就是一个新会话**，
        # `session_state` 每次都是空的，于是永远停在第 1 条——
        # 「每次换一条」等于没做。
        # 所以改成本地留一个记号文件。
        #
        # 【它是什么，不是什么】
        # 它**不是账号系统**，不记你说过什么，也没有任何身份信息——
        # 只存一个整数：「上次给他看的是第几条开场」。
        # 所以这个文件只有一个数字，读不出来也完全不影响使用。
        # 【为什么不用随机数】随机会重复，而「每次都是这句」
        # 正是用户提的那个问题本身——随机解决不了它。
        # 【为什么不用 `__file__`】
        # 组装出来的应用是被 exec 进一个命名空间跑的，
        # 那时候 `__file__` 可能不存在——`os.path.abspath(__file__)`
        # 会当场 NameError（实测报的就是 `name '__file__' is not defined`）。
        #
        # 【为什么也不能用 `os.getcwd()`】
        # 原来这里写的是 `os.path.join(os.getcwd(), "_开场记号.txt")`。
        # 在我的机器上没问题；**在 Streamlit 云上会炸**——
        # 云上的仓库目录是**只读**的，那句话会 OSError。
        # （外面虽然有个 `except OSError: pass` 兜着不会崩，
        #  但记号永远写不进去，开场白就退化成一条不换的——
        #  **而那正是用户最开始抱怨的那个毛病**。
        #  所以这不是「不崩就行」，这是功能真的没了。）
        #
        # 【改法：找一个真能写的目录】
        # 从临时目录往下试，**真的写一个探针文件**才算数——
        # 不能只看目录存不存在（云上目录存在但不可写）。
        # 都写不进去就**当场随机挑一条**：换着来这个效果还在，
        # 只是下一次不一定跟这一次不同。**宁可随机，也不要每次都第一句。**
        def _writable_dir():
            _cands = [os.path.join(tempfile.gettempdir(), "zhiyejing"),
                      tempfile.gettempdir(), os.getcwd()]
            for _d in _cands:
                try:
                    os.makedirs(_d, exist_ok=True)
                    _probe = os.path.join(_d, ".probe")
                    with open(_probe, "w", encoding="ascii") as _f:
                        _f.write("1")
                    os.remove(_probe)
                    return _d
                except OSError:
                    continue
            return None

        _dir = _writable_dir()
        if _dir is None:
            _i = random.randrange(_n)
            _last = None
        else:
            _MARK = os.path.join(_dir, "_开场记号.txt")
            try:
                with open(_MARK, encoding="ascii") as f:
                    _last = int(f.read().strip())
            except (OSError, ValueError):
                _last = None
            _i = 0 if _last is None else (_last + 1) % _n
            try:
                with open(_MARK, "w", encoding="ascii") as f:
                    f.write(str(_i))
            except OSError:
                pass
        # 回来过的人要说一句，不然「重新开始」看起来像程序重启
        _back = st.session_state.get("greeted_before")
        st.session_state.greeted_before = True
        _head = ("又来了。\n\n" if _back else "")
        st.session_state.msgs.append(
            {"role": "assistant", "text": _head + _OPENERS[_i]})

    for m in st.session_state.msgs:
        with st.chat_message("assistant" if m["role"] == "assistant"
                             else "user"):
            if m["role"] == "assistant":
                render_assistant(m["text"])
            else:
                st.markdown(m["text"])

# ---- 输入 ----
# 【公开部署要有个费用上限】
# 本机跑、自己填 key，随便聊多少轮都无所谓。
# 但**传到 Streamlit 云上公开访问**就是另一回事：
# 密钥如果由我们出，陌生人可以一直刷我们的账单。
# 所以给每个会话一个轮数上限。
#
# 【为什么做成可按环境变量调】
# 我自己演示时想多聊几轮；公开时想收紧。写死一个数两头都不合适。
try:
    _CAP = int(os.environ.get("ZHIYEJING_MAX_TURNS", "30"))
except ValueError:
    _CAP = 30
_turns = st.session_state.get("turns", 0)
_used_up = _turns >= _CAP

user_text = st.chat_input(
    "先说满这段对话了，重开一页可以接着聊"
    if _used_up else
    "说个专业名、问问区别，或者随便说点什么",
    disabled=_used_up)

if user_text and not _used_up:
    st.session_state.turns = _turns + 1
    st.session_state.msgs.append({"role": "user", "text": user_text})
    with st.chat_message("user"):
        st.markdown(user_text)

    with st.chat_message("assistant"):
        if not key:
            # 没 key 时的规则模式。**不解释自己，直接给东西。**
            low = user_text.strip()
            hit = next((mm for nm, mm in BY_NAME.items() if nm in low), None)
            if hit:
                st.markdown(card_html(hit), unsafe_allow_html=True)
                nxt = "（没填 key，我只能翻卡给你看。）"
            else:
                nxt = ("没听出来是哪个专业。直接打名字，比如「软件工程」。"
                       "　（没填 key，我只能翻卡。）")
            st.caption(nxt)
            st.session_state.msgs.append({"role": "assistant",
                                          "text": nxt})
        else:
            with st.spinner(""):
                hist = [{"role": ("assistant" if x["role"] == "assistant"
                                  else "user"), "content": x["text"]}
                        for x in st.session_state.msgs[-14:]]
                full = ([{"role": "system", "content": SYSTEM_PROMPT}]
                        + hist)
                ctx["trace"] = []
                text, calls, err = stream_llm(_client(key), full, ctx)

            if err:
                # 【公开部署时，报错要报人话】
                # 云上常见的失败是：密钥额度用尽、被限流、网络抖。
                # 直接甩一句英文栈给访问者，他只会觉得这应用坏了。
                # 但**也不能假装没事**——说清是网络那头的问题，
                # 而且给他一条还能走的路（重开一页、或者用没填 key 的翻卡模式）。
                st.warning("**这轮没接上。**"
                           "多半是网络那头的事，不是你的问题。"
                           "重开一页再试，或者直接打专业名——"
                           "**那个不用联网也能翻卡给你看。**")
                st.session_state.msgs.append(
                    {"role": "assistant",
                     "text": "（这轮没接上，重开一页再试。）"})
                st.caption(f"（技术细节：{err}）")
            else:
                text, why = guard(text, calls, ctx.get("seen_nums"))
                if why:
                    # 丢掉了就说丢掉了，但**不解释机制**，而且
                    # **同一秒把内容补上**——不能只留一句客气话。
                    # 详见 `_angle_shift()` 上面那段注释。
                    _fix = _angle_shift(text)
                    _line = _fix or (
                        "这条我说不准。**不过换个问法还有的聊：**"
                        "你说的这两条，各自要什么、出来往哪走，"
                        "你挑一个先问我，我给你摊开。")
                    st.warning(_line)
                    # 把这一轮记进去，免得上下文错位。
                    # 【删掉了原来那句自我检讨】
                    # 原来是「（刚才那句我说过头了，我自己收回来。）」+ 正文。
                    # 用户原话：「你给我把刚才那句『我说过头了，我自己收回来』
                    # 删掉，我不要你注意了，这部分删掉就好了」。
                    # 对——**自报失误是把注意力引到机制上**，
                    # 而他要的是内容。所以只留正文。
                    st.session_state.msgs.append(
                        {"role": "assistant", "text": _line})
                else:
                    render_assistant(text)
                    st.session_state.msgs.append(
                        {"role": "assistant", "text": text})
    st.rerun()

# 【用满了要说一句，不能只是让输入框悄悄变灰】
# 输入框把自己禁用了，但**为什么不给用**得说出来，
# 而且要给一条出路——不然用户以为应用坏了。
if _used_up:
    st.info(f"这一段聊了 **{_CAP}** 轮，先到这儿。"
            "**重开一页就能接着聊**——每个新页面都是一段新的对话。")
