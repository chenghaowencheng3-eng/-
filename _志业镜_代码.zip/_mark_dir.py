# -*- coding: utf-8 -*-
"""开场白记号文件到底在哪儿——**唯一一处定义**。

【为什么需要这个文件】
产品改过一次：记号从「和源码放一起」改成「去一个真能写的目录」，
因为 **Streamlit 云上的仓库目录是只读的**。
改完之后，闸门 `_check_openers_vary.py` 里那句
`MARK = os.path.join(ROOT, "_开场记号.txt")` 就过期了，
于是它报「记号文件写出来了 ✗」——
**红的原因不是功能坏了，是我把路径猜错了。**

一个路径在两处各写一份，就一定会有一次对不上。
所以定位逻辑只有这一份，产品源码里的那段和这里必须一致；
`_audit` 里那条闸门会断言两边一样。
"""
import os
import tempfile

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
def writable_dir():
    """找一个真能写的目录。找不到返回 None。

    【为什么要真的写一个探针文件】
    不能只看目录存不存在——**云上的目录存在，但不可写**。
    只有真写进去一次才算数。
    """
    for d in (os.path.join(tempfile.gettempdir(), "zhiyejing"),
              tempfile.gettempdir(), os.getcwd()):
        try:
            os.makedirs(d, exist_ok=True)
            probe = os.path.join(d, ".probe")
            with open(probe, "w", encoding="ascii") as f:
                f.write("1")
            os.remove(probe)
            return d
        except OSError:
            continue
    return None


def mark_path():
    """记号文件的完整路径；一个能写的目录都没有时返回 None。"""
    d = writable_dir()
    return None if d is None else os.path.join(d, "_开场记号.txt")


def mark_path_of_assembled(app_path):
    """问**拼装好的那个文件**：记号到底写哪儿？

    【为什么要从产物里读，不直接调上面那个 `mark_path()`】
    因为产物是独立的：它把定位逻辑内联进去了，**不 import 本模块**。
    如果闸门直接用 `mark_path()`，那验的是「本模块怎么想」，
    不是「产品实际怎么写」——**两边漂移了闸门也看不出来**。
    所以这里从产物源码里把那段抠出来执行，问的是产物本人。
    """
    src = open(app_path, encoding="utf-8").read()
    i = src.find("def _writable_dir():")
    if i < 0:
        return None
    j = src.find("_MARK = os.path.join(_dir", i)
    if j < 0:
        return None
    k = src.find("\n", j)
    ns = {"os": os, "tempfile": tempfile}
    # 定义那段定位函数
    _end = src.find("\n        _dir = _writable_dir()", i)
    if _end < 0:
        return None
    exec(src[i:_end], ns)
    if "_writable_dir" not in ns:
        return None
    ns["_dir"] = ns["_writable_dir"]()
    exec(src[j:k].strip(), ns)
    return ns.get("_MARK")
