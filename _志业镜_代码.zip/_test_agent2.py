# -*- coding: utf-8 -*-
"""测装配后的 志业镜.py。

【为什么不能只用 AppTest】
AppTest 的 `.markdown` **收不到 `unsafe_allow_html=True` 的元素**，
所以卡片它完全看不见——我差点以为卡片没渲染。
（`.html` accessor 在 1.63 里也不存在。）

于是这个测试自己搭台子：用一个**假的 streamlit** 把装配后的文件执行一遍，
拿到里面真正的函数直接调。这样卡片 HTML、守卫、工具调度都能测。
"""
import io
import json
import re
import sys
import types

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(
    _os.path.abspath(__file__))))
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")


# ── 假 streamlit ──
class State(dict):
    """既能 st.session_state["x"] 也能 st.session_state.x 的假对象。

    Streamlit 的真 session_state 两种都支持，假的也得支持，
    不然一执行到 `st.session_state.ctx = ...` 就炸。
    """

    def __getattr__(self, k):
        try:
            return self[k]
        except KeyError:
            raise AttributeError(k) from None

    def __setattr__(self, k, v):
        self[k] = v

    def setdefault(self, k, d=None):
        if k not in self:
            self[k] = d
        return self[k]

    def get(self, k, d=None):
        return dict.get(self, k, d)


class Fake:
    def __init__(self):
        self.marked = []
        self.captions = []
        self.warnings = []
        self.session_state = State()

    # st.sidebar / st.columns / st.expander 都要能当上下文管理器用，
    # 所以假对象也得实现 __enter__/__exit__
    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    @property
    def sidebar(self):
        return self

    def columns(self, spec):
        n = spec if isinstance(spec, int) else len(spec)
        return [self] * n

    def tabs(self, names):
        return [self] * len(names)

    def expander(self, *a, **k):
        return self

    def spinner(self, *a, **k):
        return self

    def chat_message(self, *a, **k):
        return self

    def __getattr__(self, name):
        # button / text_input / chat_input 这些在真实 Streamlit 里返回控件对象，
        # 假实现返回 None 就够——我们测的是卡片和守卫，不是交互本身
        def f(*a, **k):
            if name == "markdown":
                self.marked.append((a[0] if a else "", k))
            elif name == "caption":
                self.captions.append(a[0] if a else "")
            elif name == "warning":
                self.warnings.append(a[0] if a else "")
            return None
        return f


fake = Fake()
sys.modules["streamlit"] = fake

src = open(f"{ROOT}/志业镜.py", encoding="utf-8").read()
ns = {"__name__": "assembled"}
exec(compile(src, "志业镜.py", "exec"), ns)

ok = bad = 0


def chk(c, m):
    global ok, bad
    if c:
        ok += 1
        print(f"  ✓ {m}")
    else:
        bad += 1
        print(f"  ✗ {m}")


card_html = ns["card_html"]
render_assistant = ns["render_assistant"]
guard = ns["guard"]
BY_NAME = ns["BY_NAME"]
MAJORS = ns["MAJORS"]
OCC_BY_NAME = ns["OCC_BY_NAME"]
SYSTEM_PROMPT = ns["SYSTEM_PROMPT"]
BANNED = ns["BANNED"]

print("=== 0. 系统提示词里的数字有没有和数据漂开 ===")
# 【为什么专门盯这一条】
# 提示词是**原样内联**的，不做模板替换，所以里面写死的数字会随数据漂。
# 已经漂过一次：它写着「他手上有 176 个专业卡」，而实际是 161——
# **模型会照着念，用户当场就能听出错。**
# 不给提示词加模板注入（那会让它更难读），改成让测试盯着：
# 漂了就红，红了就改。
_PROMPT = ns["SYSTEM_PROMPT"]
_WANT = [
    ("只有 {n} 个专业有「需求画像」", sum(1 for m in MAJORS if m.get("dims"))),
    ("{n} 个专业的代价数字是模板值",
     sum(1 for m in MAJORS if m.get("cost_templated"))),
]
for tpl, real in _WANT:
    pat = re.escape(tpl).replace(r"\{n\}", r"(\d+)")
    mt = re.search(pat, _PROMPT)
    if not mt:
        # 句子被改写、模板对不上了——**这本身也要报**，
        # 不然检查会在提示词改写后静默失效
        chk(False, f"提示词里找不到这条（句子被改了？）：{tpl}")
        continue
    got = int(mt.group(1))
    chk(got == real,
        f"提示词里的「{tpl.format(n=got)}」和数据一致（实际 {real}）")
# 提示词里不许再出现别的写死的「N 个专业」
_loose = re.findall(r"(\d+)\s*个专业", _PROMPT)
_stray = [x for x in _loose if x not in ("161", "94", "88")]
chk(not _stray,
    f"提示词里没有别的写死的专业数（发现 {_stray}）")

print("=== 1. 数据接进来了 ===")
# 【这里原来写死 163】
# 专业数从 163 变成 161 之后，这条一直红着，而**红色的标签打的是真实值**
# （`f"{len(MAJORS)} 个专业"`），所以看上去像别的错。
# 现在改成从牌局的权威数据算出来比——**写死的数字早晚会过期，
# 而这个数字本来就该和牌局一致。**
_cards = json.load(open("_majors.json", encoding="utf-8"))
_n_cards = len(_cards["majors"] if isinstance(_cards, dict)
               and "majors" in _cards else _cards)
chk(len(MAJORS) == _n_cards,
    f"{len(MAJORS)} 个专业（牌局那边是 {_n_cards} 个）")
chk(sum(1 for m in MAJORS if m.get("dims")) == 94, "94 个有需求画像")
chk(len(OCC_BY_NAME) > 97, f"{len(OCC_BY_NAME)} 个职业名/别名可查")

print()
print("=== 2. 卡片 HTML（AppTest 看不见的那部分）===")
h = card_html(BY_NAME["软件工程"])
chk("mcard" in h, "有卡片容器")
chk("软件工程" in h, "有专业名")
chk("它对人的要求" in h, "有需求画像")
# 需求要用**人话**说，不能只甩数字。
# 【上一版这条断言是我写错的】我硬写了「没人给你划重点」，
# 但软件工程的 dims 是 [3,4,4,5,4,4,3]，最重的是「动手要求」和
# 「细节分辨」，自驱不是最高。**断言写死了具体字串，就等于测我自己的记忆。**
_plain_hits = [p for p in ns["DIM_PLAIN"].values() if p in h]
chk(len(_plain_hits) >= 3, f"需求用人话说（命中 {len(_plain_hits)} 条）")
chk("它对人的要求" in h and "/5" in h, "数字也在（人话+数字都给）")
# 【这条改过，改的是内容、不只是标签】
# 原来的卡只有一句文字「代价」（`weary` 那句话），
# **没有任何数字**——而「这条路要花多久、好不好回头」正是用户最想知道的。
# 现在对话流里的卡也走共享的 `_cards_core.summary_data()`，
# 代价是数字行（每周多少小时 / 上手几年 / 可不可回头），
# 而且**模板值必须当场标出来**（88 个专业的代价是按专业类常见情况填的）。
# 所以断言从「有『代价』这两个字」升级成「有代价的数字行」。
chk("学什么" in h and "要花多少" in h, "有学什么和代价")
# 【这条我连错两次，都是「凭印象挑样本」】
#   第一次：以为这张卡是建筑学（其实是软件工程）→ 断言「55 小时」，真值 49。
#   第二次：以为软件工程是 C1（其实 templated=True、tier=C2）。
# 现在这两件事都**从正在测的那个对象身上取**，不再写我以为的值。
_sw = BY_NAME["软件工程"]
chk(_sw.get("cost_hours") == 49,
    f"（前提）软件工程每周 {_sw.get('cost_hours')} 小时")
chk("49" in h, "代价给了数字（软件工程每周 49 小时）")
chk(bool(_sw.get("cost_templated")),
    "（前提）软件工程是 C2、代价是模板值")
# 模板值**必须当场标出来**——不标就是拿估计冒充准数
chk("模板值" in h, "模板值的代价在卡片上被标了出来")
# 反过来：C1（核实过的）不许被说成模板值。用建筑学验一次。
_h_c1 = card_html(BY_NAME["建筑学"])
chk(not BY_NAME["建筑学"].get("cost_templated"),
    "（前提）建筑学是 C1、代价不是模板值")
chk("模板值" not in _h_c1, "C1 的代价没有被误标成「模板值」")
chk("55" in _h_c1, "C1 的代价也给了数字（建筑学每周 55 小时）")
chk("这个下午就能试" in h, "有「这个下午就能试」")
chk("出来能干什么" in h, "有官方就业方向")
# 标签必须闭合，不然会吃掉后面的内容
for tag in ("div", "b", "code"):
    o = len(re.findall(rf"<{tag}[ >]", h))
    c = len(re.findall(rf"</{tag}>", h))
    chk(o == c, f"<{tag}> 开合一致（{o}/{c}）")

h2 = card_html(BY_NAME["逻辑学"])
chk("还没有「需求画像」" in h2, "没画像时说没有，不编")

print()
print("=== 3. 标记插卡 ===")
fake.marked.clear()
render_assistant("看看这个——\n\n[[CARD:软件工程]]\n\n它要你能自己找路。")
vals = [x[0] for x in fake.marked]
chk(any("mcard" in v for v in vals), "标记被换成了卡片")
chk(any("看看这个" in v for v in vals), "卡片前的文字还在")
chk(any("它要你能自己找路" in v for v in vals), "卡片后的文字还在")
# 顺序要对：文字 → 卡 → 文字
idx = [i for i, v in enumerate(vals) if "mcard" in v][0]
chk(any("看看这个" in v for v in vals[:idx]), "文字在卡前面")
chk(any("自己找路" in v for v in vals[idx:]), "文字在卡后面")
# 编造的专业名不许画卡
fake.marked.clear()
fake.warnings.clear()
render_assistant("[[CARD:星际飞船驾驶]]")
chk(not any("mcard" in v for v in fake.marked), "编造的专业名不画卡")
chk(fake.warnings, "而且会警告（不许它编）")

print()
print("=== 4. 守卫：替用户决定就丢掉 ===")
for w in ("建议你选软件工程", "这个最适合你", "你不适合学医",
          "你能力不足", "以你的条件别学艺术"):
    t, why = guard(w, [])
    chk(t is None and why, f"拦下「{w}」")
# 【这条得喂工具返回】
# 原来写的是 `guard("软件工程要你自驱 5 分…", [])`——
# 加了事实关之后，**没查过任何东西就说数字本来就该被拦**，
# 所以那条「正常的话放行」红了。错的不是守卫，是这条没给材料。
_t, _w = guard("软件工程要你自驱 5 分，但细节只要 1 分。", [], {5.0, 1.0})
chk(_t is not None and _w is None, "正常的话放行（数字是工具给过的）")
chk(len(BANNED) >= 9, f"{len(BANNED)} 条禁语")

print()
print("=== 5. 提示词的调子 ===")
chk("短" in SYSTEM_PROMPT, "要求说短")
chk("像一起玩一把游戏" in SYSTEM_PROMPT, "调子定成玩游戏")
chk("不要说自己在做什么" in SYSTEM_PROMPT, "禁止自我解说")
chk("我来为你查询" in SYSTEM_PROMPT, "给了反面例子")
chk("不要问「你还有什么想问的」" in SYSTEM_PROMPT, "禁止套话式追问")
# 【这两条换过措辞，但守的事没换——所以断言跟着换，规矩不许丢】
# 起因：用户要「语言别那么人机」，我把提示词里那批「不许/绝不」
# 改成了「你不替他做决定」这种说法。这两条断言找的是旧字面，就红了。
#
# 【为什么是改断言、不是改回去】
# 要判断的是「这条规矩还在不在」，不是「这句话还叫不叫这个名字」。
# 旧写法 `不许推荐专业` 和现在的 `你不替他做决定`说的是同一件事。
# 但**我不能默默换掉**——所以下面两条同时盯两件事：
#   ① 新说法在；② 旧说法里那个具体的禁令也还在（换行不换事）。
# 【这条换过两次措辞，守的事没换】
# 第一次：用户要「语言别那么人机」，我把「不许推荐专业」
#   改成「你不替他做决定」，断言找旧字面就红了。
# 第二次：用户说「不需要你管做不做决定」——**那句话本身也不许说出口**，
#   于是第一条改成「给东西，不给结论」。
# 【为什么还是改断言、不是改回去】
# 要判断的是「这条规矩还在不在」，不是「它还叫不叫这个名字」。
# 所以断言盯的是**实质**：禁令词还在（不能下结论），
# 而且反面示范也还在（说了不能怎么说）。
chk("给东西，不给结论" in SYSTEM_PROMPT
    and all(w in SYSTEM_PROMPT
            for w in ("建议你选", "你应该选", "这个最适合你")),
    "守住不推荐（措辞已从「你不替他做决定」改成「给东西，不给结论」）")
# 【反向也要守】用户说过「不需要你管做不做决定」，
# 所以「你不替他做决定」这句本身**不许再当成第一条**。
chk("你不替他做决定" not in SYSTEM_PROMPT,
    "提示词里不再有「你不替他做决定」这句表态")
# 而且要说清「别把机制讲出来」——这是那次的实质要求
chk("把机制讲出来" in SYSTEM_PROMPT, "提示词说清「别讲你为什么讲不了」")
chk("现实条件" in SYSTEM_PROMPT and "只能谈可行性和时间表" in SYSTEM_PROMPT,
    "守住现实条件不许评判人")
chk("[[CARD:" in SYSTEM_PROMPT, "教了它怎么插卡")
chk("没做过的事说「还没试过」，不说「你不擅长」" in SYSTEM_PROMPT,
    "守住低证据≠低能力（措辞已从「低证据不等于低能力」改成正面写法）")
# 提示词里不该有「我是AI」这种自我暴露
for w in ("作为AI", "作为一个AI", "语言模型", "AI助手"):
    chk(w not in SYSTEM_PROMPT, f"提示词里不出现「{w}」")

print()
print("=== 6. 工具能调通 ===")
ctx = ns["new_ctx"]()
ctx["mirror_fn"] = ns["mirror_fn_factory"](ctx)
run_tool = ns["run_tool"]
r = run_tool("show_major", {"name": "软件工程"}, ctx)
chk(r["found"], "show_major 能查到")
r = run_tool("requirements", {"name": "软件工程"}, ctx)
chk(r["has_profile"], "requirements 有画像")
chk(r["cost"]["is_templated"] is True, "模板代价被标出来")
r = run_tool("lookup_unavailable", {"name": "星际飞船驾驶"}, ctx)
chk("没有就说没有" in r["rule"], "查不到时规矩写死在返回值里")
r = run_tool("occupation_info", {"name": "软件工程师"}, ctx)
chk(r.get("important_courses"), "职业详情查得到")

print()
print("=== 7. 镜像在真实上下文里能读 ===")
ctx2 = ns["new_ctx"]()
ctx2["mirror_fn"] = ns["mirror_fn_factory"](ctx2)
ctx2["collected"] = ["计算机科学与技术", "数学与应用数学", "建筑学"]
ctx2["rejected"] = [("临床医学", ["背不下来"])]
r = run_tool("read_mirror", {}, ctx2)
chk(r.get("enough") is True, "3 张卡后开口")
chk(r.get("hypotheses"), "给了假设")

print()
print("=== 8. 界面不许泄露开发笔记 ===")
# 顶层裸字符串会被 Streamlit 当 markdown
import ast
t = ast.parse(src)
bare = [n.lineno for n in t.body
        if isinstance(n, ast.Expr) and isinstance(n.value, ast.Constant)
        and isinstance(n.value.value, str)]
chk(not bare, f"顶层没有裸字符串（{bare}）")
# 侧栏/主区不许出现解释自己的长段
for w in ("点选模式", "我会假装", "这一轮我丢掉了"):
    chk(w not in src, f"界面里没有旁白「{w}」")

print()
print("=== 9. 逐条标出处（目标里的「逐条标注出处」）===")
fake.marked.clear()
# sources_block 直接调，看它列出了几条、有没有把官方和个人判断分开
sb = ns["sources_block"]
sb(BY_NAME["软件工程"])
txt = "\n".join(str(x[0]) for x in fake.marked)
chk("教育部" in txt, "标了教育部目录")
chk("学职平台" in txt, "标了学职平台")
chk("学信网" in txt and "实名投票" in txt, "标了学信网实名投票")
chk("官方" in txt, "有「官方」这个等级")
chk("个人判断" in txt or "不是数据" in txt,
    "把「别人的判断」和官方数据分开标")
chk("模板值" in txt, "模板值被标出来")
chk("没有逐一核实" in txt or "公开资料推" in txt, "推测的来源也标了")

fake.marked.clear()
sb(BY_NAME["临床医学"])
t2 = "\n".join(str(x[0]) for x in fake.marked)
chk("访谈核实" in t2, "访谈核实过的标成「访谈核实」")

# 官方覆盖是**算出来的**，不是写死的清单
g = ns["MAJOR_DATA"]
chk(len(g.get("official_classes") or {}) > 80,
    f"官方专业类对照表在（{len(g.get('official_classes') or {})} 条）")
chk(len(g.get("class2gate") or {}) > 80, "class2gate 在")
# 抽样：有官方代码的专业应判为「官方」
sb(BY_NAME["软件工程"])
t3 = "\n".join(str(x[0]) for x in fake.marked)
chk("软件工程" in BY_NAME["软件工程"]["n"] and "官方" in t3,
    "软件工程被正确判为官方在册")

print()
print("=== 10. sources_of_major 工具 ===")
ctx3 = ns["new_ctx"]()
ctx3["mirror_fn"] = ns["mirror_fn_factory"](ctx3)
r = run_tool("sources_of_major", {"name": "软件工程"}, ctx3)
chk(r.get("rows"), f"返回 {len(r.get('rows') or [])} 条出处")
lv = [x["等级"] for x in r["rows"]]
chk(any("官方" in x for x in lv), "有官方等级")
chk(any("个人判断" in x for x in lv), "有个人判断等级")
chk(any("模板值" in x for x in lv), "有模板值标记")
chk("等级从高到低" in r["read"], "给了等级顺序，便于它排话说")
# 拿不到对照表时要如实说，不能默默降级
ctx4 = ns["new_ctx"]()
ctx4["major_data"] = {}
r2 = run_tool("sources_of_major", {"name": "软件工程"}, ctx4)
chk(any("未能核对" in x["等级"] for x in r2["rows"]),
    "拿不到对照表时说「未能核对」，不冒充官方")

print()
print("=== 11. 后置守卫：措辞关 + 事实关 ===")
# 【这一节是稿子上要当场演示的那一条】
# 稿子第 16 页写着「试着让它说一个错的数字，看会不会被拦下」。
# 而对话版原来**只查措辞、不查数字**——事实守卫只在牌局里有。
# 上台做会翻车。补上之后这里盯着它别再退回去。
guard = ns["guard"]
# 【这一组数字是挑过的】
# 我第一版这里放了「认知负荷 5」，于是「临床医学要读**五**年」的 5
# 变成**合法数字**，守卫放行——而我在测试里期望它被拦。
# 期望和素材自相矛盾，红的是测试不是代码。
# 现在故意**不放 5**：这样「五年」才是真的没出处，拦下才有意义。
_C = [("requirements", {"name": "计算机科学与技术"},
       str({"found": True,
            "dims": {"认知负荷": 4, "记忆量": 2, "细节分辨": 1,
                     "动手要求": 3, "自驱要求": 4, "挫折耐受": 4,
                     "慢反馈耐受": 3},
            "cost": {"周均小时": 45, "几年能独立": 3,
                     "几个月有反馈": 1}})[:160])]
for text, block in (
        ("这个专业每周要 45 小时。", False),
        ("这个专业每周要 60 小时。", True),
        ("就业率 98%。", True),
        ("学费一年 5000 元。", True),
        ("临床医学要读五年。", True),          # 中文数字也要拦
        ("计算机的七维里自驱要求是 4 分。", False),   # 「七维」不算数字
        ("咱先聊两三件事。", False)):               # 闲聊不该拦
    _o, _w = guard(text, _C)
    # 【方向别搞反】`_w` 是**拦截理由**：有理由 = 拦下了，None = 放行。
    # 我第一版写成 `bool(_w) == block`，于是「该拦的」全报红。
    chk(bool(_w) == block,
        f"{'拦下' if block else '放行'}「{text}」"
        + (f"（{_w}）" if _w else ""))

# 跨轮：上一轮查过的数，这一轮复述不该被拦
_seen = {5.0, 2.0, 1.0, 3.0, 4.0, 45.0}
_o, _w = guard("计算机的自驱要求是 5 分。", [], _seen)
chk(not _w, "跨轮复述上一轮查过的数，不该被拦")
_o, _w = guard("它每周 70 小时。", [], _seen)
chk(bool(_w), "跨轮里编的数照样拦（70 不在 seen 里）")

# 只查措辞的那一半还在
_o, _w = guard("建议你选软件工程。", _C)
chk(bool(_w) and "建议你选" in _w, "措辞关还在（建议你选）")

print()
print(f"结果：{ok}/{ok + bad} 通过"
      + ("" if bad == 0 else f"　失败 {bad}"))
