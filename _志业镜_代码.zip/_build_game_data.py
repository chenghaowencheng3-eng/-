# -*- coding: utf-8 -*-
"""重做「游戏化」字段的派生逻辑。

第一版的错：hook 和 fun 都是 daily 的截断，**两张卡上写着同一句话**。
卡片因此看着很空——用户说「不太好、不搭」，这是直接原因。

第二版的判断（这才是关键）：
  **最抓人的部分恰恰是 hardest。**
  「在很小的空间里做不可逆的操作，而且患者是清醒的、能看见你。」
  ——这句话比任何招聘广告都吸引人。它同时是「有意思」和「可怕」。

  所以卡片的主视觉应该是**这个职业最难的那一点**，
  而不是「每天做什么」的流水账。

字段设计：
  hook   一句话钩子——直接取 hardest 的核心冲突（最有戏的那句）
  daily  每天在干嘛（原文，轻松说法）
  craft  这门手艺好玩的点（从 daily 里挑出「动作」部分）
  weary  什么会烦到你（avoid + hardest）
  suits  谁会觉得有意思
  touch  手感
"""
import io, json, re, sys
from collections import Counter

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

src = open(os.path.join(ROOT, "对话子智能体.py"), encoding="utf-8").read()
A = 'CAREER_DATA = json.loads(r"""'
i = src.index(A) + len(A)
j = src.index('""")', i)
d = json.loads(src[i:j])

# 【必须先清 markdown 再派生】
# 职业库原文里带加粗，而且**是夹在句子中间的**：
#   「你**要为公司省钱，又要保证不断供**，这两件事在紧急时必然冲突。」
# 我一开始把清理放在派生之后，于是切句和关键词匹配都在带 ** 的文本上做，
# 「又要」被 ** 挡开，那句带冲突的话就没被选成钩子——
# 结果 hook 退化成和 craft 一模一样。
# **处理顺序错了，逻辑再对也没用。**
import re as _re



def _strip_md(x):
    if isinstance(x, str):
        return _re.sub(r"\*\*", "", x)
    if isinstance(x, list):
        return [_strip_md(v) for v in x]
    if isinstance(x, dict):
        return {k: _strip_md(v) for k, v in x.items()}
    return x


d = _strip_md(d)

CAP2RIASEC = {
    "hands_on": "R", "logic": "I", "sensation": "C", "creativity": "A",
    "empathy": "S", "language": "S", "organization": "E",
    "self_drive": "E", "judgment": "E",
}
RIASEC_CN = {"R": "现实型", "I": "研究型", "A": "艺术型",
             "S": "社会型", "E": "企业型", "C": "常规型"}
RIASEC_PITCH = {"R": "动手把东西做出来", "I": "把问题搞清楚",
                "A": "做出没人做过的东西", "S": "帮到具体的人",
                "E": "拿主意、把事推成", "C": "把复杂的事理清楚"}

FAST = ["快", "紧急", "节奏", "赶", "突发", "同时", "多线", "现场"]
SLOW = ["周期", "长期", "反复", "慢慢", "多年", "长线", "打磨", "迭代"]
PPL = ["沟通", "患者", "病人", "客户", "家属", "团队", "学生", "同事",
       "对方", "用户", "面谈", "协调", "谈判", "家长", "农户", "指导"]
ALONE = ["独自", "独立", "一个人", "安静", "数据", "文献", "代码", "图纸",
         "实验", "审", "核对"]
CLEAR = ["规范", "标准", "流程", "制度", "明确", "按", "固定", "查对"]
VAGUE = ["不确定", "没有现成", "模糊", "变化快", "新", "探索", "判断",
         "权衡", "取舍", "没有标准"]


def _blob(c):
    return " ".join([c.get("daily", ""), c.get("hardest", ""),
                     c.get("failure", "")])


def _has(blob, ws):
    return any(w in blob for w in ws)


def touch_of(c):
    b = _blob(c)
    return {"节奏": "快" if (_has(b, FAST) and not _has(b, SLOW))
                    else ("慢" if _has(b, SLOW) else "中"),
            "见人": "多" if _has(b, PPL) else "少",
            "答案": "清楚" if (_has(b, CLEAR) and not _has(b, VAGUE))
                    else "模糊"}


def clauses(text):
    """把一段话切成小句，去掉空的和太短的。"""
    parts = re.split(r"[。；;]", text or "")
    return [p.strip(" ，、") for p in parts if len(p.strip()) > 4]


# 「有戏」的标记：转折、对比、意外、两难。
#
# 【补记】第一版漏了「又要…又要…」这种**并列冲突**句式，
# 于是「要为公司省钱，又要保证不断供，这两件事在紧急时必然冲突」
# 这句最有戏的话没被选中，钩子退化成和「手艺」一模一样。
# **只列转折词是不够的——两难也是戏。**
DRAMA = ["但", "却", "其实", "真正", "往往", "永远", "比", "远少于",
         "远多于", "大多数", "没人", "不可逆", "偏偏", "反而",
         "不在", "不是", "又要", "既要", "必须", "同时", "矛盾",
         "冲突", "取舍", "代价", "最怕", "最怕", "熬", "不可见"]


def pick_hook(c):
    """挑最有戏的一句当钩子。

    优先顺序：
      1) hardest 里含转折词的小句（冲突最集中）
      2) daily 里含转折词的小句（意外的真相）
      3) hardest 的任意小句
      4) daily 里**和 craft 不同**的小句（避免两张卡说同一句话）

    第 4 条是补的：第一版有几个职业没有转折词，
    于是 hook 退化成和 craft 一模一样——卡片上写着同一句话两遍，
    看着很空。**「退化成重复」是这类派生逻辑最容易出的问题。**
    """
    for fld in ("hardest", "daily"):
        for cl in clauses(c.get(fld, "")):
            if any(w in cl for w in DRAMA):
                return cl
    h = (c.get("hardest") or "").strip()
    if h:
        cls = clauses(h)
        if cls:
            return cls[0]
    craft = pick_craft(c)
    for cl in clauses(c.get("daily", "")):
        if cl != craft:
            return cl
    for cl in clauses(c.get("hardest", "")):
        if cl != craft:
            return cl
    return craft


def pick_craft(c):
    """「手艺」：daily 里最像动作的那一小句（不含转折的实做部分）。"""
    cls = clauses(c.get("daily", ""))
    plain = [x for x in cls if not any(w in x for w in DRAMA)]
    if plain:
        # 取动作最密的一句（顿号最多的通常是动作罗列）
        return max(plain, key=lambda x: (x.count("、"), len(x)))
    return cls[0] if cls else (c.get("daily") or "")


def build(c):
    codes = []
    for cp in (c.get("caps") or []):
        r = CAP2RIASEC.get(cp)
        if r and r not in codes:
            codes.append(r)
    lead = codes[0] if codes else "I"
    avoid = c.get("avoid") or []

    out = dict(c)
    out["holland"] = codes
    out["holland_lead"] = lead

    # 【括号里的说明不能当钩子】
    # 「（注意：这里说的是「执行岗」，不是全部设计）」被选成钩子过——
    # 那是一句免责声明，不是这个职业的戏。
    # 萎缩职业的戏在 shrink.verdict 里，所以先看它。
    _hook = ""
    _sh = c.get("shrink") or {}
    if isinstance(_sh, dict) and _sh.get("verdict"):
        _hook = _strip_md(_sh["verdict"])
    if not _hook:
        _hook = pick_hook(c)
    # 以括号/注意开头的，退回到 hardest
    if _hook.lstrip().startswith(("（", "(", "注意", "说明")):
        _hook = clauses(c.get("hardest", ""))[0] if clauses(
            c.get("hardest", "")) else pick_hook(c)
    out["hook"] = _hook

    out["craft"] = pick_craft(c)
    out["weary"] = "、".join(avoid[:3]) if avoid else ""
    out["suits"] = (f"喜欢「{RIASEC_PITCH[lead]}」的人"
                    + (f"；受不了{avoid[0]}的别来" if avoid else ""))
    out["touch"] = touch_of(c)
    return out


new = [build(c) for c in d["careers"]]
d["careers"] = new
d["riasec_cn"] = RIASEC_CN
d["riasec_pitch"] = RIASEC_PITCH

L = []
L.append(f"=== 抽查 6 张卡（这就是用户看到的）===")
for c in (new[0], new[1], new[20], new[26], new[40], new[52]):
    L.append(f"\n┌─ {c['n']}  [{RIASEC_CN[c['holland_lead']]}] {c['fam']}")
    L.append(f"│ 钩子   {c['hook']}")
    L.append(f"│ 手艺   {c['craft']}")
    L.append(f"│ 会烦你 {c['weary']}")
    L.append(f"│ 适合   {c['suits']}")
    L.append(f"│ 手感   {c['touch']['节奏']} / 见人{c['touch']['见人']} / "
             f"答案{c['touch']['答案']}")
    L.append(f"└─ 入行   {c.get('entry','')[:40]}")

# 重复率检查：hook 和 craft 撞车的有多少
dup = sum(1 for c in new if c["hook"] == c["craft"])
L.append("")
L.append(f"=== 质量检查 ===")
L.append(f"  hook == craft 的职业数：{dup}（越低越好，第一版是全部）")
L.append(f"  hook 为空：{sum(1 for c in new if not c['hook'])}")
L.append(f"  craft 为空：{sum(1 for c in new if not c['craft'])}")
L.append(f"  weary 为空：{sum(1 for c in new if not c['weary'])}")
L.append(f"  hook 平均长度：{sum(len(c['hook']) for c in new)/len(new):.0f} 字")

open(os.path.join(ROOT, "_careers_game.json"), "w", encoding="utf-8").write(
    json.dumps(d, ensure_ascii=False, indent=1))
open(os.path.join(ROOT, "_game_preview.txt"), "w", encoding="utf-8").write(
    "\n".join(L))
