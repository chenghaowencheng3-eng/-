# -*- coding: utf-8 -*-
"""找出「装了 streamlit 的那个解释器」——别写死路径。

【为什么需要这一步】
`_check_delivery.py` 原来用 `sys.executable` 去跑包里的测试和闸门。
如果**启动它的那个解释器**是运行时环境（没有 streamlit），
那 12 个闸门会齐刷刷报 `ModuleNotFoundError: No module named 'streamlit'`——
**看起来像包里缺东西，其实是我拿错了解释器**。
那种红最费时间：它指向错的方向，还一副有理有据的样子。

所以这里不写死路径，而是**问一遍**：哪个解释器 import 得到 streamlit。
"""
import os
import subprocess
import sys

# 候选：当前解释器、以及这台机器上已知的两个
_CANDIDATES = [
    sys.executable,
    r"C:\Users\Lenovo\AppData\Local\Python\pythoncore-3.14-64\python.exe",
    r"C:\Users\Lenovo\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe",
]


def _probe(p, mod):
    try:
        r = subprocess.run(
            [p, "-c", f"import {mod}"],
            capture_output=True, timeout=180,
            env={**os.environ, "PYTHONIOENCODING": "utf-8"})
    except (OSError, subprocess.SubprocessError):
        return False
    return r.returncode == 0


def _find(mod):
    seen = set()
    for p in _CANDIDATES:
        if not p or p in seen or not os.path.exists(p):
            continue
        seen.add(p)
        if _probe(p, mod):
            return p
    return None


def find_streamlit_python():
    """装了 streamlit 的那个解释器（跑界面闸门用）。"""
    return _find("streamlit")


def find_pptx_python():
    """装了 python-pptx 的那个解释器（跑讲稿闸门用）。

    【为什么需要两个】
    这台机器上两个环境是分工的：
      · 主环境有 streamlit，没有 pptx
      · 运行时环境有 pptx，没有 streamlit
    所以「哪套闸门用哪个解释器」得看闸门自己需要什么，
    **不能一刀切**。一刀切的后果是十几条闸门齐刷刷报
    `No module named 'streamlit'`，看着像包里缺东西。
    """
    return _find("pptx")


# 【只认这几个真的第三方库】
# 第一版写成「扫任何 `import xxx`」，于是 `import _find_python`、
# `from _root import ...` 这些**本地模块**也被当成了要装的包，
# 挑解释器就挑错了。本地模块在哪个环境下都有，不是判据。
_THIRD_PARTY = ("pptx", "pypdfium2", "openpyxl", "docx",
                "streamlit", "pandas", "numpy")


def python_for(script_path):
    """按脚本正文挑一个解释器**首选**。

    【为什么只是「首选」而不是「就是它」】
    有的闸门**同时**要 pptx 和 streamlit（`_check_slide18.py` 就是：
    它渲染讲稿，但读的那份产物 import streamlit）。
    而这两个库分别在两个环境里——**没有哪个解释器同时有**。
    所以真正的跑法见 `run_with_fallback()`：先试一个，缺模块就换另一个。
    """
    try:
        src = open(script_path, encoding="utf-8", errors="replace").read()
    except OSError:
        return find_streamlit_python()
    for mod in _THIRD_PARTY:
        if f"import {mod}" in src or f"from {mod}" in src:
            return _find(mod) or find_streamlit_python()
    return find_streamlit_python()


def run_with_fallback(script_path, args=(), cwd=None, timeout=900,
                      first=None):
    """跑一个脚本，缺模块就换另一个解释器再试一次。

    【为什么要这么绕】
    这台机器两个环境是分工的：主环境有 streamlit 没 pptx，
    运行时环境有 pptx 没 streamlit。**没有哪个同时有。**
    而个别闸门两样都要。一刀切会让它报
    `No module named 'streamlit'`，看着像包里缺东西。

    【但也绝不能「失败了就换一个再试」了事】
    那样会把真错误也重试一遍，而且掩盖原因。
    所以**只在 stderr 明明白白是 ModuleNotFoundError 时才换**。
    """
    import subprocess

    cands = [first or python_for(script_path), find_streamlit_python(),
             find_pptx_python()]
    tried, seen = None, set()
    for p in cands:
        if not p or p in seen or not os.path.exists(p):
            continue
        seen.add(p)
        r = subprocess.run([p, "-X", "utf8", script_path, *args], cwd=cwd,
                           capture_output=True, text=True, encoding="utf-8",
                           errors="replace", timeout=timeout,
                           env={**os.environ, "PYTHONIOENCODING": "utf-8"})
        tried = r
        if r.returncode == 0:
            return r
        # 【只在「真的缺模块」时才换解释器】
        if "ModuleNotFoundError" not in (r.stderr or ""):
            return r
    return tried
