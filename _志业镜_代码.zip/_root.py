# -*- coding: utf-8 -*-
"""行定位模块：让测试和闸门**不再依赖它被放在哪儿**。

【为什么需要它】
30 / 36 个闸门里写死了 `C:\\Users\\Lenovo\\zhiyejing`。
后果是：代码在自己的工作目录里永远全绿，**换台机器、换个目录就跑不动**——
我打包发给用户，他解开、跑闸门，32 个不过。
那不是他环境差，是**这份代码本来就没打算搬家**。

所以给一个 `find_root()`：自己往上找，找到放着 `志业镜.py` 的那一层。
找不到才回退到那个老路径，这样我本地的东西一条也不动。
"""
import os

# 老路径只当**最后**的兜底，不再当唯一答案。
_KNOWN = r"C:\Users\Lenovo\zhiyejing"
# 认这几个中的任意一个，说明这层就是根：
#   志业镜.py    —— 产品
#   _majors_src.py —— 源
#   _agent2_src.py —— 源
# 两种布局都要认：
#   ① 平铺（开发目录、以及交付包解开后就是这样）
#   ② 分目录（产品/、源/、数据/）
_MARKERS = ("志业镜.py", "_majors_src.py", "_agent2_src.py",
            os.path.join("产品", "志业镜.py"),
            os.path.join("源", "_majors_src.py"))


def _walk(d):
    """从 `d` 往上找，最多 8 层。"""
    d = os.path.abspath(d)
    for _ in range(8):
        if any(os.path.exists(os.path.join(d, m)) for m in _MARKERS):
            return d
        up = os.path.dirname(d)
        if up == d:
            break
        d = up
    return None


def find_root(start=None):
    """往上找项目根。

    找的是「看得见产品或源」的那一层，而不是「有某个固定名字的子目录」——
    换目录时只有相对关系还在，绝对位置会变。

    【为什么要找两次：模块所在处 + 当前工作目录】
    闸门可能的启动方式有两种：
      ① `python _审计\\_check_xxx.py` —— `__file__` 在根下面，往上能找到
      ② 从别处启动、或者测试里用子进程带着另一个 cwd 跑 ——
         `__file__` 那条路走不通，但 **cwd 在根下面**，往上也能找到
    只认一种就会出现「有的闸门能跑、有的找不到」——
    而那种红看起来像内容有问题，其实是找路找错了。
    """
    env = os.environ.get("ZHIYEJING_ROOT")
    if env and os.path.isdir(env):
        return env
    r = _walk(start or os.path.dirname(os.path.abspath(__file__)))
    if r:
        return r
    r = _walk(os.getcwd())
    if r:
        return r
    return _KNOWN


ROOT = find_root()
