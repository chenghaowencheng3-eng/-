# -*- coding: utf-8 -*-
"""对话智能体的「手」：一组只读工具 + 一组记录工具。

【为什么要做成工具，而不是把数据塞进 prompt】
176 个专业 + 97 个职业族 + 官方四维满意度 + 845 条评级，
全塞进 prompt 不现实（几十万字符），而且模型会**记错、会编**。

做成工具之后有一条硬规矩：
    **模型对专业说的每一句事实，都必须来自某次工具调用的返回值。**
它不能凭记忆说「计算机专业就业很好」——得先查，查到什么说什么，
查不到就说查不到。这条规矩是把「陪你聊」和「一本正经胡说」分开的东西。

【产品底线，写在工具层而不是提示词里】
script.py 原文那三条，这里用代码而不是嘱咐来保证：
  1. 现实条件（家里条件/地域/成绩）只能影响可行性和时间表，
     不能影响「你这个人适合什么」→ see_record_self / see_record_reality 分开
  2. 低证据 ≠ 低能力 → 没数据时工具返回「没有」，不许返回「低」
  3. 不给唯一「最佳答案」→ 没有 recommend 工具，只有 lookup
"""

import importlib as _importlib

DIM_KEYS = ["认知负荷", "记忆量", "细节分辨", "动手要求",
            "自驱要求", "挫折耐受", "慢反馈耐受"]

# ── 共用核心里的东西：两种运行方式都要能用 ──
# 这个文件有两种活法：
#   ① 被 `_assemble_agent2.py` 内联进 `志业镜.py`——
#      那时 `_mirror_core.py` 的内容也内联在同一个命名空间里，
#      `OPTIONS` / `ASK` 直接就能看见；
#   ② 被单独 import（测试、单跑）——那时什么都没有。
#
# 【为什么必须显式兜住】
# 第一版裸用 `OPTIONS[dim]`，于是**单独跑就 NameError**。
# 内联兜住了它，所以应用里看不出问题——
# **一个只在「另一种跑法」下才炸的错，最难发现，也最容易在演示外的地方炸。**
# 这里显式取一次：取得到就用，取不到留空，让代码自己判断。
try:
    _mc = _importlib.import_module("_mirror_core")
    ASK = getattr(_mc, "ASK", [])
    OPTIONS = getattr(_mc, "OPTIONS", {})
    DIM_SHORT = getattr(_mc, "DIM_SHORT", {})
    Q_OF = getattr(_mc, "Q_OF", {})
except Exception:                       # noqa: BLE001
    # 内联运行时走这里：宿主命名空间里已经有了，用 globals() 兜
    ASK = globals().get("ASK", [])
    OPTIONS = globals().get("OPTIONS", {})
    DIM_SHORT = globals().get("DIM_SHORT", {})
    Q_OF = globals().get("Q_OF", {})

# ──「你这个人」vs「现实条件」：两张表，不许混 ──
SELF_TAGS = ["坐得住", "喜欢动手", "喜欢跟人打交道", "喜欢想抽象问题",
             "喜欢做出来看得见的东西", "喜欢整理和条理",
             "受不了重复", "受不了没有标准答案", "受不了别人指挥",
             "数学不怵", "看见数字就烦", "写东西有瘾", "讨厌背书"]
REALITY_TAGS = ["家里希望我学某个", "成绩够不上", "学费贵",
                "不想离家太远", "家里需要我早点工作",
                "某个专业在我省招得少"]
assert not (set(SELF_TAGS) & set(REALITY_TAGS)), \
    "两张表不许有交集——现实条件不能当成人格"

# 官方就业方向里混着「考研」「公务员」这种——**那不是职业，是去向**。
# 牌局那边（`_majors_src.py`）有自己的同名表，工具层这边也必须有：
# 算「这个专业有多少个出口点得开」时用它，不然会把升学算成就业。
NOT_JOBS = {"考研", "事业单位人员", "公务员", "出国", "参军",
            "科研", "继续深造", "学术"}


def tool_specs():
    """给模型看的工具声明（OpenAI function-calling 格式）。"""
    return [
        {"type": "function", "function": {
            "name": "search_majors",
            "description": "按门类或关键词找专业。返回名字和一句话简介。"
                           "想具体看某个专业时用 show_major。",
            "parameters": {"type": "object", "properties": {
                "gate": {"type": "string",
                         "description": "学科门类，如 工学、文学。不填=全部"},
                "keyword": {"type": "string",
                            "description": "关键词，匹配专业名/课程/代价"},
                "limit": {"type": "integer"}}}}},
        {"type": "function", "function": {
            "name": "show_major",
            "description": "拿一个专业的卡片给用户看。这是他看得见的东西。",
            "parameters": {"type": "object", "properties": {
                "name": {"type": "string"}}, "required": ["name"]}}},
        {"type": "function", "function": {
            "name": "requirements",
            "description": "某专业对人提出的 7 项要求（0-5）和代价硬数据"
                           "（周均小时/到能独立年数/多久才有反馈/能否回头）。"
                           "**判断「这个我行不行」主要靠这个。**",
            "parameters": {"type": "object", "properties": {
                "name": {"type": "string"}}, "required": ["name"]}}},
        {"type": "function", "function": {
            "name": "similar_majors",
            "description": "和某专业在「对人的要求」上最像/最不像的专业。"
                           "用来做对照实验，比空谈适合不适合有用。",
            "parameters": {"type": "object", "properties": {
                "name": {"type": "string"},
                "most": {"type": "boolean",
                         "description": "true=最像，false=最不像"}},
                "required": ["name"]}}},
        {"type": "function", "function": {
            "name": "majors_by_dimension",
            "description": "找在某一项要求上高或低的专业。"
                           "如「不要求背书的专业」= dimension=记忆量, high=false",
            "parameters": {"type": "object", "properties": {
                "dimension": {"type": "string", "enum": DIM_KEYS},
                "high": {"type": "boolean"},
                "limit": {"type": "integer"}},
                "required": ["dimension"]}}},
        {"type": "function", "function": {
            "name": "occupations_of",
            "description": "某专业官方登记的就业方向（真实职业名）。",
            "parameters": {"type": "object", "properties": {
                "name": {"type": "string"}}, "required": ["name"]}}},
        {"type": "function", "function": {
            "name": "occupation_info",
            "description": "某个职业是什么：学历要求、重要大学课程、"
                           "工作内容、行业前景、薪酬结构。"
                           "还可以问「哪些专业通向它」。",
            "parameters": {"type": "object", "properties": {
                "name": {"type": "string",
                         "description": "职业名，如 软件工程师"},
                "want": {"type": "string",
                         "enum": ["all", "majors"],
                         "description": "majors=只看哪些专业通向它"}},
                "required": ["name"]}}},
        {"type": "function", "function": {
            "name": "student_ratings",
            "description": "学信网的官方四维满意度（在读学生实名投票）"
                           "和在校生规模。**必须连票数一起给用户**："
                           "32 票的 4.3 分和 5166 票的 4.0 不是一回事。"
                           "这是「在读体验」，不是就业率。",
            "parameters": {"type": "object", "properties": {
                "name": {"type": "string"}}, "required": ["name"]}}},
        {"type": "function", "function": {
            "name": "external_ratings",
            "description": "两份外部材料的评级（三维星级 / 综合推荐指数）。"
                           "**这是别人的判断，不是数据，必须标出处，"
                           "而且不同材料口径不同、会互相矛盾，"
                           "不许合成一个总分。**",
            "parameters": {"type": "object", "properties": {
                "name": {"type": "string"}}, "required": ["name"]}}},
        {"type": "function", "function": {
            "name": "sources_of_major",
            "description": "某个专业卡片上每一条信息的出处、以及可信度等级。"
                           "用户问「你怎么知道的」「这数据哪来的」时调这个。"
                           "**答出处的时候一定要说清哪条是官方的、"
                           "哪条只是别人的判断。**",
            "parameters": {"type": "object", "properties": {
                "name": {"type": "string"}}, "required": ["name"]}}},
        {"type": "function", "function": {
            "name": "lookup_unavailable",
            "description": "查库里有没有某个专业或职业。"
                           "**没有就如实说没有，绝对不许编。**"
                           "用户问的东西如果不在库里，先调这个确认。",
            "parameters": {"type": "object", "properties": {
                "name": {"type": "string"}}, "required": ["name"]}}},
        {"type": "function", "function": {
            "name": "remember_about_person",
            "description": "记下用户说过的关于**他自己**的事"
                           "（喜欢什么、受不了什么、做过什么）。"
                           "不是记专业信息。",
            "parameters": {"type": "object", "properties": {
                "tag": {"type": "string", "enum": SELF_TAGS},
                "quote": {"type": "string",
                          "description": "用户的原话，尽量照抄"}},
                "required": ["tag", "quote"]}}},
        {"type": "function", "function": {
            "name": "remember_reality",
            "description": "记下**现实条件**（家里的意见、成绩、钱、地域）。"
                           "**这些只能用来谈可行性和时间表，"
                           "绝对不能用来判断他适合什么。**",
            "parameters": {"type": "object", "properties": {
                "tag": {"type": "string", "enum": REALITY_TAGS},
                "quote": {"type": "string"}},
                "required": ["tag", "quote"]}}},
        {"type": "function", "function": {
            "name": "note_impression",
            "description": "记下用户对某个专业的第一反应。"
                           "排除理由比喜欢理由信号更强，别漏。",
            "parameters": {"type": "object", "properties": {
                "major": {"type": "string"},
                "feel": {"type": "string",
                         "enum": ["想要", "不要", "拿不准"]},
                "why": {"type": "string"}},
                "required": ["major", "feel"]}}},
        {"type": "function", "function": {
            "name": "read_mirror",
            "description": "把用户到目前为止收下/排除的卡读成一份画像，"
                           "给出「值得验证的假设 + 能马上做的小实验」。"
                           "**只在积累了几张之后调**，样本不够它会拒绝开口。",
            "parameters": {"type": "object", "properties": {}}}},
        {"type": "function", "function": {
            "name": "interview",
            "description":
                "反过来问用户「七个关于他实际做过什么的问题」，"
                "把他的回答和你手上的专业**逐维**对一遍。"
                "**这是这个产品最核心的一件事：把「他说的话」和"
                "「专业要什么」接起来，用的是同一把尺子（都是 1—5）。**"
                "用法：\n"
                "① 不填参数调一次 → 拿到还没答的题和每题的原话选项。\n"
                "② 用**他的说法**一次问一两题，别一口气倒七题。\n"
                "③ **判断他说的对应哪个选项，把这个分填进 score，"
                "同时把你依据的那句话原样填进 quote。**"
                "quote 必须是他真说过的字——代码会核对，"
                "对不上就当没听见（记「不知道」），不会用你给的分。\n"
                "他要是说「没试过」「说不好」，就把 answer 填 none，"
                "**这是合法答案，别追问、别安慰、别当成低分。**\n"
                "④ 七题答完会返回对照结果（几个对得上、几个有落差、"
                "落差具体在哪一维）。\n"
                "**必须原话说清楚：这不是测评。**它问的是承受力不是兴趣；"
                "答案是用户自己说的、没有校准；它一个字都没问家里、成绩、钱。",
            "parameters": {"type": "object", "properties": {
                "dimension": {
                    "type": "string", "enum": DIM_KEYS,
                    "description": "刚问的是哪一维。不填=看进度和剩下的题"},
                "score": {
                    "type": "integer",
                    "description": "你看他说的对应哪一档。**只能填这一维"
                                   "选项里出现过的分**，别的分不认。"},
                "quote": {
                    "type": "string",
                    "description": "你据以判分的**用户原话**（照抄，别改写）。"
                                   "代码会拿它和他真说的话核对。"},
                "answer": {
                    "type": "string",
                    "description": "他说不上来时填 none（没试过/说不好）。"
                                   "其它情况优先用 score+quote。"}}}}},
    ]


def _b(v, default=False):
    """把模型可能传的字符串转成 bool。"""
    if v is None:
        return default
    if isinstance(v, bool):
        return v
    return str(v).strip().lower() in ("true", "1", "yes", "y", "是")


# ==================================================================
# 访谈：它反过来问用户
# ==================================================================
# 【为什么不照搬牌局那套界面】
# 牌局是「七个 radio 一起摆出来」，对话版是「一句话一句话地聊」。
# 同一个访谈在这两处本来就该长得不一样——用户自己说过
# 「选择卡片只是形式之一」，形式要跟着场景走。
# 所以这里搬的不是界面，是**问题和选项本身**（在 _mirror_core.py 里，
# 两个应用共用同一套），再把「记答案」做成模型能调用的动作。
#
# 【为什么记答案要交给代码，不交给模型】
# 模型很会顺着话说，但它算不对 94 个专业的逐维比较，
# 也不该由它决定「落差」怎么算——那是可复现的东西，必须落成代码。
# 模型负责**用他的话问**；算账归这里。


def _iv_words(dim):
    """某一维的选项原话，给模型照读用。None 那条说成「没试过」。"""
    out = []
    for score, label, _reply in OPTIONS[dim]:
        out.append("没试过，说不好" if score is None else label)
    return out


_IV_PUNCT = "，。、；：？！「」『』（）()【】《》…—～~·,.;:?!\"' \t\n\r"


def _iv_norm(s):
    """归一化：去标点空格、去「我 的 了」这类对判断没用的字。

    【为什么去虚词】
    「我坐得住，能一口气看两三个小时」和选项「有，一两个通宵，缓两天就回来了」
    之间几乎没有一个实词重叠——**它们说的是同一件事，字面却完全不同。**
    所以匹配必须看**实词**，不能让「我」「的」这种字搅进来。
    """
    low = str(s or "").strip().lower()
    for p in _IV_PUNCT:
        low = low.replace(p, "")
    for w in ("我自己", "我们", "他们", "这个", "那个", "什么", "怎么",
              "的话", "感觉", "觉得", "应该", "可能", "就是", "然后",
              "其实", "反正", "不过", "但是", "而且", "因为", "所以"):
        low = low.replace(w, "")
    return low


def _iv_bigrams(s):
    """字符二元组。中文短文本比相似度，这是稳的做法。

    【为什么不用单字重合】
    原来的算法是「单字集合的重合数 ÷ min(两边集合大小)」。
    分母取 min 是**致命的**：用户输入越短越容易拿满分。
    打「代码」两个字，`min` 就是 2，只要两个都在标签里就是 1.0——
    于是随口两个字会压过所有长选项。
    二元组还有一个好处：**语序变了分数会掉**，
    而单字集合对「我打你」和「你打我」给出同样的分。
    """
    s = _iv_norm(s)
    if len(s) < 2:
        return set(s), set()
    return set(s[i:i + 2] for i in range(len(s) - 1)), set(s)


def _iv_match(dim, raw):
    """把模型给回来的回答对上选项，返回分数或 None。

    【为什么不能直接信模型】
    它可能把选项抄错一个字，也可能自作主张写个数——**它写「4」的时候，
    我们无从知道那是哪一题、按什么标准给的。**
    所以认不出来一律返回 None（=不知道）。

    【为什么现在是二元组 Dice，而不是单字重合】
    单字重合那一版，我用 15 句真人会说的话试过：**只对了 3 句。**
    「拆过家里的旧电脑，还装回去了」认不出，
    「一道题卡一星期也会接着做」也认不出——
    **因为真人的话和选项的字面本来就不一样。**
    二元组 Dice 对「同义改写、语序变化、有冗余字」都更稳。
    """
    low = str(raw or "").strip().lower()
    if low in ("none", "null", "没试过", "说不好", "不知道", "不清楚", "-"):
        return None
    a, a1 = _iv_bigrams(low)
    if not a:
        return None
    best, best_score = None, 0.0
    for score, label, _reply in OPTIONS[dim]:
        if not label:
            continue
        b, b1 = _iv_bigrams(label)
        if not b:
            continue
        dice = 2 * len(a & b) / (len(a) + len(b))
        # 单字也补一点权重：真人说话常常只重合实词，二元组对不上。
        # **权重给得低（0.25）**，免得退回成「单字乱认」那一版。
        uni = len(a1 & b1) / max(1, min(len(a1), len(b1)))
        sc = dice + 0.25 * uni
        if sc > best_score:
            best, best_score = score, sc
    # 阈值：认不出来就当「不知道」。**猜错一个分数比承认没听清严重得多。**
    if best_score < 0.42:
        return None
    return best


def _score_ok(dim, v):
    """这个分在这一维里是合法的吗？（选项之外的分一律不认）"""
    legal = [sc for sc, _l, _r in OPTIONS[dim]]
    try:
        return int(v) in legal
    except (TypeError, ValueError):
        return False


def _quote_ok(quote, said):
    """引文必须真的出现在用户说的话里。

    【这是「让模型判断」之后，唯一还拦得住它的东西】
    改成模型判分之后，代码不再有能力自己算对错——
    但它**仍然能检查模型有没有依据**。
    模型要拿一个分，就必须交回一句用户真说过的话。
    **编一个分容易，同时编出一句用户真说过的话难得多。**

    归一化之后再比：用户的原话可能有标点、语气词，
    引文可能是节选——所以按「归一化后是否是子串」判定，
    并且要求至少 2 个字，免得「我」这种一个字就过。
    """
    q = _iv_norm(quote)
    s = _iv_norm(said)
    if len(q) < 2 or not s:
        return False
    return q in s


def interview_run(args, ctx):
    """执行一次访谈调用。**答案存在 ctx 里，跨轮次累积。**"""
    args = args or {}
    ans = ctx.setdefault("iv", {})
    dim = str(args.get("dimension") or "").strip()
    raw = str(args.get("answer") or "").strip()
    score = args.get("score")
    quote = str(args.get("quote") or "").strip()

    if dim and (raw or score is not None):
        if dim not in OPTIONS:
            return {"error": f"没有「{dim}」这一维", "dimensions": DIM_KEYS}
        if dim in ans:
            return {"already": True, "dimension": dim,
                    "note": "这一维答过了。要改就直接说新的答案。"}

        # ── 两条路，**互斥** ──
        # 【为什么互斥，而不是「拒了就退回字面匹配」】
        # 第一版是：score+quote 不成立就退回 _iv_match。
        # 于是模型编了一句假引文，代码拒了它——**然后退回字面匹配，
        # 从用户真话里捞出一个分记下了。** 结果碰巧是对的，
        # 但语义错了：模型交了假依据，我却给了它一个分，
        # 而且**事后分不清「模型试了没成」和「模型没试」。**
        # 所以：给了 score 又过不了校验 → 记「不知道」并说明原因；
        # 完全没给 score（比如它老实转述了原话）→ 才走字面匹配。
        uses, why = None, None
        if score is not None:
            if not _score_ok(dim, score):
                why = f"它给的 {score} 不是这一维的合法分，不采信"
            elif not _quote_ok(quote, raw):
                why = "它给了分，但引文不在他真说的话里，不采信"
            else:
                uses = int(score)
                why = "模型判分，引文核对过了"
        else:
            uses = _iv_match(dim, raw)
            why = "没给分，按字面匹配"
        ans[dim] = uses
        ctx.setdefault("trace", []).append(("interview", f"{dim}={uses}"))
        ctx.setdefault("iv_why", []).append((dim, why, quote or raw[:40]))

    left = [d for d in DIM_KEYS if d not in ans]
    out = {"answered": len(ans), "total": 7, "answered_which": list(ans)}
    if left:
        # 【这里原来写的是 dict(ASK)[d]】
        # ASK 是 [(题目, 维度), ...]，`dict(ASK)` 是 **{题目: 维度}**——
        # 拿「认知负荷」当键去查当然 KeyError。
        # 方向搞反了：我要的是「按维度取题目」，那就是 Q_OF 反过来，
        # 而 Q_OF 本身是 {题目: 维度}，所以这里要反查。
        _q_of_dim = {dim: q for q, dim in ASK}
        out["next"] = [{"dimension": d,
                        "question": _q_of_dim[d],
                        "options": _iv_words(d)} for d in left]
        out["note"] = ("还没答完。**一次只问一两题**，用他自己的话说，"
                       "别把七题一起倒出来。"
                       "他要是说「没试过」「说不好」，就把 answer 填 none——"
                       "**这是合法答案，别追问、别当成低分。**")
        return out

    r = interview_result([ans[d] for d in DIM_KEYS], ctx["majors"])
    out["done"] = True
    out["counts"] = {"对得上": len(r["agree"]), "有落差": len(r["gap"]),
                     "证据不足": len(r["unknown"])}
    # 【名单长这一件事必须让模型知道，否则它会照着 8 个名字说得很肯定】
    # 实测：94 份画像里 35 份的「一致名单」≥20 个，最多 83 个。
    # 只给它 `agree_sample`（前 8 个）而不给这个标志，
    # 模型会说「这 8 个和你的承受力都匹配」——
    # 而真相是**他的答案宽，几乎每张牌都放得下**。
    _n_ag = len(r["agree"])
    _n_have = sum(1 for m in ctx["majors"] if m.get("dims"))
    out["long_list"] = _n_ag >= 20
    out["must_say"] = [
        "这不是「适合他」。它只说明**它要的，他都说他受得了**。",
        "它问的是承受力，不是兴趣——受得了不等于愿意干。",
        "答案是**他自己说的、没有校准**，只能当一次自我核对。",
        "**它一个字都没问他家里、成绩、钱。**",
    ]
    if out["long_list"]:
        # 【顺序：must_say 必须先建好再往里插】
        # 我第一版把 `insert(0, ...)` 写在 `must_say = [...]` 之前，
        # 那一句是 **AttributeError**，而它是每个长名单访谈都会走到的路。
        out["must_say"].insert(
            0, f"**对上 {_n_ag} 个，太多了，等于没说。**"
               f"必须直说「这不是他适合 {_n_ag} 个专业」，"
               f"是**他答的这几项确实宽**；"
               f"**不许挑几个名字出来夸匹配度高。**")
        out["note"] = (f"一致名单 {_n_ag} 个（共 {_n_have} 个有画像）。"
                       f"**别念名单**，直说它宽；"
                       f"再往下能给的不是更多名字，"
                       f"是问他愿意先试哪一张牌。")
    out["gaps"] = [{"major": m["n"],
                    "why": [f"{DIM_SHORT[i]}：它要 {dd}，他答 {aa}"
                            for i, aa, dd in gaps]}
                   for m, _n, gaps, _u in r["gap"][:8]]
    out["agree_sample"] = [m["n"] for m, *_ in r["agree"][:8]]
    return out


def run_tool(name, args, ctx):
    """执行一次工具调用。

    ctx 是一个可变 dict，装着：
      majors / by_name / occ_by_id / major_occ / mirror / notes / trace
    **所有返回值都是给模型看的纯数据**，不含任何我看不见的加工。
    """
    args = args or {}
    tr = ctx.setdefault("trace", [])

    def norm(s):
        return str(s or "").strip()

    if name == "search_majors":
        gate, kw = norm(args.get("gate")), norm(args.get("keyword"))
        lim = int(args.get("limit") or 12)
        out = []
        for m in ctx["majors"]:
            if gate and gate not in (m.get("门类") or ""):
                continue
            if kw:
                hay = " ".join(str(m.get(k) or "")
                               for k in ("n", "core_s", "weary", "suits",
                                         "car_s", "hook", "专业类"))
                if kw not in hay:
                    continue
            out.append({"name": m["n"], "gate": m.get("门类"),
                        "hook": m.get("hook"),
                        "has_dims": bool(m.get("dims"))})
            if len(out) >= lim:
                break
        tr.append(("search_majors", f"{gate}/{kw} -> {len(out)}"))
        return {"count": len(out), "majors": out}

    if name == "show_major":
        m = ctx["by_name"].get(norm(args.get("name")))
        if not m:
            return {"found": False,
                    "note": "库里没有这个专业。**如实告诉用户没有，"
                            "不要编。**"}
        ctx.setdefault("shown", []).append(m["n"])
        tr.append(("show_major", m["n"]))
        return {"found": True, "card": _card_payload(m)}

    if name == "requirements":
        m = ctx["by_name"].get(norm(args.get("name")))
        if not m:
            return {"found": False, "note": "库里没有这个专业"}
        if not m.get("dims"):
            return {"found": True, "has_profile": False,
                    "note": "这个专业**没有需求画像**（库里有 94 个有）。"
                            "如实说没有，不要推测。"}
        d = m["dims"]
        tr.append(("requirements", m["n"]))
        return {"found": True, "has_profile": True, "major": m["n"],
                "dims": {DIM_KEYS[i]: d[i] for i in range(7)},
                "dims_plain": {DIM_KEYS[i]: _plain(DIM_KEYS[i], d[i])
                               for i in range(7)},
                "cost": _cost_payload(m),
                "tier": m.get("dims_tier"),
                "tier_note": _tier_note(m.get("dims_tier"))}

    if name == "similar_majors":
        base = ctx["by_name"].get(norm(args.get("name")))
        if not base or not base.get("dims"):
            return {"found": False, "note": "没有这个专业的需求画像，"
                                            "没法比。"}
        want_most = _b(args.get("most"), True)
        pool = []
        for m in ctx["majors"]:
            if m["n"] == base["n"] or not m.get("dims"):
                continue
            dist = sum(abs(m["dims"][i] - base["dims"][i])
                       for i in range(7))
            pool.append((dist, m))
        pool.sort(key=lambda x: x[0], reverse=not want_most)
        tr.append(("similar_majors", f"{base['n']} most={want_most}"))
        return {"major": base["n"],
                "dims": {DIM_KEYS[i]: base["dims"][i] for i in range(7)},
                "most": want_most,
                "matches": [{"name": m["n"], "distance": d,
                             "dims": {DIM_KEYS[i]: m["dims"][i]
                                      for i in range(7)}}
                            for d, m in pool[:5]],
                "how_to_read":
                    "distance 越小越像。0=七项要求完全一样。"
                    "**像不等于好**——像只说明这两条路对人的要求差不多。"}

    if name == "majors_by_dimension":
        dim = norm(args.get("dimension"))
        if dim not in DIM_KEYS:
            return {"error": f"dimension 必须是 {DIM_KEYS} 之一"}
        high = _b(args.get("high"), True)
        lim = int(args.get("limit") or 10)
        i = DIM_KEYS.index(dim)
        pool = [m for m in ctx["majors"] if m.get("dims")]
        pool.sort(key=lambda m: m["dims"][i], reverse=high)
        tr.append(("majors_by_dimension", f"{dim} high={high}"))
        return {"dimension": dim, "high": high,
                "meaning": _plain(dim, 5 if high else 1),
                "majors": [{"name": m["n"], "value": m["dims"][i],
                            "dims": {DIM_KEYS[k]: m["dims"][k]
                                     for k in range(7)}}
                           for m in pool[:lim]]}

    if name == "occupations_of":
        m = ctx["by_name"].get(norm(args.get("name")))
        if not m:
            return {"found": False}
        jf = m.get("chsi_jyfx") or []
        if not jf:
            return {"found": True, "major": m["n"], "list": [],
                    "note": "官方库没登记这个专业的就业方向。"}
        tr.append(("occupations_of", m["n"]))
        return {"found": True, "major": m["n"],
                "how_many_majors_also": "n_majors 越大说明这个出口越宽"
                                        "（很多专业都能走到），"
                                        "越小说明越是这个专业的特征出口",
                "list": [{"occupation": j, **ctx["occ_majors_stat"].get(j, {})}
                         for j in jf[:14]]}

    if name == "occupation_info":
        nm = norm(args.get("name"))
        rec = ctx["occ_by_name"].get(nm)
        if not rec:
            return {"found": False,
                    "note": f"学职平台没有「{nm}」这个职业页。"
                            f"库里有的职业是："
                            f"{list(ctx['occ_by_name'])[:12]}…"}
        if norm(args.get("want")) == "majors":
            tr.append(("occupation_info", f"{nm} -> majors"))
            return {"occupation": rec.get("name"),
                    "majors": rec.get("majors"),
                    "n_majors": rec.get("n_majors"),
                    "read": "这是他这一族职业的入口专业。"
                            "**专业多不等于好进，只说明这个出口宽。**"}
        tr.append(("occupation_info", nm))
        return {"found": True, "occupation": rec.get("name"),
                "also_called": rec.get("names"),
                "industry": rec.get("industry"),
                "what_it_is": rec.get("def") or rec.get("desc"),
                "education": rec.get("edu"),
                "important_courses": rec.get("courses"),
                "courses_not_taught": rec.get("courses_missing"),
                "skills": rec.get("skills"),
                "duties": rec.get("duties"),
                "workplace": rec.get("workplace"),
                "outlook": rec.get("outlook"),
                "trend": rec.get("trend"),
                "career_path": rec.get("path"),
                "pay": {"structure": rec.get("pay_struct"),
                        "satisfaction": rec.get("pay_satis"),
                        "note": "**薪酬满意度是 1-5 分的自评，"
                                "不是钱数。学职平台没有结构化薪资数字，"
                                "不要编一个出来。**"},
                "n_majors": rec.get("n_majors"),
                "source": "学职平台 xz.chsi.com.cn（教育部学生服务与素质发展中心）"}

    if name == "student_ratings":
        m = ctx["by_name"].get(norm(args.get("name")))
        if not m:
            return {"found": False}
        sat = m.get("chsi_sat")
        out = {"found": True, "major": m["n"],
               "enrollment_scale": m.get("chsi_xsgm"),
               "gender_ratio": m.get("chsi_ratio"),
               "source": "学信网阳光高考专业库；在读学生实名投票"}
        if not sat:
            out["satisfaction"] = None
            out["why_missing"] = (
                "官方库里没有这个专业的满意度。这通常不是遗漏，"
                "而是**它太新或太小**，还没有足够多学生投过票。"
                "**要如实说成「还没被验证过」，不要说成「差」。**")
            return out
        out["satisfaction"] = {
            v["name"]: {"score": v["rank"], "votes": v["count"]}
            for v in sat["dims"].values()}
        out["total_votes"] = sat.get("total")
        out["how_to_read"] = (
            "**票数必须一起说。** 票少的时候分数波动很大，"
            "要说「样本太小」。这是**在读体验**，"
            "既不等于就业率，也不等于薪资。")
        tr.append(("student_ratings", m["n"]))
        return out

    if name == "external_ratings":
        m = ctx["by_name"].get(norm(args.get("name")))
        if not m:
            return {"found": False}
        r1, r2 = m.get("rating"), m.get("rec_index")
        if not r1 and not r2:
            return {"found": True, "major": m["n"], "ratings": [],
                    "note": "这个专业两份材料都没给评级。"
                            "**留空是对的，不许自己补一套。**"}
        tr.append(("external_ratings", m["n"]))
        return {"found": True, "major": m["n"],
                "ratings": ([{"来源": r1["src"], "kind": "别人的判断",
                              "找工作": r1["stars"]["find_job"],
                              "待遇": r1["stars"]["pay"],
                              "前景": r1["stars"]["prospect"]}]
                            if r1 else []) +
                           ([{"来源": r2["src"], "kind": "综合推荐指数",
                              "推荐指数": r2["v"]}] if r2 else []),
                "warning": "**两套口径不同，实测互相矛盾且方向两边都有**"
                           "（软件工程推荐3星/找工作5星；"
                           "汉语言文学推荐4星/找工作1星）。"
                           "**绝对不许合成一个总分。**",
                "enroll_marks": m.get("enroll")}

    if name == "sources_of_major":
        m = ctx["by_name"].get(norm(args.get("name")))
        if not m:
            return {"found": False, "note": "库里没有这个专业"}
        g = ctx.get("major_data") or {}
        off_classes = g.get("official_classes") or {}
        c2g = g.get("class2gate") or {}
        cl = m.get("专业类") or ""
        cc = next((c for c, n in off_classes.items() if n == cl), None)
        sat = m.get("chsi_sat") or {}
        rows = []
        if not (off_classes and c2g):
            # **不假定自己拿得到这份对照表**。拿不到就直说，
            # 不能默默降级成「待核」——那会把官方的说成没核实的。
            rows.append({"项目": "分类·代码·学位", "等级": "未能核对",
                         "来源": "这次没拿到官方目录对照表，无法确认"})
        elif cc and c2g.get(cc):
            # 不写年份：数据里的出处是「教育部《普通高等学校本科专业目录》」，
            # 本身不带年份。我上一轮擅自写成「（2026年）」——
            # **那是我自己加的一个说法，数据里没有依据。**
            rows.append({"项目": "分类·代码·学位", "等级": "官方",
                         "来源": "教育部《普通高等学校本科专业目录》"
                                 "（门类 · 专业类 · 专业代码）"})
        else:
            rows.append({"项目": "分类", "等级": "待核",
                         "来源": "这个专业类不在官方目录对照表里"})
        if m.get("chsi_jyfx"):
            rows.append({"项目": "就业方向", "等级": "官方",
                         "来源": "学职平台 xz.chsi.com.cn"})
        elif m.get("car"):
            # 【「整理」这一份也要出一行】
            # 牌局那边已经改成按**实际用的是哪一份**出行了，这边原来没有。
            # 那 16 个官方零记录的新专业，卡片上明明列着出路，
            # 来源里却一个字都不提——等于让人信一句没署名的话。
            rows.append({"项目": "就业方向", "等级": "整理·不是官方登记",
                         "来源": "库里自己整理的，官方职业库查不到这个专业"})
        # ── 出口详情这一行原来没有 ──
        # 卡片上那一页内容最多（学历要求、重要课程、上升路径、薪酬结构、
        # 薪酬满意度），来源却一个字都没写；而**牌局那边的来源页里是有的**。
        # 同一张卡在两处给出不同的出处，用户会怀疑哪边在骗他。
        #
        # 【别用 `_occ_lookup` / `NOT_JOBS`】
        # 那两个名字在 `_majors_src.py` 里，工具层没有——
        # 直接写会 NameError，而 `sources_of_major` 只在被调用时才炸，
        # 单测不碰它就一路绿灯。工具层这边自己的入口是
        # `ctx["occ_by_name"]`。
        _obn = ctx.get("occ_by_name") or {}
        _items = m.get("chsi_jyfx") or list(m.get("car") or [])
        _n_occ = len([j for j in _items
                      if j not in NOT_JOBS and _obn.get(j)])
        if _n_occ:
            # 【项目名必须和牌局一个字都不差】
            # 牌局那边叫「出口详情」。这边原来叫
            # 「出口详情（学历·重要课程·上升路径·薪酬结构·薪酬满意度）」——
            # 同一个项目在两个应用里叫两个名字，**并排看就是两行不同的东西**。
            # 详细说明放进「来源」，项目名保持和牌局一致。
            rows.append({"项目": "出口详情", "等级": "官方·从业者/官方整理",
                         "来源": f"学职平台职业页 xz.chsi.com.cn"
                                 f"（{_n_occ} 个职业，每个都带职业页 ID）："
                                 "学历·重要课程·上升路径·薪酬结构·"
                                 "薪酬满意度。**薪酬满意度是自评，不是钱数**"})
        # 在校生规模：牌局有，这边原来漏了（157 个专业）。
        # 来源和四维满意度同一处——官方专业库的同一页。
        if m.get("chsi_xsgm"):
            rows.append({"项目": "在校生规模", "等级": "官方",
                         "来源": "学信网阳光高考专业库（同上）"})
        if sat:
            n = sat.get("total") or 0
            rows.append({"项目": "四维满意度", "等级": "官方·学生自评",
                         "来源": f"学信网实名投票，{n} 票"
                                 + ("（票少，仅供参考）" if n < 300 else "")})
        if m.get("rating"):
            rows.append({"项目": "三维星级", "等级": "个人判断·不是数据",
                         "来源": m["rating"].get("src")})
        if m.get("rec_index"):
            rows.append({"项目": "推荐指数", "等级": "个人判断·不是数据",
                         "来源": m["rec_index"].get("src")})
        if m.get("dims"):
            rows.append({"项目": "7 维需求画像",
                         "等级": "访谈核实" if m.get("dims_tier") == "C1"
                                 else "公开资料推",
                         "来源": "志业镜原库"})
        if m.get("cost_hours"):
            rows.append({"项目": "代价数字",
                         "等级": "模板值·别当准数"
                                 if m.get("cost_templated") else "访谈核实",
                         "来源": "同批数挤在同一个值上"
                                 if m.get("cost_templated") else "逐个核实"})
        tr.append(("sources_of_major", m["n"]))
        return {"major": m["n"], "rows": rows,
                "read": "等级从高到低：官方 → 官方·学生自评 → 访谈核实 → "
                        "公开资料推 → 个人判断 → 模板值。"}

    if name == "lookup_unavailable":
        nm = norm(args.get("name"))
        in_major = nm in ctx["by_name"]
        near = [x["n"] for x in ctx["majors"]
                if nm and (nm in x["n"] or x["n"] in nm)][:5]
        in_occ = nm in ctx["occ_by_name"]
        tr.append(("lookup_unavailable", f"{nm} major={in_major}"))
        out = {"query": nm, "is_major": in_major, "is_occupation": in_occ,
               "maybe_meant": near}
        # ── 查官方目录（883 个）──
        # 【为什么必须有这一步】
        # 「我库里没有」和「这个专业不存在」是两件完全不同的事。
        # 用户问「世界语」：我库里没这张牌，但教育部目录里**真有**，
        # 说成「没有」就是在给他错的信息。
        # 这一步只答**官方目录上印着的四个字段**，其余一个字都不编——
        # 「学什么」「代价多少」「出口在哪」没材料就不说。
        #
        # 【目录可能根本不在】
        # 目录是界面层内联进来的。工具层被单独拿去跑（比如测试）时，
        # 它就不存在——**那时候要说「我没法核」，不能崩，也不能
        # 假装自己核过了。** 「查不到」和「没查」是两件事。
        cat = ctx.get("cat_major") or globals().get("CAT_MAJOR") or {}
        cls_tab = ctx.get("cat_class") or globals().get("CAT_CLASS") or {}
        if not cat:
            out["rule"] = ("**我手上没有官方目录，这一条核不了。**"
                           "别猜它存不存在——直接说核不了。")
            return out
        row = cat.get(nm)
        if row:
            gate, cls, code, zymyd = (list(row) + [None] * 4)[:4]
            out["in_official_catalog"] = True
            out["official"] = {
                "门类": gate, "专业类": cls, "专业代码": code,
                "官方满意度": ("目录里有这一栏，但没有票数"
                               if not zymyd or float(zymyd or 0) == 0
                               else f"{zymyd}/5（在读学生实名投票）"),
            }
            # 【有牌和没牌，规矩完全不同】
            # 第一版这里只有一句话「我没把它做成牌」，
            # 而「软件工程」**是有牌的**——返回里 is_major=True、
            # rule 却说「我没做成牌」，自相矛盾。
            # 所以这里分开写：有牌就让他直接看牌，别绕。
            if in_major:
                out["rule"] = (
                    "**我库里有这张牌**，而且它也在官方目录里。"
                    "直接调 show_major 给他看牌——"
                    "上面那四个官方字段只是核对用的，别拿它当牌讲。")
            else:
                # ── 它所属的专业类，有没有「同源出口」可以给你？ ──
                # 【为什么这一步能加，而「拿别的专业去套」不能】
                # 没做牌的 722 个专业，原来「出口在哪」一个字都没有。
                # 但材料其实在手边——只是它是**有牌的 161 个**的。
                # 差别在于有没有量过：
                #   机械类 5 个专业的官方就业方向**完全一样**
                #     （机械工程师/机械设计师/机械设备工程师）
                #   工商管理类 6 个专业 **6 种**
                # 所以门槛是算出来的（≥75% 且类内 ≥3 个专业），
                # 写在装配器里，不是我在这里挑几个看起来像的类。
                # 放出来的 12 个类，同源出口全是**特征出口**
                # （法务/律师、机械工程师、内科/外科医生、建筑设计师），
                # 不是「公务员/教师」那种通用去向凑出来的。
                cls_exit = ctx.get("cls_exit") or globals().get(
                    "CLS_EXIT") or {}
                _ce = cls_exit.get(cls)
                if _ce:
                    out["class_exit"] = _ce["方向"]
                    # 【等级必须比「官方」低一档，而且要写在数据里】
                    # 这几条不是「{nm}」这个专业的官方就业方向，
                    # 是**同类的别的专业**的。学职平台没有为它登记过。
                    # 靠一句提示词去提醒模型「记得打折」是不可靠的——
                    # 所以等级直接写在返回值里，模型就算不提醒，
                    # 这一行也带着「类级代理」四个字。
                    out["class_exit_src"] = {
                        "等级": "官方·类级代理（不是这个专业自己的）",
                        "来源": f"学职平台：{cls} 下有官方就业方向的 "
                                f"{_ce['该类有数据的专业数']} 个专业里，"
                                f"{_ce['同类专业数']} 个是同几条"
                                f"（门槛 ≥75% 由数据算出来，不是挑的）",
                    }
                    out["rule"] = (
                        f"**它在官方目录里，但我没把它做成牌。**"
                        f"这四个字段是官方的，可以照说。"
                        f"另外「{cls}」这一类有 {_ce['该类有数据的专业数']} 个"
                        f"专业在学职平台登记了就业方向，其中 "
                        f"{_ce['同类专业数']} 个是同几条——所以"
                        f"`class_exit` 是**这一类的**典型出口，"
                        f"**不是「{nm}」单独的**。"
                        f"必须说清这一点，再说那几条。"
                        f"**别把它说成「官方给这个专业登记的方向」**——"
                        f"官方没有登记过它。"
                        f"「学什么」「代价多少」**我都没有材料，"
                        f"没有材料就不说**。")
                else:
                    # 找不到同源出口时，能给的最有用的一句话是
                    # **「这一类里我有哪几个是有牌的」**——
                    # 那是他能马上点开看的东西，比一串通用去向实在。
                    sibs = [x["n"] for x in ctx["majors"]
                            if x.get("专业类") == cls]
                    out["rule"] = (
                        "**它在官方目录里，但我没把它做成牌。**"
                        "这四个字段是官方的，可以照说。"
                        "「学什么」「代价多少」「出口在哪」**我都没有材料——"
                        "没有材料就不说**，别用别的专业的去套。"
                        + (f"这一类的牌我只有 {'、'.join(sibs[:6])}，"
                           f"那是**别的专业**，不能套到它头上；"
                           f"但可以让他去看那几张，比空说有用。"
                           if sibs else
                           "这一类我一张牌都没做。")
                        + "想看得更细：学信网阳光高考专业库能查到它。")
            return out
        if nm in cls_tab:
            gate, n = cls_tab[nm]
            kids = [x["n"] for x in ctx["majors"] if x.get("专业类") == nm]
            out["is_official_class"] = True
            out["official"] = {"门类": gate, "下面有专业数": n}
            out["note"] = (
                f"「{nm}」不是一个专业，是一个**专业类**，属于 {gate} 门类，"
                f"下面有 {n} 个专业。"
                + (f"牌堆里有：{'、'.join(kids[:12])}。" if kids else ""))
            return out
        out["in_official_catalog"] = False
        out["rule"] = (
            "**教育部《本科专业目录》里没有这个名字。**"
            "没有就说没有——**不许用相似的凑，也不许凭常识补。**"
            "可以说「我库里和官方目录里都没有，"
            "但我可以陪你想想怎么去查」。"
            "（研究生方向、专科专业、企业岗位名都不在这份目录里，"
            "所以也可能只是名字对不上。）")
        return out

    if name == "remember_about_person":
        tag, q = norm(args.get("tag")), norm(args.get("quote"))
        if tag not in SELF_TAGS:
            return {"error": f"tag 必须是 {SELF_TAGS} 之一"}
        ctx.setdefault("self_notes", []).append({"tag": tag, "quote": q})
        tr.append(("remember_self", tag))
        return {"ok": True, "remembered": {"tag": tag, "quote": q},
                "n_self": len(ctx["self_notes"])}

    if name == "remember_reality":
        tag, q = norm(args.get("tag")), norm(args.get("quote"))
        if tag not in REALITY_TAGS:
            return {"error": f"tag 必须是 {REALITY_TAGS} 之一"}
        ctx.setdefault("reality_notes", []).append({"tag": tag, "quote": q})
        tr.append(("remember_reality", tag))
        return {"ok": True, "remembered": {"tag": tag, "quote": q},
                "limit": "**这只是现实条件。**它只能用来谈可行性和"
                         "时间表，**不能用来判断他适合什么。**"
                         "别把它写进任何「你这个人」的结论里。"}

    if name == "note_impression":
        mj = norm(args.get("major"))
        feel = norm(args.get("feel"))
        if mj not in ctx["by_name"]:
            return {"error": f"库里没有「{mj}」"}
        ctx.setdefault("impressions", []).append(
            {"major": mj, "feel": feel, "why": norm(args.get("why"))})
        tr.append(("note_impression", f"{mj}={feel}"))
        return {"ok": True, "n_impressions": len(ctx["impressions"])}

    if name == "read_mirror":
        # 由界面注入的 mirror 函数负责——这样工具层不依赖界面
        fn = ctx.get("mirror_fn")
        if not fn:
            return {"enough": False, "why": "还没法读镜像。"}
        tr.append(("read_mirror", ""))
        return fn()

    if name == "interview":
        return interview_run(args, ctx)

    return {"error": f"没有这个工具：{name}"}


def _plain(dim, v):
    """把分数说成人话。**数字给机器，这句话给人。**"""
    from _mirror_core import DIM_PLAIN
    low = {0: "完全不要求", 1: "要求很低", 2: "要求不高", 3: "有一定要求",
           4: "要求较高", 5: "要求很高"}
    return f"{DIM_PLAIN.get(dim, dim)}（{low.get(v, v)}）"


def _tier_note(t):
    return {"C1": "这一份是逐个访谈核实过的",
            "C2": "这一份是从公开资料整理的，**没有逐一核实**",
            None: "来源等级未知"}.get(t, "来源等级未知")


def _cost_payload(m):
    tpl = m.get("cost_templated")
    d = {"hours_per_week": m.get("cost_hours"),
         "years_to_competence": m.get("cost_years"),
         "months_to_first_feedback": m.get("cost_feedback_months"),
         "can_turn_back": m.get("cost_reversible"),
         "note": m.get("cost_note")}
    if tpl:
        d["reliability"] = (
            "**这批代价数字是模板推的，不是逐个量出来的，别当准数说。**"
            "同批 88 个专业里反馈月数有 56 个都是 7、年份 49 个都是 5——"
            "真量出来的数不会这么齐。只有 6 个专业"
            "（建筑学/临床医学/计算机科学与技术/数学与应用数学/"
            "电气工程及其自动化/应用心理学）是逐个访谈核实的。")
        d["is_templated"] = True
    else:
        d["reliability"] = "逐个访谈核实过的"
        d["is_templated"] = False
    return d


def _card_payload(m):
    """卡片的数据版（给模型看），不是界面版。"""
    return {"name": m["n"], "gate": m.get("门类"),
            "class": m.get("专业类"), "degree": m.get("学位"),
            "years": m.get("years"), "hook": m.get("hook"),
            "what_you_study": m.get("core_s"),
            "cost_plain": m.get("weary"),
            "who_fits": m.get("suits"),
            "why_worth_it": m.get("fun"),
            "one_thing_to_try_this_afternoon": m.get("act_s"),
            "has_requirement_profile": bool(m.get("dims")),
            "has_official_data": bool(m.get("chsi_sat")
                                      or m.get("chsi_jyfx"))}
