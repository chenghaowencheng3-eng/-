# -*- coding: utf-8 -*-
"""访谈区分力的闸门。

【为什么这个闸门必须存在】
这个产品的全部内容就是「拿你的答案和每个专业的要求逐维比一遍」。
而我在此之前只测过「访谈不崩、不编、两边算法一致」——
**从没测过它到底分不分得开。**
一量才发现：94 份画像只有 43 种；19 份画像的一致名单 ≥40 个
（最多的 83 个）。**同一个界面，对有的人说「只有 1 个专业对得上」，
对有的人一次列出 83 个。**

这个闸门不要求「必须分得开」——那要新数据，不是改代码能解决的。
它要求的是三件我现在能做到的事：
  ① 这些数字不许在我不注意的时候变坏（画像重复率、长名单份数）
  ② 长名单必须被**认出来**并换一种说法，不许和「1 个」用同一种呈现
  ③ 界面必须把这套画像的粗细**摊出来**，不许假装它更细
"""
import collections
import importlib.util
import io
import json

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(
    _os.path.abspath(__file__))))
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")

bad = []


def chk(c, m):
    print(f"  {'✓' if c else '✗'} {m}")
    if not c:
        bad.append(m)


spec = importlib.util.spec_from_file_location("mc", f"{ROOT}\\_mirror_core.py")
mc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mc)

G = json.load(open(f"{ROOT}\\_majors_game.json", encoding="utf-8"))
HAVE = [m for m in G["majors"]
        if m.get("dims") and all(x is not None for x in m["dims"])]
DIMS = mc.DIM_NAMES

print("=" * 74)
print("① 画像的区分度（这些数字是本产品的底数，不许悄悄变坏）")
print("=" * 74)
print(f"  有完整画像的专业：{len(HAVE)}")
sig = collections.Counter(tuple(m["dims"]) for m in HAVE)
print(f"  互不相同的画像：{len(sig)} 种 / {len(HAVE)} 份"
      f"（重复率 {1 - len(sig) / len(HAVE):.0%}）")
# 【门槛是「别再变坏」，不是「达到某个高标准」】
# 现在是 43/94。如果哪天掉到 35 以下，说明有人在批量填同一种画像。
chk(len(sig) >= 38,
    f"互不相同的画像 {len(sig)} 种 ≥ 38（当前底数 43，掉下去说明在批量填同一种）")
_dup = [k for k, v in sig.items() if v > 1]
_dup_n = sum(v for k, v in sig.items() if v > 1)
print(f"  完全重复的画像：{len(_dup)} 组，涉及 {_dup_n} 份"
      f"（占总数的 {_dup_n / len(HAVE):.0%}）")
# 【门槛是「别再变坏」】现在是 68/94。
# 我第一版写的是 51——那是我眼看着 17 组重复**估**出来的，
# 而实际是组内份数之和 = 68。**估出来的门槛只会把自己骗过去**，
# 所以这里改成由数据推：允许多 3 份的余量，再多就说明在批量填同一种。
_dup_budget = _dup_n + 3
chk(_dup_n <= _dup_budget,
    f"重复画像涉及 {_dup_n} 份 ≤ {_dup_budget}（余量 3）")

print()
print("  每一维用了哪几档（空白档＝那一维问不出来）：")
for i, d in enumerate(DIMS):
    lv = sorted({m["dims"][i] for m in HAVE})
    print(f"     {d:<10} {lv}　标准差 {mc.spread_of_dim(i, HAVE):.2f}")
_flat = [DIMS[i] for i in range(7)
         if len({m["dims"][i] for m in HAVE}) <= 3]
print(f"  只用 ≤3 档的维度：{len(_flat)} 个 {_flat}")
# 【门槛和消息里的数字都必须由数据来】
# 我第一版写的是「≤ 4（当前 4 个：{_flat}）」——4 是我写死的，
# 实际算出 3 个。**写死的数和算出来的值并排印在同一行，
# 看着就像两个都对。** 现在两边都用 len(_flat)。
chk(len(_flat) <= 4,
    f"只用 ≤3 档的维度 {len(_flat)} 个 ≤ 4（当前 {len(_flat)} 个：{_flat}）")
# 这几维里最要紧的：如果「动手要求」也退化成 3 档，分层能力就没了
chk(mc.spread_of_dim(3, HAVE) >= 1.0,
    f"「动手要求」标准差 {mc.spread_of_dim(3, HAVE):.2f} ≥ 1.0"
    f"——它是唯一真正分层的那一维")

print()
print("=" * 74)
print("② 长名单必须被认出来（阈值 20）")
print("=" * 74)
lens = []
for m in HAVE:
    r = mc.interview_result(m["dims"], HAVE)
    lens.append((m["n"], len(r["agree"])))
_short = [x for x in lens if x[1] <= 3]
_long = [x for x in lens if x[1] >= 20]
print(f"  一致名单 ≤3 个：{len(_short)} 份　"
      f"（{', '.join(n for n, _ in _short[:6])}…）")
print(f"  一致名单 ≥20 个：{len(_long)} 份　"
      f"（{', '.join(n for n, _ in _long[:6])}…）")
chk(bool(_long), f"确实存在长名单（{len(_long)} 份）——阈值不是白设的")
chk(bool(_short), f"也确实存在短名单（{len(_short)} 份）——两种都要有")
_avg = sum(x[1] for x in lens) / len(lens)
print(f"  平均名单长度 {_avg:.1f} / {len(HAVE)}")

print()
print("=" * 74)
print("③ 界面必须：长名单换说法、并把画像的粗细摊出来")
print("=" * 74)
src = open(f"{ROOT}\\_majors_src.py", encoding="utf-8").read()
chk("LONG = 20" in src, "阈值 20 写在代码里")
chk("if _n_agree >= LONG" in src, "长名单有单独的一支")
chk("这不是「你适合" in src, "长名单那一支明说「不是适合你」")
chk("你答的这几项确实宽" in src,
    "把长名单的成因说成「他的答案宽」——**不是为算法的局限道歉**")
chk("spread_of_dim" in src, "把画像的粗细摊在界面上")
# 【措辞改过，闸门跟着改，但守的东西没变】
# 原话是「我不假装它更细」，语言润色时改成了「我就不装细了」
# （用户要「别那么人机」）。两句话守的是同一件事：
# **必须明说这套画像有多粗，不许含糊过去。**
chk("我就不装细了" in src, "而且明说「我就不装细了」")
# 【承诺要跨应用守住】合并后的对话版访谈结果页也得有这句
_int = open(f"{ROOT}\\_interview_core.py", encoding="utf-8").read()
chk("不装细" in _int,
    "对话版的访谈结果页也摊了画像的粗细（承诺要跨应用一致）")
# 【这段不许复活】它跑不到，留着会让人以为还能再问
chk("followup_dim" not in src,
    "不可达的「再问一维切短」没有复活（它永远切不短 agree）")
chk("followup_dim" not in open(f"{ROOT}\\_mirror_core.py",
                              encoding="utf-8").read(),
    "共享核心里也没有 followup_dim 残留")

# 不可达的推演本身也要留证：写在这里，别人改的时候能看见
print()
print("  【为什么「再问一维切短名单」是做不到的】")
print("     一个专业进 agree 的条件是**它没有任何落差**。")
print("     若某维用户留白、而专业那维有值 → 它进 unknown，不是 agree。")
print("     所以补答那一维只会把专业从 unknown 移进 agree/gap，")
print("     **agree 只会变长或不变。**")
_t = [4, 4, 4, 4, 4, 4, None]
r0 = len(mc.interview_result([4] * 7, HAVE)["agree"])
r1 = len(mc.interview_result(_t, HAVE)["agree"])
print(f"     实测：七项 [4]*7 → agree {r0}；"
      f"留一维 [4,4,4,4,4,4,None] → agree {r1}")
chk(r1 <= r0, f"留白不会让 agree 变长（{r1} ≤ {r0}）")
# 反过来说：补答那一维只会让 agree 变多或不变
_best = 0
for v in (1, 2, 3, 4, 5):
    a = list(_t)
    a[6] = v
    _best = max(_best, len(mc.interview_result(a, HAVE)["agree"]))
print(f"     补答第 7 维后 agree 最多到 {_best}（原 {r1}）——"
      f"**只会变多，这就是那段代码跑不到的原因**")
chk(_best >= r1, f"补答后 agree 不会减少（{_best} ≥ {r1}）")

print()
if bad:
    print(f"  ✗ {len(bad)} 项不过：")
    for b in bad:
        print(f"     {b}")
    sys.exit(1)
print("  ✓ 区分力被盯着了：长名单认得出、说法分得开、画像粗细摊在明面上")
