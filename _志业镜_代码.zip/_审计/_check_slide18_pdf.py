# -*- coding: utf-8 -*-
"""第 18 页（访谈页）渲染出来后，印的确实是那几个字和那几个数。"""
import io
import sys

# ── 自举：缺库就换解释器重跑 ──────────────────────────────────
# 【必须在需要那些库的 import **之前**】
# 我上一版把它插在「最后一个顶层 import 之后」——
# 而 `import pypdfium2` 本身就是最后一个顶层 import，
# 于是自举还没跑，ModuleNotFoundError 已经抛了。
_NEEDS = ['pypdfium2']
# 【`importlib.util` 必须显式 import】
# `find_spec` 在 `importlib.util` 里，而 `import importlib` **不会**
# 自动带上它——直接 `__import__("importlib").util` 会 AttributeError。
import importlib.util as _ilu
# 【`os` 也要自己来】这段插在文件最前面，那时 `os` 还没被 import。
import os
_MISSING = [m for m in _NEEDS if _ilu.find_spec(m) is None]
if _MISSING:
    _RUNTIME = r"C:\Users\Lenovo\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe"
    if (os.path.abspath(sys.executable).lower()
            != os.path.abspath(_RUNTIME).lower()
            and os.path.exists(_RUNTIME)):
        print(f"  换成有 {_MISSING} 的解释器重跑……")
        os.execv(_RUNTIME, [_RUNTIME] + sys.argv)
        raise SystemExit(1)
    print(f"  ✗ 两个解释器都没有 {_MISSING}")
    raise SystemExit(1)
# ──────────────────────────────────────────────────────────────






sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")

import re

import pypdfium2 as pdfium

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
# 【路径要写绝对】上面的自举会**换解释器重跑**，
# 那个进程的工作目录不保证就是本目录——相对路径会时灵时不灵。
pdf = pdfium.PdfDocument(
    os.path.join(ROOT, "_out/志业镜_课堂展示.pdf"))
print(f"PDF 共 {len(pdf)} 页")
_raw = pdf[17].get_textpage().get_text_range()


def norm(s):
    """去掉所有空白再比。

    【为什么必须归一化】
    原来的断言是 `"有落差的：3 个" in t`——而 PDF 实际抽出来的是
    `"有落差的： 3 个"`（数字左侧多一个空格），
    以及 `"它要 5 ，你答 4"`（数字和逗号之间多一个空格）。
    内容一个字不差，是**渲染器在数字/字母两侧插了空格**。

    按渲染器的空格习惯写断言，是给自己埋雷：
    字体、字号、换行一改就报假红，而真错了反倒可能被空格凑巧掩盖。
    **比字，不比空白。**
    """
    return re.sub(r"\s+", "", s or "")


t = norm(_raw)
print(f"第 18 页 {len(_raw)} 字（去空白后 {len(t)}）")
print()
bad = []
for kw in ("反过来问你",
           "七个问题（都问做过的事，不问偏好）",
           "你为了一个东西，最长连着熬了多久",
           "91 个", "有落差的：3 个",
           "计算机科学与技术", "数学与应用数学", "哲学",
           "它要 5，你答 4",
           "这一层不是测评", "没有校准", "一个字都没问你家里",
           # 这一轮新加的那句：对话版怎么判分
           "对话版里得听懂他的话",
           "交回一句你真说过的话",
           "改写过的、编的，一律记「不知道」"):
    ok = norm(kw) in t
    print(f"   {'OK' if ok else '缺'}  「{kw}」")
    if not ok:
        bad.append(kw)

# 反向核对：这一页不该出现别页的内容
print()
for kw in ("一张牌上有什么", "代价对比", "每一个数字的出处"):
    if norm(kw) in t:
        bad.append(("不该出现", kw))
        print(f"   混进了别页的内容：「{kw}」")

# 这一页也不该留下没解析的 markdown 记号
if "**" in _raw:
    bad.append(("印出了星号", "**"))
    print("   ✗ 这一页印出了 `**`")

print()
print("  ✓ 第 18 页印的字都核对上了" if not bad else f"  ✗ {bad}")
