# -*- coding: utf-8 -*-
"""验「开场每次都换」在**跨刷新**时真的成立。

【为什么要单独验这一条】
我第一版把「上次用的第几条」存在 `session_state` 里，
而浏览器每刷新一次就是新会话——`session_state` 每次都是空的，
于是永远停在第 1 条。**「每次换一条」等于没做。**
这种错不会报任何错，只是行为静默地退化成原来的样子。
所以必须**真的连开两次会话**去看，不能只看代码。

AppTest 每 `from_file` 一次就是一个新会话，正好能模拟「换一次浏览器」。
"""
import io

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(
    _os.path.abspath(__file__))))
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")

APP = os.path.join(ROOT, "志业镜.py")

# 【记号文件在哪儿，要问产品，不能自己拼】
# 原来这里写的是 `os.path.join(ROOT, "_开场记号.txt")`：
# 我假设它和源码放在一起。**这个假设在传云上那天就不成立了**——
# 云上的仓库目录是只读的，产品改成去临时目录写记号
# （见 `_mark_dir.py`），于是这条闸门找不到那个文件，
# 报「记号文件写出来了 ✗」。**它红的原因不是功能坏了，是我把路径猜错了。**
#
# 改法：读产品源码里那段定位逻辑，跑一遍，问它到底写哪儿。
sys.path.insert(0, ROOT)
from _mark_dir import mark_path_of_assembled as _mark_path   # noqa: E402

MARK = _mark_path(APP)

sys.path.insert(0, ROOT)
from streamlit.testing.v1 import AppTest                        # noqa: E402

bad = []


def chk(c, m):
    print(f"  {'✓' if c else '✗'} {m}")
    if not c:
        bad.append(m)


def first_line_of_opening():
    """开一次全新会话，取它开场白的头一行。

    【为什么每轮都要 `AppTest.from_file`，而不是复用同一个再 `run()`】
    我为此单独做过一个最小实验（探针应用里 `session_state.n += 1`）：

        同一个 AppTest 反复 run() → n = 1, 2, 3   ← **会累积**
        每轮新建一个 AppTest     → n = 1, 1, 1   ← 干净

    也就是说：**`run()` 不是「新开一局」**，它只重跑脚本、
    不清 `session_state`。而开场段外面有 `if not opening_done` 这道守卫，
    所以复用实例的话，第 2..8 轮**根本进不了那段**——
    测出来永远是同一条，然后我就会去改一段没坏的代码。
    新建实例才等价于「新来一个人 / 浏览器新开一页」。
    """
    at = AppTest.from_file(APP, default_timeout=300)
    at.run()
    exc = list(at.exception) if at.exception is not None else []
    if exc:
        return None, f"首屏异常：{str(getattr(exc[0], 'value', exc[0]))[:200]}"
    for e in (at.markdown or []):
        v = getattr(e, "value", "") or ""
        if "我先说我这儿有什么" in v or "来了。" in v \
                or "不用自我介绍" in v or "你先说，或者先别说" in v \
                or "你要是已经有个大概方向" in v or "不聊大道理" in v:
            return v.strip().split("\n")[0][:40], None
    return None, "这一屏里没找到开场白"


# 【先把记号清掉】不然「第一次」取决于上一次跑测试留下的状态
if MARK and os.path.exists(MARK):
    os.remove(MARK)

print("  连开 8 次全新会话（每次都是一个新浏览器），看开场换不换：")
if MARK is None:
    chk(False, "问不出记号文件在哪儿——定位逻辑在产物里找不到了")
seen = []
for k in range(8):
    head, err = first_line_of_opening()
    if err:
        chk(False, f"第 {k + 1} 次：{err}")
        break
    seen.append(head)
    print(f"    第 {k + 1} 次：{head}")

if len(seen) == 8:
    chk(len(set(seen)) == 6, f"8 次里出现了 {len(set(seen))} 种（应为 6）")
    chk(all(seen[i] != seen[i + 1] for i in range(len(seen) - 1)),
        "相邻两次没有一次是重样的")
    chk(seen[5] == seen[0] or seen[6] == seen[0] or seen[6] == seen[1],
        "第 7 次开始回到第 1 条（转了一圈）")
    chk(MARK is not None and os.path.exists(MARK),
        f"记号文件写出来了（{MARK}）")
    if MARK and os.path.exists(MARK):
        _v = open(MARK, encoding="ascii").read().strip()
        chk(_v.isdigit(), f"记号文件里只有一个整数（读出来是 {_v!r}）")

print()
if bad:
    print(f"  ✗ {len(bad)} 项不过：{bad}")
    raise SystemExit(1)
print("  ✓ 开场每次都换，跨刷新也成立")
