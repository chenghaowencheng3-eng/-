# -*- coding: utf-8 -*-
"""核对新加那一页（第 18 页）上的数字是不是真的。

【为什么要核】
那一页上的「91 个」「3 个」「只有三个专业这一项要 5 分」
是我从一次 AppTest 运行的输出里抄过来的。
**抄来的数字没人核，而 PPT 上的数字最容易被追问。**
所以这里用同一组答案重算一遍，并检查 PDF 里印的确实是这几个数。
"""
import io

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(
    _os.path.abspath(__file__))))
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")

sys.path.insert(0, ROOT)
import _majors_src_loader as _L                                  # noqa: E402
# 【数据从加载器来，不自己 exec 源码】
# 源码里是 `__MAJOR_DATA__` 这类占位符，直接 exec 会 JSONDecodeError。
# 加载器先让组装器拼好，再切断界面。
NS = _L.load()

# 第 18 页上写的那组答案：认知负荷答 4，其余答满
ANS = [4, 5, 5, 5, 5, 5, 5]
# 【必须显式传专业名单】见 `_mirror_core.interview_result` 里的说明
r = NS["interview_result"](ANS, NS["MAJORS"])
DIM_NAMES = NS["DIM_NAMES"]
print(f"认知负荷那一项答 {ANS[0]}/5")
print(f"一致 {len(r['agree'])}　落差 {len(r['gap'])}　"
      f"证据不足 {len(r['unknown'])}")
print()
print("落差的全部：")
for m, n, gaps, _ in r["gap"]:
    print(f"   {m['n']:20} " + "；".join(
        f"{DIM_NAMES[i]} 它要 {dd}，你答 {aa}" for i, aa, dd in gaps))

# 第 18 页写的是「只有三个专业这一项要 5 分」
_M5 = [m["n"] for m in NS["MAJORS"]
       if m.get("dims") and m["dims"][0] == 5]
print()
print(f"认知负荷要 5 分的专业：{len(_M5)} 个 → {_M5}")

# 逐条对稿子上印的字
PRINTED = {"一致": 91, "落差": 3, "要5分": 3}
CHECKS = [
    ("一致 91 个", len(r["agree"]) == PRINTED["一致"], len(r["agree"])),
    ("落差 3 个", len(r["gap"]) == PRINTED["落差"], len(r["gap"])),
    ("这一项要 5 分的是 3 个", len(_M5) == PRINTED["要5分"], len(_M5)),
]
print()
ok = True
for name, good, actual in CHECKS:
    print(f"   {'✓' if good else '✗'} {name}（实际 {actual}）")
    ok = ok and good

# PDF 里印的确实是不是这几个数
print()
try:
    import pypdfium2 as pdfium
    pdf = pdfium.PdfDocument("_out/志业镜_课堂展示.pdf")
    pg = pdf[17]
    txt = pg.get_textpage().get_text_range()
    print("第 18 页渲染出的文字里含：")
    for kw in ("91 个", "3 个", "它要 5，你答 4", "反过来问你"):
        print(f"   {'✓' if kw in txt else '✗'} 「{kw}」")
        ok = ok and (kw in txt)
except Exception as e:
    print(f"   （PDF 还没重渲，跳过：{type(e).__name__}）")

print()
print("  ✓ 第 18 页的数字全部对得上" if ok else "  ✗ 有数字对不上")
