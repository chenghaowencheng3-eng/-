# -*- coding: utf-8 -*-
"""撞到「不替你选」那道墙之后，**必须真的有东西端上来**。

【这个闸门守的是什么】
用户原话：「那个所谓的不帮你做选择的越界问题很容易，使聊天变死，
我希望你能在避免引导做决定的同时，积极开拓出新的内容」。

改之前撞墙的处理是一句「要不要我陪你把这两条路摆开看看？」——
客气，但**球被丢回给用户了**，他什么都没得到。这就是「聊天变死」。

所以这里验三件事：
  ① 撞墙之后端上来的东西**不是空的**，里面有真事实（数字/分数）
  ② 端上来的东西**还是中性的**——不许趁机变成「所以它更适合你」
  ③ 换的角度**会轮换**，不能变成新的复读机
"""
import io
import os
import re

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(
    _os.path.abspath(__file__))))
sys.path.insert(0, ROOT)
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")

import _majors_src_loader as L                                   # noqa: E402

# `_angle_shift` 活在对话版里，不在牌局源文件里。
# 它要 `BY_NAME` / `summary_data` / `DIM_NAMES` / `DIM_PLAIN` / `st`。
# 所以从**产品**里取（产品是权威），不从源里取。
src = open(os.path.join(ROOT, "志业镜.py"), encoding="utf-8").read()
# 【切除范围要连 `_ANGLE_TAIL` 一起】
# 它定义在 `_angle_shift` **前面**。只切函数会 NameError
# （我第一次就是这么错的：`name '_ANGLE_TAIL' is not defined`）。
i = src.find("_ANGLE_TAIL = [")
assert i > 0, "产品里找不到 _ANGLE_TAIL"
k = src.find("def _angle_shift(", i)
assert k > i, "找不到 _angle_shift"
j = src.find("\n# ===", k)
assert j > k, "找不到 _angle_shift 的结尾"
_CODE = src[i:j]

bad = []


def chk(c, m):
    print(f"  {'✓' if c else '✗'} {m}")
    if not c:
        bad.append(m)


class FakeSt:
    """够 `_angle_shift` 用的假 streamlit。"""

    def __init__(self):
        self.session_state = {"msgs": [1, 2, 3]}


NS = L.load(need=("BY_NAME", "summary_data", "DIM_NAMES", "DIM_PLAIN",
                  "MAJORS"))
NS["st"] = FakeSt()
exec(compile(_CODE, "_angle_shift", "exec"), NS)                 # noqa: S102
_shift = NS["_angle_shift"]

print("=" * 74)
print("① 被拦掉的话里提到专业时，端上来的东西里有真事实")
print("=" * 74)
# 【这是守卫真正会看到的输入】模型想推荐，所以句子里有「建议你选」
CASES = [
    ("我建议你选软件工程。", "软件工程"),
    ("按你说的，你应该选临床医学。", "临床医学"),
    ("还是学数学与应用数学最适合你。", "数学与应用数学"),
]
for text, want in CASES:
    got = _shift(text)
    ok = bool(got)
    print()
    print(f"  输入：{text}")
    print(f"  输出{'' if ok else '（空）'}：")
    for line in (got or "").split("\n"):
        print(f"     {line}")
    chk(ok, f"「{want}」这一句有东西端上来")
    if not ok:
        continue
    chk(want in got, f"端上来的提到的是「{want}」")
    # 【必须有真数字】「2/5」「每周约 55 小时」都算
    chk(bool(re.search(r"\d", got)), "里面有真数字（分数或小时数）")
    # 【断言：不许自我检讨、也不许提机制】
    # 用户原话：「你给我把刚才那句『我说过头了，我自己收回来』删掉，
    # 我不要你注意了」，以及「不需要你管做不做决定」。
    # 所以这两样都要**明确断言不在**——不是 `or True` 那种空断言
    # （我第一版就写成了 `chk(... or True, ...)`，那等于什么都没查）。
    for _no in ("我自己收回来", "我说过头", "不替你", "越线",
                "替你挑", "不能给你看", "不给你看"):
        chk(_no not in got, f"端上来的东西里没有「{_no}」")

print()
print("=" * 74)
print("② 端上来的东西还是中性的——没趁机变成「它更适合你」")
print("=" * 74)
_TAINT = ["适合你", "更适合", "推荐你", "你就选", "最好的选择",
          "我建议", "你应该"]
_all = "\n".join((_shift(t) or "") for t, _w in CASES)
for w in _TAINT:
    chk(w not in _all, f"没出现「{w}」")
chk("哪一条你已经知道是自己不要的" in _all
    or "真在干这行的人" in _all
    or "容不容易回头" in _all
    or "不用等毕业就能试" in _all,
    "给了至少一个新的角度（不是只摊区别）")

print()
print("=" * 74)
print("③ 角度会轮换，不是新的复读机")
print("=" * 74)
_tails = []
for k in range(12):
    NS["st"].session_state["msgs"] = [0] * k
    g = _shift("我建议你选软件工程。") or ""
    _tails.append(g.split("\n")[-1][:24])
_u = sorted(set(_tails))
print(f"     连撞 12 次，出现 {len(_u)} 种收尾：")
for t in _u:
    print(f"       {t}…")
chk(len(_u) >= 3, f"收尾至少 3 种（实际 {len(_u)}）")
chk(all(_tails[k] != _tails[k + 1] for k in range(len(_tails) - 1)),
    "相邻两次不重样")

print()
print("=" * 74)
print("④ 挖不出专业名的时候，不硬凑（返回 None，交给调用方兜底）")
print("=" * 74)
for t in ("我建议你选那个。", "", "你应该选个自己喜欢的。"):
    g = _shift(t)
    chk(g is None, f"{t!r} → 不硬凑（{'None' if g is None else '有内容'}）")

print()
if bad:
    print(f"  ✗ {len(bad)} 项不过：")
    for b in bad:
        print(f"      {b}")
    raise SystemExit(1)
print("  ✓ 撞墙之后有内容、是中性的、而且会换角度")
