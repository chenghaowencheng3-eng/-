# -*- coding: utf-8 -*-
"""两个应用的「来源与底细」，逐条对一遍。

【为什么这件事值得单独做个闸门】
`_majors_src.py` 的 `sources_rows` 注释里写着：
「同一张卡在两处必须给出同样的出处，否则用户会怀疑哪边在骗他」。
**但从来没有一条检查在盯这句话。**

而它是有真实后果的：我这一轮就发现对话版少了「出口详情」那一行——
同一个专业，牌局告诉你那一页内容从哪来，对话版一个字不提。
用户拿两个应用问同一个问题，会得到两个不同的可信度印象。

所以先量差异，再决定哪些差异是**故意的**、哪些是漏的。
"""
import io
import json

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(
    _os.path.abspath(__file__))))
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")

B = json.load(open(f"{ROOT}\\_majors_game.json", encoding="utf-8"))
M = B["majors"]
OCC = json.load(open(f"{ROOT}\\_occ_detail.json", encoding="utf-8"))
ALIAS = set()
for oid, r in OCC.items():
    for nm in set([r.get("primary"), r.get("name")]
                  + (r.get("names") or [])):
        if nm:
            ALIAS.add(nm)
NOT_JOBS = {"考研", "事业单位人员", "公务员", "出国", "参军",
            "科研", "继续深造", "学术"}


def card_rows(m):
    """照 _majors_src.sources_rows 的逻辑算出「项目」名单（不跑 streamlit）。"""
    g = B
    c2g = g.get("class2gate") or {}
    off = g.get("official_classes") or {}
    cl = m.get("专业类") or ""
    cc = next((c for c, n in off.items() if n == cl), None)
    rows = []
    if not (off and c2g):
        rows.append("分类·代码·学位")
    elif cc and c2g.get(cc):
        rows.append("分类·代码·学位")
    else:
        rows.append("分类")
    jf = m.get("chsi_jyfx") or []
    car = m.get("car") or []
    if jf:
        rows.append("就业方向")
    elif car:
        rows.append("就业方向")
    items = jf if jf else car
    n_occ = len([j for j in items if j not in NOT_JOBS and j in ALIAS])
    if n_occ:
        rows.append("出口详情")
    if m.get("chsi_sat"):
        rows.append("四维满意度")
    if m.get("chsi_xsgm"):
        rows.append("在校生规模")
    if m.get("rating"):
        rows.append("三维星级")
    if m.get("rec_index"):
        rows.append("推荐指数")
    if m.get("dims"):
        rows.append("7 维需求画像")
    if m.get("cost_hours"):
        rows.append("代价数字")
    return rows


# 对话版：跑装配文件，调真函数
import ast                                                    # noqa: E402


class _Any:
    def __call__(self, *a, **k):
        return _Any()

    def __enter__(self):
        return _Any()

    def __exit__(self, *a):
        return False

    def __getattr__(self, k):
        return _Any()

    def __iter__(self):
        return iter(())

    def __len__(self):
        return 0


class SS(dict):
    def __getattr__(self, k):
        try:
            return self[k]
        except KeyError:
            raise AttributeError(k) from None

    def __setattr__(self, k, v):
        self[k] = v


class Fake:
    def __init__(self):
        self.marked, self.captions = [], []
        self.session_state = SS()
        self.sidebar = _Any()
        self.err, self.warn, self.ok = [], [], []
        self._progress = []

    def progress(self, *a, **k):
        return self

    def columns(self, spec, *a, **k):
        n = spec if isinstance(spec, int) else len(spec)
        return [_Any() for _ in range(n)]

    def __getattr__(self, name):
        def f(*a, **k):
            return _Any()
        return f


src = open(f"{ROOT}\\志业镜.py", encoding="utf-8").read()
_saved = sys.modules.get("streamlit")
sys.modules["streamlit"] = Fake()
ns = {"__name__": "sources_cmp"}
try:
    exec(compile(src, "志业镜.py", "exec"), ns)
finally:
    if _saved is not None:
        sys.modules["streamlit"] = _saved

ctx = ns.get("new_ctx")()
ctx["by_name"] = {m["n"]: m for m in M}
ctx["majors"] = M

print("=" * 74)
print("逐条对：同一个专业，两个应用各出了哪些出处行")
print("=" * 74)
bad = []


def chk(c, m):
    print(f"  {'✓' if c else '✗'} {m}")
    if not c:
        bad.append(m)


only_card = {}
only_chat = {}
n_same = 0
_len_diff = []
_dups = []
for m in M:
    a = card_rows(m)
    r = ns["run_tool"]("sources_of_major", {"name": m["n"]}, ctx)
    b = [x["项目"] for x in (r.get("rows") or [])]
    sa, sb = set(a), set(b)
    if sa == sb:
        n_same += 1
    # 【条数也要比】只比集合的话，某一项出了两次会被 set 压成一个，
    # 看不出来。我这一轮两次都栽在「比集合不比个数」上。
    if len(a) != len(b):
        _len_diff.append((m["n"], len(a), len(b)))
    if len(b) != len(set(b)):
        _dups.append(m["n"])
    for k in sa - sb:
        only_card.setdefault(k, []).append(m["n"])
    for k in sb - sa:
        only_chat.setdefault(k, []).append(m["n"])

print(f"  161 个专业里，两边出处行**完全一致**的：{n_same} 个")
chk(n_same == len(M), f"全部 {len(M)} 个专业的出处行一致（实际 {n_same}）")
chk(not only_card,
    f"没有「只有牌局出」的行（{ {k: len(v) for k, v in only_card.items()} }）")
chk(not only_chat,
    f"没有「只有对话版出」的行（{ {k: len(v) for k, v in only_chat.items()} }）")
chk(not _len_diff,
    f"每个专业的出处行**条数**也一致（不一的 {len(_len_diff)} 个："
    f"{_len_diff[:3]}）")
chk(not _dups, f"没有重复的项目行（{_dups[:3]}）")

print()
print("=" * 74)
print("每一行都得有「等级」和「来源」")
print("=" * 74)
_norow, _empty, _ranks = [], [], set()
for m in M:
    for x in (ns["run_tool"]("sources_of_major", {"name": m["n"]},
                             ctx).get("rows") or []):
        if not x.get("项目"):
            _norow.append(m["n"])
        if not str(x.get("等级") or "").strip() \
                or not str(x.get("来源") or "").strip():
            _empty.append((m["n"], x.get("项目")))
        _ranks.add(x.get("等级"))
chk(not _norow, f"每一行都有项目名（缺 {len(_norow)}）")
chk(not _empty, f"每一行都有等级和来源（缺 {len(_empty)}：{_empty[:3]}）")
print(f"     用到的等级：{sorted(x for x in _ranks if x)}")

print()
print("=" * 74)
print("抽一个专业把两边的行都打出来")
print("=" * 74)
_ex = next(m for m in M if m["n"] == "建筑学")
print(f"  {_ex['n']}")
print(f"     牌局  ：{card_rows(_ex)}")
_r = ns["run_tool"]("sources_of_major", {"name": _ex["n"]}, ctx)
print(f"     对话版：{[x['项目'] for x in _r['rows']]}")
print()
for x in _r["rows"]:
    print(f"       {x['等级']:<18} {x['项目'][:40]}")

print()
if bad:
    print(f"  ✗ {len(bad)} 项不过：")
    for b in bad:
        print(f"     {b}")
    sys.exit(1)
print("  ✓ 两个应用给出的出处，逐条一致、条数一致、每条都有等级和来源")
