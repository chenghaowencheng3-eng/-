# -*- coding: utf-8 -*-
"""卡片渲染模块的单元测试。**脱开两个应用单独跑。**

【为什么能单独跑，这本身就是设计目标】
`_tools_core.py` 单独跑会 NameError（它引用 `_mirror_core.py` 里的
`ASK`/`OPTIONS`），只有靠组装时内联才能活——**那种代码没法单独测**。
`_cards_core.py` 把所有外部名字做成参数，所以这里可以直接喂真实数据。
"""
import io
import json

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(
    _os.path.abspath(__file__))))
sys.path.insert(0, ROOT)
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")

import _cards_core as C                                       # noqa: E402

bad = []


def chk(c, m):
    print(f"  {'✓' if c else '✗'} {m}")
    if not c:
        bad.append(m)


class FakeSt:
    """最小的假 st。**只实现契约里说的那几个方法。**

    如果 `_cards_core` 偷偷用了别的方法，这里会 AttributeError——
    那正是我想知道的（契约破了）。
    """

    def __init__(self):
        self.md, self.cap, self.warn = [], [], []

    def markdown(self, s, **k):
        self.md.append(str(s))

    def caption(self, s, **k):
        self.cap.append(str(s))

    def warning(self, s, **k):
        self.warn.append(str(s))

    @property
    def all_text(self):
        return "\n".join(self.md + self.cap + self.warn)


game = json.load(open(f"{ROOT}\\_majors_game.json", encoding="utf-8"))
MAJORS = game["majors"]
BY_NAME = {m["n"]: m for m in MAJORS}
# 这几维的名字从共享核心来（不在这里硬写，免得和产品漂开）
sys.path.insert(0, ROOT)
_mc = {}
exec(compile(open(f"{ROOT}\\_mirror_core.py", encoding="utf-8").read(),
             "_mirror_core.py", "exec"), _mc)
DIM_NAMES = _mc["DIM_NAMES"]
DIM_PLAIN = _mc["DIM_PLAIN"]
print(f"  维度名（从 _mirror_core 读的）：{DIM_NAMES}")

print()
print("=" * 74)
print("  ① 有完整画像的牌：该有的块都要有")
print("=" * 74)
m = BY_NAME["建筑学"]
st = FakeSt()
d = C.render_card(st, m, DIM_NAMES, DIM_PLAIN)
kinds = [k for k, _ in d["sections"]]
print(f"     建筑学的块：{kinds}")
chk(d["name"] == "建筑学", "名字取到了")
chk(d["code"] == "082801", f"代码取到了（{d['code']}）")
chk("dims" in kinds, "有七维画像块")
chk("cost" in kinds, "有代价块")
chk("exits" in kinds, "有出口块")

# 【模板值这件事我第一版测错了，记在这里】
# 我断言「建筑学的代价是模板值」，理由是早先探测输出里见过
# `cost_templated  true`——**我把一个刚好相反的样本当成了典型样本。**
# 实测：建筑学的 cost_templated 是 None。
# 查清楚之后发现一条很有用的规律：
#   cost_templated 为 真 → 88 条，**全部是 C2**（按专业类常见情况填的）
#   cost_templated 为 None → 恰好 6 条，**全部是 C1**，且 6/6 都带手写
#                            cost_note（建筑学「五年制 + 改图强度大」、
#                            临床医学「五年本科 + 三年规培…」）
# 也就是说：**这两档不能用一个样本代表**。C1 要显示「等级 C1」，
# C2 要显示「这是模板值」。两类各测一遍。
print()
print("=" * 74)
print("  ①b 代价的两档：C1（核实过）和 C2（模板值）必须显示得不一样")
print("=" * 74)
_c1 = dict(d["sections"])["cost"]
chk(_c1["templated"] is False, "建筑学（C1）不算模板值")
chk("模板值" not in _c1["text"], "C1 不说自己是模板值")
chk("C1" in _c1["text"], "C1 显示了自己的等级")

# 找一个真正的模板值样本（C2）
_tpl_m = next(m2 for m2 in MAJORS
              if m2.get("cost_hours") and m2.get("cost_templated"))
st_t = FakeSt()
d_t = C.render_card(st_t, _tpl_m, DIM_NAMES, DIM_PLAIN)
_c2 = dict(d_t["sections"])["cost"]
print(f"     模板值样本：「{_tpl_m['n']}」")
chk(_c2["templated"] is True, f"「{_tpl_m['n']}」算模板值")
chk("模板值" in _c2["text"], "模板值的文本里标了「模板值」")
chk("模板值" in st_t.all_text, "模板值也画到了页面上")
# 【这条规律要盯住】C1 和 C2 的模板标记必须严格对应，不许出现
# 「C1 却自称模板值」或「C2 却不标模板值」——那是把估计冒充准数。
_n_c1_tpl = sum(1 for x in MAJORS
                if x.get("cost_tier") == "C1" and x.get("cost_templated"))
_n_c2_untpl = sum(1 for x in MAJORS
                  if x.get("cost_tier") == "C2" and x.get("cost_hours")
                  and not x.get("cost_templated"))
chk(_n_c1_tpl == 0, f"没有「C1 却标成模板值」的（{_n_c1_tpl} 条）")
chk(_n_c2_untpl == 0, f"没有「C2 却没标模板值」的（{_n_c2_untpl} 条）")

print()
print("=" * 74)
print("  ② 数据缺项时不许硬凑（这是产品最值钱的地方）")
print("=" * 74)
_no_dims = [m for m in MAJORS if not m.get("dims")]
print(f"     没有画像的牌：{len(_no_dims)}/{len(MAJORS)}")
chk(len(_no_dims) > 0, "确实存在没有画像的牌（否则这一节什么都没测）")
m2 = _no_dims[0]
st2 = FakeSt()
d2 = C.render_card(st2, m2, DIM_NAMES, DIM_PLAIN)
k2 = [k for k, _ in d2["sections"]]
print(f"     「{d2['name']}」的块：{k2}")
chk("dims" not in k2, "没有画像就**不画**七维块（不编一个出来）")
chk("成本" not in st2.all_text or "模板值" not in st2.all_text,
    "没有代价数字时不会出现「模板值」这句")
# 一个什么都没有的牌，必须走「我还没做出内容」那条路，而不是空白
_bare = {"n": "测试用专业", "gate": "工学"}
st3 = FakeSt()
d3 = C.render_card(st3, _bare, DIM_NAMES, DIM_PLAIN)
chk("我还没做出内容" in st3.all_text,
    "什么都没有时说清「我还没做出内容」（不是留白）")
chk(d3["sections"] == [], "空牌的 sections 是空列表，没被硬凑")

print()
print("=" * 74)
print("  ③ 出口要分「官方的」和「整理的」两类")
print("=" * 74)
_ex = dict(d["sections"]).get("exits")
chk(_ex is not None, "建筑学有出口块")
if _ex:
    _off = [e for e in _ex["items"] if e["kind"] == "official"]
    _cur = [e for e in _ex["items"] if e["kind"] == "curated"]
    print(f"     官方登记 {len(_off)} 条，整理的 {len(_cur)} 条")
    chk(bool(_off), "有官方登记的方向")
    chk("学职平台登记的" in st.all_text, "官方那组标了「学职平台登记」")
    if _cur:
        chk("不是官方登记" in st.all_text, "整理那组标了「不是官方登记」")

print()
print("=" * 74)
print("  ④ 转义：名字里的尖括号不许撑坏布局")
print("=" * 74)
st4 = FakeSt()
C.render_card(st4, {"n": "<script>alert(1)</script>", "gate": "工学"},
              DIM_NAMES, DIM_PLAIN)
chk("<script>" not in st4.all_text, "尖括号被转义了")
chk("&lt;script&gt;" in st4.all_text, "转义成了实体")

print()
print("=" * 74)
print("  ⑤ 全量：161 张牌一张都不许崩")
print("=" * 74)
_crash = []
for _m in MAJORS:
    try:
        C.render_card(FakeSt(), _m, DIM_NAMES, DIM_PLAIN)
    except Exception as e:
        _crash.append((_m.get("n"), f"{type(e).__name__}: {e}"))
chk(not _crash, f"161 张牌全部渲染通过（崩了 {len(_crash)} 张）")
for nm, e in _crash[:6]:
    print(f"       ✗ {nm}：{e}")

# 维度名数量必须对得上（数据里是 7 维）
chk(all(len(m["dims"]) == len(DIM_NAMES)
        for m in MAJORS if m.get("dims")),
    f"有画像的牌维数都等于 {len(DIM_NAMES)}")

print()
if bad:
    print(f"  ✗ {len(bad)} 项不过：")
    for b in bad:
        print(f"     {b}")
    sys.exit(1)
print(f"  ✓ 卡片渲染：{len(MAJORS)} 张牌全过，缺项不硬凑，模板值有标记")
