# -*- coding: utf-8 -*-
"""AppTest：对话版能起来、侧栏数字是真的、开场白在。

【为什么这一层不能省】
函数测对了不等于应用能跑。内联 35KB 目录、加一个工具，
任何一处坏掉都会在 import 或首次渲染时炸。

【这个文件原来有两个毛病，一并修了】
① 路径写死在本机绝对位置 → 换台机器就跑不动。
② **它从不 `sys.exit(1)`**，只有前面那个「启动异常」会退码 1。
   也就是说：**下面的关键词、侧栏数字、输入框全都不合格时，
   它照样退码 0**——一条永远绿的闸门。现在每项不过都记账。
"""
import io
import json

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(
    _os.path.abspath(__file__))))
from streamlit.testing.v1 import AppTest                    # noqa: E402

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")

bad = []


def chk(c, m):
    print(f"   {'✓' if c else '✗'} {m}")
    if not c:
        bad.append(m)


AT = AppTest.from_file(os.path.join(ROOT, "志业镜.py"), default_timeout=180)
AT.run()
chk(not AT.exception,
    f"启动无异常（{AT.exception if AT.exception else '0 条'}）")
if AT.exception:
    print("   → 起不来，后面的检查没有意义")
    raise SystemExit(1)

parts = []
for kind in ("markdown", "caption", "warning", "error", "success", "info"):
    try:
        for e in getattr(AT, kind):
            parts.append(str(e.value))
    except Exception:
        pass
t = "\n".join(parts)
chk(len(t) > 200, f"页面有内容（{len(t)} 字）")

print()
print("   开场白：", end="")
# 【开场白有六条、每次换一条，所以不能只认一条】
# 原来这里写死「不用想清楚才来」「最近有什么事，是你自己愿意多花点时间的」——
# 那是**写死一句**时代的断言。用户嫌它「每次都是开头这句，烦不烦」之后
# 开场改成六条轮换，这条断言就过期了。
# 换成：**六条里必须有一条真渲染出来**，而且把对上的那条报出来——
# 万一以后六条全改了，输出里能直接看出是哪种。
_OPEN_KEYS = ("我先说我这儿有什么", "来了。", "不用自我介绍",
              "你先说，或者先别说", "你要是已经有个大概方向",
              "不聊大道理")
_hit = next((k for k in _OPEN_KEYS if k in t), None)
print(f"{'✓ 「' + _hit + '」' if _hit else '✗ 六条一条都没出现'}")
chk(_hit is not None, "开场白真的有六条里的一条")
chk("志业镜" in t, "页面上有「志业镜」")

# 侧栏底细里的数字必须是真的
SIDE = "\n".join(str(e.value) for e in AT.sidebar.markdown)
g = json.load(open(os.path.join(ROOT, "_majors_game.json"), encoding="utf-8"))
M = g["majors"]
facts = {
    f"{len(M)}": len(M),
    f"{sum(1 for m in M if m.get('dims'))}": sum(1 for m in M
                                                if m.get("dims")),
    f"{sum(1 for m in M if m.get('cost_templated'))}":
        sum(1 for m in M if m.get("cost_templated")),
}
print()
print("   侧栏数字核对（数据里有这个数，侧栏就得提到）：")
for kw, real in facts.items():
    chk(kw in SIDE, f"侧栏提到「{kw}」（数据里是 {real}）")

print()
chk(bool(AT.chat_input), "输入框在")
chk(not AT.exception, f"整屏无异常（{AT.exception if AT.exception else '0 条'}）")

print()
if bad:
    print(f"   ✗ {len(bad)} 项不过：{bad}")
    raise SystemExit(1)
print("   ✓ 对话版起得来、开场白在、侧栏数字对得上")
