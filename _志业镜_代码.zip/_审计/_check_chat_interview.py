# -*- coding: utf-8 -*-
"""对话版的访谈：工具真的在、真的能走完七题、算得和牌局一样。

【为什么最关键的一条是「两边算得一样」】
用户会先看牌局、再看对话。同一个答案在两边得出不同的数，
是这个产品最不能出的错——**那说明它不是一台镜子，是两台。**
所以这里直接把两个应用里的 interview_result 拿出来比。
"""
import io
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")

bad = []
CUT = 'if __name__ == "__main__"'


def load(path, mod):
    s = open(path, encoding="utf-8").read()
    c = s.find(CUT)
    ns = {"__name__": mod}
    exec(compile(s[:c if c > 0 else len(s)], path, "exec"), ns)
    return ns


print("=" * 74)
print("① 工具声明里有 interview 吗")
print("=" * 74)
CH = load("志业镜.py", "chat")
specs = {t["function"]["name"] for t in CH["tool_specs"]()}
print(f"   工具：{sorted(specs)}")
ok = "interview" in specs
print(f"   {'✓' if ok else '✗'} interview 在工具表里")
if not ok:
    bad.append("工具表里没有 interview")

_iv = next((t["function"] for t in CH["tool_specs"]()
            if t["function"]["name"] == "interview"), None)
if _iv:
    props = _iv["parameters"]["properties"]
    dims = props["dimension"]["enum"]
    same = sorted(dims) == sorted(CH["DIM_KEYS"])
    print(f"   {'✓' if same else '✗'} dimension 的 enum 正好是七维")
    if not same:
        bad.append(("enum 和七维不符", dims))
    n_req = _iv["parameters"].get("required")
    print(f"   {'✓' if not n_req else '✗'} 没有必填参数（模型可以先空手调一次）")
    if n_req:
        bad.append(("有必填参数，模型无法先看进度", n_req))
    # 描述里必须写明「这不是测评」
    d = _iv["description"]
    for kw in ("这不是测评", "没有校准", "一个字都没问"):
        print(f"   {'✓' if kw in d else '✗'} 描述里说了「{kw}」")
        if kw not in d:
            bad.append(("描述缺", kw))

    # ── 判分这条路：这轮改过，得盯住新契约 ──
    # 原来描述写的是「不要自己打分数」，模型只能把用户原话当 answer 传回来。
    # 那条路在**真人话上只对 3/15**——「一道题卡一星期也会接着做」和选项
    # 「失败了反而更想弄明白为什么」一个字都不重合。
    # 现在改成模型判分 + 交引文，所以要断言的是**新契约的三件事**：
    #   ① 有 score 参数   ② 有 quote 参数
    #   ③ 明说 quote 会被核对、对不上就不认
    props = _iv["parameters"]["properties"]
    for p in ("score", "quote"):
        print(f"   {'✓' if p in props else '✗'} 有「{p}」参数")
        if p not in props:
            bad.append(("缺参数", p))
    _qd = str(props.get("quote", {}).get("description", ""))
    for kw in ("原话", "核对"):
        print(f"   {'✓' if kw in _qd else '✗'} quote 的说明里提到「{kw}」")
        if kw not in _qd:
            bad.append(("quote 说明缺", kw))
    print(f"   {'✓' if '照抄' in _qd or '别改写' in _qd else '✗'} "
          f"明说引文要照抄（不能改写）")
    if "照抄" not in _qd and "别改写" not in _qd:
        bad.append(("quote 没说清要照抄", _qd[:40]))

print()
print("=" * 74)
print("② 空手调一次：拿到七题和选项")
print("=" * 74)
ctx = CH["new_ctx"]()
r = CH["run_tool"]("interview", {}, ctx)
print(f"   answered={r.get('answered')}/{r.get('total')}  "
      f"next={len(r.get('next') or [])} 题")
if len(r.get("next") or []) != 7:
    bad.append(("空手调没给七题", r))
for it in (r.get("next") or [])[:2]:
    print(f"   · {it['dimension']}：{it['question'][:34]}…")
    print(f"       选项 {len(it['options'])} 个，例：{it['options'][0][:30]}")
# 每一维的选项数都要和牌局一致
# 【牌局那个应用已经并入产品了，这一条跟着改】
# 原来的立论是「两个应用算得一样」——因为用户会先看牌局、再看对话，
# 同一个答案在两边得出不同的数，那说明「它不是一台镜子，是两台」。
# 合并之后只有一个应用，但那条立论变成了**更强的形式**：
#   **应用里跑的必须是 `_mirror_core.py` 本体，不能是任何一份副本。**
# 副本才是「两台镜子」的成因，而合并恰恰消灭了副本。
# 所以这里换成「应用 vs 共享核心」的逐项对齐。
_mirror_ns = {}
exec(compile(open("_mirror_core.py", encoding="utf-8").read(),
             "_mirror_core.py", "exec"), _mirror_ns)
CARD = _mirror_ns
print("   （牌局应用已并入产品；这一节改成「应用 vs 共享核心」逐项对齐）")
_mismatch = []
for it in (r.get("next") or []):
    a = len(it["options"])
    b = len(CARD["OPTIONS"][it["dimension"]])
    if a != b:
        _mismatch.append((it["dimension"], a, b))
print(f"   {'✓' if not _mismatch else '✗'} 两边每维选项数一致"
      f"{'' if not _mismatch else ' 不符：' + str(_mismatch)}")
if _mismatch:
    bad.append(("选项数不一致", _mismatch))

print()
print("=" * 74)
print("③ 逐题作答（用选项原话），看最后算出来的对照")
print("=" * 74)
ctx = CH["new_ctx"]()
# 认知负荷答第二个选项（=4），其余也各挑一个
PICK = {"认知负荷": 1, "记忆量": 2, "细节分辨": 2, "动手要求": 2,
        "自驱要求": 2, "挫折耐受": 2, "慢反馈耐受": 2}
expect = []
for dim, idx in PICK.items():
    opts = CH["_iv_words"](dim)
    word = opts[idx]
    r = CH["run_tool"]("interview",
                       {"dimension": dim, "answer": word}, ctx)
    sc = CARD["OPTIONS"][dim][idx][0]
    expect.append(sc)
    print(f"   {dim:6} 答「{word[:26]}」→ answered={r.get('answered')}")
print(f"   最后 done={r.get('done')}")
if not r.get("done"):
    bad.append(("七题答完没 done", r))
print(f"   counts={r.get('counts')}")
print(f"   must_say {len(r.get('must_say') or [])} 条")

# 【这一节改成「应用 vs 共享核心」，判准更严了】
# 原来比的是「对话版 vs 牌局版」两个应用。
# 现在比的是「应用里那份 vs `_mirror_core.py` 本体」——
# 后者才是要害：**应用里跑的必须就是核心本体，不能是副本。**
# 【这里原来是 `CH["majors"] if "majors" in CH else None`——错了两层】
#   ① 应用的名单叫 `MAJORS`（大写），`"majors"` 永远不在 CH 里，
#      所以它**永远走 else，永远传 None**；
#   ② 而 `None` 以前会退回一个全局，于是**这个错误被掩盖了很久**。
# 核心现在不留退路了，它当场报错——**这次是核心帮我把测试的错误逼出来的。**
res_app = CH["interview_result"](expect, CH["MAJORS"])
res_core = CARD["interview_result"](expect, CH["MAJORS"])
print()
print(f"   应用：一致 {len(res_app['agree'])} "
      f"落差 {len(res_app['gap'])} 证据不足 {len(res_app['unknown'])}")
print(f"   核心：一致 {len(res_core['agree'])} "
      f"落差 {len(res_core['gap'])} 证据不足 {len(res_core['unknown'])}")
_same = (len(res_app["agree"]) == len(res_core["agree"])
         and len(res_app["gap"]) == len(res_core["gap"])
         and len(res_app["unknown"]) == len(res_core["unknown"]))
print(f"   {'✓' if _same else '✗'} 应用里跑的就是核心本体（不是副本）")
if not _same:
    bad.append(("应用与共享核心算法不一致", "见上"))
# 落差的具体专业也要一样
_g1 = [m["n"] for m, *_ in res_app["gap"]]
_g2 = [m["n"] for m, *_ in res_core["gap"]]
print(f"   {'✓' if _g1 == _g2 else '✗'} 落差的专业名单逐条一致")
if _g1 != _g2:
    bad.append(("落差名单不一致", (_g1[:5], _g2[:5])))
print(f"   落差的：{_g1[:6]}")
# 【选项表也必须同源】应用的 OPTIONS 和核心的 OPTIONS 要一模一样，
# 否则会出现「题面是应用版的、判分是核心版的」这种错位。
_ch_opt = {k: [(s, t) for s, t, _r in v] for k, v in CH["OPTIONS"].items()}
_core_opt = {k: [(s, t) for s, t, _r in v] for k, v in CARD["OPTIONS"].items()}
print(f"   {'✓' if _ch_opt == _core_opt else '✗'} 选项表也同源"
      f"（{len(_ch_opt)} 维）")
if _ch_opt != _core_opt:
    bad.append(("选项表和核心不一致",
                [k for k in _ch_opt if _ch_opt[k] != _core_opt.get(k)]))

print()
print("=" * 74)
print("④ 「没试过」必须变成「不知道」，不能变低分")
print("=" * 74)
ctx = CH["new_ctx"]()
for dim in CH["DIM_KEYS"]:
    opts = CH["_iv_words"](dim)
    none_word = opts[-1]          # 「没试过，说不好」
    CH["run_tool"]("interview", {"dimension": dim, "answer": none_word}, ctx)
r4 = CH["run_tool"]("interview", {}, ctx)
print(f"   七题全答「没试过」→ counts={r4.get('counts')}")
if r4.get("counts", {}).get("证据不足") != 94:
    bad.append(("全答没试过时证据不足不是 94", r4.get("counts")))
else:
    print("   ✓ 94 个全部归入「证据不足」")
if r4.get("counts", {}).get("有落差"):
    bad.append(("全答没试过却算出落差", r4.get("counts")))
else:
    print("   ✓ 一个落差都没有（没答 ≠ 不行）")

# 模型乱写一个分数，不许被当成分数
ctx = CH["new_ctx"]()
r5 = CH["run_tool"]("interview",
                    {"dimension": "认知负荷", "answer": "4"}, ctx)
_ans = ctx["iv"].get("认知负荷")
print(f"   模型写「4」（不是选项原话）→ 记成 {_ans!r}")
if _ans is not None:
    bad.append(("模型乱写分数被采纳了", _ans))
else:
    print("   ✓ 认不出来就记「不知道」，不猜分数")

# 已经答过的不许被覆盖
r6 = CH["run_tool"]("interview",
                    {"dimension": "认知负荷",
                     "answer": CH["_iv_words"]("认知负荷")[2]}, ctx)
print(f"   重复答同一维 → already={r6.get('already')}（不许静默覆盖）")
if not r6.get("already"):
    bad.append(("重复答同一维会静默覆盖", r6))

print()
print("=" * 74)
print(f"  {'✓ 对话版访谈全部通过' if not bad else f'✗ {len(bad)} 处：{bad}'}")
