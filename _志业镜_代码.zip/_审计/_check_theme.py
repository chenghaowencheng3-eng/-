# -*- coding: utf-8 -*-
"""皮肤闸门：两套配色真的生效、且确实是两套。

【为什么不能靠肉眼看生成的 .py】
「CSS 在文件里」和「CSS 到页面上」是两件事。
这个仓库里已经栽过「822 字 CSS 一次都没出现在屏幕上」那次——
我当时还把它算进了「主区很啰嗦」。
"""
import io
import re

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(
    _os.path.abspath(__file__))))
sys.path.insert(0, ROOT)
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")

import _theme_core as TH                                      # noqa: E402

bad = []


def chk(c, m):
    print(f"  {'✓' if c else '✗'} {m}")
    if not c:
        bad.append(m)


print("=" * 74)
print("  ① 一份结构、两套配色")
print("=" * 74)
ink, rose = TH.css("ink"), TH.css("rose")
chk(ink != rose, "两套配色产出的字面量不同")
chk(len(ink) > 1500, f"皮肤够大（{len(ink)} 字节字面量）")
# 结构必须一致：把颜色值抠掉之后应该完全相同
# 【结构比对不能靠我手维护一份颜色清单】
# 我第一版写的是 `_pal = [...16 个颜色值...]`，然后从两边抠掉它们。
# 改配色时我忘了同步这个清单，于是「结构一字不差」这条**假红**了——
# 这是这个仓库里第 N 次「两处靠人工同步」出问题。
# 正解：用正则把**所有**颜色（#rrggbb 和 rgba(...)）都换成占位，
# 剩下的就是纯结构，不需要我维护任何东西。
def skeleton(s):
    t = re.sub(r"#[0-9a-fA-F]{3,8}", "@", s)
    t = re.sub(r"rgba?\([^)]*\)", "@", t)
    return t


chk(skeleton(ink) == skeleton(rose),
    "**去掉所有颜色之后，两套的结构一字不差**（说明没有各写一份）")
chk(skeleton(ink) != ink,
    "骨架比对确实抠掉了东西（否则它什么都没测）")
_n_hex = len(re.findall(r"#[0-9a-fA-F]{3,8}", ink))
chk(_n_hex >= 5, f"ink 里抠出 {_n_hex} 个颜色，说明比对不是空转")

print()
print("=" * 74)
print("  ② 每个主题的配色占位符都换干净了")
print("=" * 74)
for name, s in (("ink", ink), ("rose", rose)):
    chk("__C_" not in s, f"{name} 没有残留的 __C_ 占位符")
    _missing = re.findall(r"var\(--([a-z]+)\)", s)
    _declared = set(re.findall(r"--([a-z]+):", s))
    _undef = sorted(set(_missing) - _declared)
    chk(not _undef, f"{name} 用到的变量都声明过（缺 {_undef}）")
    print(f"     {name} 声明 {len(_declared)} 个变量，"
          f"引用 {len(set(_missing))} 个")

print()
print("=" * 74)
print("  ③ 应用里，皮肤是真的被 markdown 发出去的")
print("=" * 74)
# 【用户把产品合并成一个应用了，这一节跟着改】
# 原来查两个文件：牌局（专业游乐场.py）和对话（志业镜.py）。
# 现在只有一个应用 `志业镜.py`。
#
# 【但「两套配色都要在」这条不能跟着删】
# `_theme_core.py` 仍然是「一份结构 + 两套配色」，
# ink 那套留给讲稿和牌局源复用。这条断言改成**直接比配色的取值**——
# 比原来「比两个文件的字符串」更贴近它想测的东西。
_mirror_ink = re.search(r"--mirror:(#[0-9a-f]{6})", TH.css("ink")).group(1)
_mirror_rose = re.search(r"--mirror:(#[0-9a-f]{6})", TH.css("rose")).group(1)
print(f"     牌局配色镜色 {_mirror_ink}　对话配色镜色 {_mirror_rose}")
chk(_mirror_ink != _mirror_rose, "两套配色的品牌色确实不同（不是抄的两份）")

_src_app = open(os.path.join(ROOT, "志业镜.py"),
                encoding="utf-8").read()
chk("st.markdown(" in _src_app and "<style>" in _src_app,
    "唯一应用里有 st.markdown 发 <style>")
chk("mcard" in _src_app, "卡片 class 在（共用结构）")
chk("--mirror" in _src_app, "用到 --mirror 变量")
_m_app = re.search(r"--mirror:(#[0-9a-f]{6})", _src_app)
print(f"     应用实际用的品牌色 {_m_app.group(1) if _m_app else '（没找到）'}")
chk(_m_app and _m_app.group(1) == _mirror_rose,
    "它用的是 rose 那套（对话版该用的那套）")
print()
print("=" * 74)
print("  ④ 对比度：正文和次要文字都要读得清")
print("=" * 74)


def lum(hexs):
    r, g, b = (int(hexs[i:i + 2], 16) / 255 for i in (1, 3, 5))
    f = lambda c: c / 12.92 if c <= .03928 else ((c + .055) / 1.055) ** 2.4
    return .2126 * f(r) + .7152 * f(g) + .0722 * f(b)


def ratio(a, b):
    la, lb = lum(a), lum(b)
    hi, lo = max(la, lb), min(la, lb)
    return (hi + .05) / (lo + .05)


for name, c in (("牌局", dict(ink="#1f2933", muted="#63717f",
                             paper="#fbfaf7", panel="#f3f5f8")),
                ("对话", dict(ink="#2b2530", muted="#766b79",
                             paper="#fdfbfc", panel="#f8f3f6"))):
    r_ink = ratio(c["ink"], c["paper"])
    r_mut = ratio(c["muted"], c["paper"])
    r_pan = ratio(c["muted"], c["panel"])
    print(f"     {name}：正文/底 {r_ink:.2f}　次要/底 {r_mut:.2f}　"
          f"次要/面板 {r_pan:.2f}")
    chk(r_ink >= 7.0, f"{name} 正文对比度 {r_ink:.2f} ≥ 7（AAA）")
    chk(r_mut >= 4.5, f"{name} 次要文字对比度 {r_mut:.2f} ≥ 4.5（AA）")
    # 【面板比底更亮，是最坏情况】次要文字大量出现在面板上（侧栏、引用块）
    chk(r_pan >= 4.5, f"{name} 次要文字在面板上 {r_pan:.2f} ≥ 4.5（最坏情况）")

# 【这几条颜色值必须和主题文件里的一模一样】
# 我不在这里另写一遍颜色，而是**从主题里读出来**——
# 上面那两个 dict 只是为了让消息好读；真正判定用 theme 自己的值。
print()
print("  从主题文件里读出来的实际颜色（这才是判定依据）：")
for nm, t in (("ink", "牌局"), ("rose", "对话")):
    lit = TH.css(nm)
    got = {}
    for key in ("ink", "muted", "paper", "panel"):
        m = re.search(rf'--{key}:(#[0-9a-f]{{6}})', lit)
        got[key] = m.group(1) if m else None
    r1 = ratio(got["ink"], got["paper"])
    r2 = ratio(got["muted"], got["paper"])
    r3 = ratio(got["muted"], got["panel"])
    print(f"     {t}：ink={got['ink']} muted={got['muted']} "
          f"paper={got['paper']} panel={got['panel']}")
    print(f"        正文 {r1:.2f}　次要/底 {r2:.2f}　次要/面板 {r3:.2f}")
    chk(r1 >= 7.0, f"{t}（读自主题）正文 {r1:.2f} ≥ 7")
    chk(r2 >= 4.5, f"{t}（读自主题）次要/底 {r2:.2f} ≥ 4.5")
    chk(r3 >= 4.5, f"{t}（读自主题）次要/面板 {r3:.2f} ≥ 4.5")

print()
if bad:
    print(f"  ✗ {len(bad)} 项不过：")
    for b in bad:
        print(f"     {b}")
    sys.exit(1)
print("  ✓ 皮肤：一份结构、两套配色、对比度都过关、真的发到了页面上")

