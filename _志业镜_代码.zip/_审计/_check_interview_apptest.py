# -*- coding: utf-8 -*-
"""AppTest：从侧栏入口真的点进访谈，答完，看对照页。

【为什么必须这一层】
上面那些测的是函数。**用户走的是按钮和 radio。**
入口按钮的 key、模式切换、radio 的默认值——任何一处对不上，
函数测得再对用户也进不去。
"""
import io
import sys

from streamlit.testing.v1 import AppTest

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
# ==================================================================
# 【已停用：它驱动的那个界面已经并入产品了】
# ==================================================================
# 这个脚本原来用 `AppTest` 驱动 `专业游乐场.py`（牌局界面）。
# 用户把产品合并成了一个应用（对话为主、翻牌做进对话里），
# 那个界面文件已经不再生成（见 `_assemble_majors.py`）。
#
# 【为什么不把路径改指到 `志业镜.py` 了事】
# 那会让它去驱动**另一个界面**，断言逐条都对不上——
# **一个必然假的绿，比一个红更糟。**
# 它守的那件事（访谈/查询在真页面上走得通）现在由这些闸门守：
#   · `_审计/_check_interview_in_chat.py`（侧栏进得去、七题走完、结果带立场）
#   · `_审计/_check_merged_app.py`（首屏起得来、翻牌画得出、展开是完整的）
#   · `_审计/_check_exit_render.py`（出口那一行印得对）
# 所以它是被**取代**了，不是被绕过。
print("  （这个闸门已停用：它驱动的界面已并入产品，"
      "由 _check_interview_in_chat / _check_merged_app 取代）")
raise SystemExit(0)
# ------------------------------------------------------------------
# 下面保留原文，供查阅；不再执行。
# ------------------------------------------------------------------

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")


def collect(at):
    parts = []
    for kind in ("markdown", "caption", "warning", "error", "success",
                 "info"):
        try:
            for e in getattr(at, kind):
                parts.append(str(e.value))
        except Exception:
            pass
    return "\n".join(parts)


AT = AppTest.from_file(
        os.path.join(ROOT, "_专业游乐场.build-check.py"), default_timeout=120)
AT.run()
print(f"启动：{AT.exception if AT.exception else '无异常 ✓'}")

# ── 找侧栏入口 ──
_btn = None
for b in AT.button:
    if "反过来问你" in str(getattr(b, "label", "")):
        _btn = b
        break
print(f"侧栏入口按钮：{'找到了 → ' + str(_btn.label) if _btn else '✗ 没找到'}")
if _btn is None:
    print("侧栏按钮有：", [str(getattr(b, 'label', '')) for b in AT.button])
    sys.exit(1)

_btn.click()
AT.run()
print(f"点进访谈：{AT.exception if AT.exception else '无异常 ✓'}")
t = collect(AT)
_ASK = ["熬了多久", "硬背下来", "细节都是我在抠", "亲手做出一件东西",
        "推得动吗", "连着失败好几回", "很久以后才知道有没有用"]
miss = [q for q in _ASK if q not in t]
print(f"七问都在页上：{'✓' if not miss else '✗ 少了 ' + str(miss)}")

_radios = AT.radio
print(f"页面上的 radio：{len(_radios)} 个")
for r in _radios:
    print(f"   {str(getattr(r, 'label', ''))[:28]!r}  "
          f"选项 {len(getattr(r, 'options', []) or [])} 个")

# ── 答满七问，再点「看看这些答案对上了什么」 ──
_picks = ["有，一两个通宵，缓两天就回来了",
          "经常这样，背下来之后再慢慢懂，我习惯了",
          "细节都是我在抠，别人做的我不放心",
          "有，而且不用人催，自己就能鼓捣半天",
          "推得动，没什么人管也一样干",
          "失败了反而更想弄明白为什么",
          "做过，而且当时完全看不出有什么用，我也做完了"]
_n_set = 0
for r in AT.radio:
    opts = list(getattr(r, "options", []) or [])
    for p in _picks:
        if p in opts:
            r.set_value(p)
            _n_set += 1
            break
print(f"设了 {_n_set} 个 radio")
AT.run()
print(f"答完之后：{AT.exception if AT.exception else '无异常 ✓'}")

_go = None
for b in AT.button:
    if "对上了什么" in str(getattr(b, "label", "")):
        _go = b
        break
print(f"「看看这些答案对上了什么」按钮：{'找到' if _go else '✗ 没找到'}")
if _go is None:
    print("按钮有：", [str(getattr(b, 'label', '')) for b in AT.button])

if _go is not None:
    _go.click()
    AT.run()
    print(f"进对照页：{AT.exception if AT.exception else '无异常 ✓'}")
    t2 = collect(AT)
    print(f"对照页 {len(t2)} 字")
    for kw in ("你的话，和牌上要的", "你刚才说的", "你说的每一项，它都要得起的",
               "有落差的", "它不知道你喜欢什么", "没有校准"):
        print(f"   {'✓' if kw in t2 else '✗'} 「{kw}」")
    # 抽几行实际内容，看它说不出得出东西
    print()
    print("对照页里抽几行：")
    for line in t2.split("\n"):
        s = line.strip()
        if any(k in s for k in ("你说的每一项", "有落差的", "它要", "不知道")):
            if 4 < len(s) < 150:
                print("   ", s[:140])
