# -*- coding: utf-8 -*-
"""访谈那一层：问得对、算得对、不把「没答」当低分。

【这一层最容易出的三类错，各测一遍】
  ① 把 None 当成 0 或 1 —— 那等于替用户判他的能力
  ② 「落差」和「证据不足」混成一堆 —— 两件事意思相反
  ③ 七问和七维对不上 —— 题面问的和它记的维度不是一件事
"""
import io

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(
    _os.path.abspath(__file__))))
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")


class F:
    def __init__(self):
        self.marked, self.captions, self.session_state = [], [], {}
        self.warn, self.err, self.ok, self.info = [], [], [], []
        self.progress = []
        self._radio = {}
        self._btn = None

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    @property
    def sidebar(self):
        return self

    def columns(self, x):
        return [self] * (x if isinstance(x, int) else len(x))

    def tabs(self, n):
        return [self] * len(n)

    def expander(self, *a, **k):
        return self

    def spinner(self, *a, **k):
        return self

    def multiselect(self, *a, **k):
        return []

    def selectbox(self, *a, **k):
        return (a[0][0] if a and a[0] else "")

    def radio(self, *a, **k):
        # 【这里必须像真的 radio 一样返回一个选项】
        # 我第一版没命中就返回 None，侧栏那句 `_d.startswith(...)` 直接炸——
        # 那是**我的假对象不对**，不是应用不对。
        # 真 radio 永远有值（默认第一项），所以这里也照做。
        lbl = k.get("key") or (a[0] if a else "")
        if lbl in self._radio:
            return self._radio[lbl]
        opts = a[1] if len(a) > 1 else k.get("options")
        if isinstance(opts, (list, tuple)) and opts:
            return opts[0]
        return None

    def text_area(self, *a, **k):
        return ""

    def text_input(self, *a, **k):
        return ""

    def progress(self, *a, **k):
        self.progress.append(a[0] if a else None)
        return self

    def button(self, *a, **k):
        return self._btn is not None and str(a[0]) == self._btn

    def __getattr__(self, name):
        def f(*a, **k):
            _v = str(a[0]) if a else ""
            if name == "markdown":
                self.marked.append(_v)
            if name == "caption":
                self.captions.append(_v)
            if name == "warning":
                self.warn.append(_v)
            if name == "error":
                self.err.append(_v)
            if name == "success":
                self.ok.append(_v)
            if name == "info":
                self.info.append(_v)
            return None
        return f


saved = sys.modules.get("streamlit")
fake = F()
sys.modules["streamlit"] = fake
# 【数据从加载器来，不自己 exec 源码】
# 源码里是 `__MAJOR_DATA__` 这类占位符，直接 exec 会 JSONDecodeError；
# 而且那个应用文件已经不再生成（产品合并成一个了）。
# 假 streamlit 必须**在加载之前**装上：加载会 `import streamlit`，
# 装晚了它拿到的是真的，输出就全是「missing ScriptRunContext」。
sys.path.insert(0, ROOT)
import _majors_src_loader as _L                              # noqa: E402
NS = _L.load()

ASK = NS["ASK"]
OPT = NS["OPTIONS"]
# 【把专业名单在这里绑好，别改五个调用点】
# `interview_result` 的 `majors` 参数已经改成必需（以前会退回一个
# 只存在于应用里的全局 `MAJORS`）。与其去改五处调用，
# 不如在绑函数这一行就地包一层——**改一处，五处都跟着对**。
RES = lambda a: NS["interview_result"](a, NS["MAJORS"])       # noqa: E731
MAJORS = NS["MAJORS"]
DIM_NAMES = NS["DIM_NAMES"]
bad = []

print("=" * 74)
print("① 七问 ↔ 七维：必须一一对上，不能重复也不能漏")
print("=" * 74)
_dims_asked = [d for _, d in ASK]
print(f"   七问覆盖的维度：{_dims_asked}")
_missing = [d for d in DIM_NAMES if d not in _dims_asked]
_extra = [d for d in _dims_asked if d not in DIM_NAMES]
print(f"   没被问到的维度：{_missing or '无 ✓'}")
print(f"   问了但不在七维里的：{_extra or '无 ✓'}")
if _missing or _extra:
    bad.append(("题目和维度脱节", _missing, _extra))
if len(_dims_asked) != len(set(_dims_asked)):
    bad.append(("有维度被问了两遍",))

print()
print("=" * 74)
print("② 每个维度的选项：有没有「不知道」这一条，分数合不合法")
print("=" * 74)
for d in DIM_NAMES:
    if d not in OPT:
        print(f"   ✗ {d} 没有选项")
        bad.append((d, "没有选项"))
        continue
    opts = OPT[d]
    has_none = any(o[0] is None for o in opts)
    scores = [o[0] for o in opts]
    ok = all(v is None or 1 <= v <= 5 for v in scores)
    print(f"   {'✓' if ok else '✗'} {d:8} {len(opts)} 个选项 "
          f"分数={scores}　含「不知道」={'是' if has_none else '否'}")
    if not ok:
        bad.append((d, "分数越界", scores))
    # 【每一维都必须有「不知道」这条路】
    # 我第一版只有第一维有，于是 interview_result 里那整条
    # 「证据不足」的分支**用户永远走不到**，从没被执行过——
    # 一条走不到的分支等于没写。
    if not has_none:
        bad.append((d, "没有「不知道」选项——「证据不足」这条路走不到"))

print()
print("=" * 74)
print("③ None 绝不能被当成低分")
print("=" * 74)
_M = [m for m in MAJORS if m.get("dims")]
_all_none = RES([None] * 7)
print(f"   七项全 None：一致 {len(_all_none['agree'])}　"
      f"落差 {len(_all_none['gap'])}　证据不足 {len(_all_none['unknown'])}")
print(f"   → 期望：一致 0、落差 0、**全部落到证据不足**")
if _all_none["agree"] or _all_none["gap"]:
    bad.append(("全 None 时给出了结论", ))
if len(_all_none["unknown"]) != len(_M):
    bad.append(("全 None 没有被全部归入证据不足",))
else:
    print(f"   ✓ {len(_M)} 个有画像的专业全部归入「证据不足」，"
          f"没有被判成落差")

# 单项 None：那一维不该造成任何落差
_one_none = RES([None] + [5] * 6)
print(f"   只第一项 None、其余全 5：落差 {len(_one_none['gap'])} 个")
_should_be_zero = [r for r in _one_none["gap"]]
if _should_be_zero:
    print(f"   ✗ 竟然有落差：{[(r[0]['n'], r[2]) for r in _should_be_zero[:3]]}")
    bad.append(("None 被当成了低分", [(r[0]['n'], r[2]) for r in _should_be_zero[:3]]))
else:
    print("   ✓ 没有因为「没答」产生任何落差")

# 答 0 分（不该出现）和答 1 分的区别
_all_one = RES([1] * 7)
print(f"   七项全答 1（最弱）：落差 {len(_all_one['gap'])} 个，"
      f"一致 {len(_all_one['agree'])} 个")
if _all_one["agree"]:
    bad.append(("全 1 竟然有一致的", [r[0]['n'] for r in _all_one['agree'][:3]]))

print()
print("=" * 74)
print("④ 落差和证据不足必须是两堆，不许混")
print("=" * 74)
_mixed = RES([5, 5, 5, 5, 5, 5, None])
_n = len(_mixed["agree"]) + len(_mixed["gap"]) + len(_mixed["unknown"])
print(f"   三堆加起来 {_n}，有画像的专业 {len(_M)}")
if _n != len(_M):
    bad.append(("三堆之和不对", _n, len(_M)))
else:
    print("   ✓ 三堆之和 = 有画像的专业数，一个不多一个不少")
_g_overlap = set(id(r[0]) for r in _mixed["gap"]) & \
    set(id(r[0]) for r in _mixed["unknown"])
if _g_overlap:
    bad.append(("同一个专业同时出现在落差和证据不足里", len(_g_overlap)))
else:
    print("   ✓ 没有专业同时出现在两堆里")

print()
print("=" * 74)
print("⑤ 落差的算法：它要的 > 我说的")
print("=" * 74)
print("   抽 3 个专业，手工核一遍落差算得对不对：")
for m in _M[:3]:
    a = [3] * 7
    r = RES(a)
    where = None
    for k in ("gap", "unknown", "agree"):
        for rec in r[k]:
            if rec[0] is m:
                where = (k, rec[2])
    _manual = [i for i in range(7) if a[i] < m["dims"][i]]
    _mine = [g[0] for g in (where[1] or [])]
    ok = sorted(_manual) == sorted(_mine)
    print(f"   {'✓' if ok else '✗'} {m['n']:14} dims={m['dims']}　"
          f"手工落差={_manual}　程序={_mine}")
    if not ok:
        bad.append((m['n'], "落差算法不一致", _manual, _mine))

print()
print("=" * 74)
print("⑥ 问句里不许出现「你适合」「推荐」这类话")
print("=" * 74)
_blob = "\n".join(q for q, _ in ASK) + "\n" + "".join(
    o[2] for d in OPT for o in OPT[d])
for _w in ("你适合", "推荐你", "最适合你", "你应该选"):
    if _w in _blob:
        bad.append(("问了不该问的话", _w))
        print(f"   ✗ 出现了「{_w}」")
    else:
        print(f"   ✓ 没有「{_w}」")

print()
print("=" * 74)
print("  ✓ 访谈层全部核对通过" if not bad else f"  ✗ {len(bad)} 处：{bad}")
