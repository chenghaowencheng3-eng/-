# -*- coding: utf-8 -*-
"""共享核心里**不许引用只存在于应用里的名字**。

【这一条是为哪一笔账写的】
`_mirror_core.interview_result(ans, majors=None)` 原来写的是
`for m in (MAJORS if majors is None else majors)`。
它在应用里跑得动，只因为应用把它内联进去之后，
全局命名空间里恰好有 `MAJORS`；
**一旦把 `_mirror_core.py` 本体单独执行，它就是 NameError。**

它是怎么被发现的：`_审计/_check_chat_interview.py` 拿共享核心本体
跑了一遍对照，当场崩。也就是说——
**这类 bug 平时是看不出来的，因为调用方总是把它内联进应用。**

【为什么不能只修那一处】
同一个毛病在 `_mirror_core.py` 里当时有两处
（`interview_result` 和 `spread_of_dim`）。
所以这里不是查某一个名字，而是**扫整个共享核心文件**：
凡是被它引用、而它自己没定义的模块级名字，都要报出来。
参数名、局部变量、内置名不算。
"""
import ast
import builtins
import io

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(
    _os.path.abspath(__file__))))
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")

# 【只查这几个共享文件】
# 它们是「可以被单独执行、也可能被内联」的两用文件，
# 这个约束只对它们成立。应用源文件（`_agent2_src.py` 等）
# 本来就活在应用命名空间里，不在此列。
SHARED = ["_mirror_core.py", "_cards_core.py", "_interview_core.py",
          "_tools_core.py"]

# `_tools_core.py` 是**故意**不独立的：它在装配时和 `_mirror_core`
# 内联到同一个命名空间，靠那边的 `ASK`/`OPTIONS`/`DIM_NAMES` 等工作。
# 把它列进来会让闸门红一片，而那不是缺陷、是设计。
# **要查的恰恰是「明明可以独立、却偷偷依赖全局」的那几个。**
ALLOWED_FROM_APP = {"_tools_core.py": {
    "interview_result", "ASK", "OPTIONS", "DIM_NAMES", "DIM_SHORT",
    "DIM_PLAIN", "_iv_words", "_iv_match", "_iv_norm", "_score_ok",
    "_quote_ok", "DEMAND_ASK", "DEMAND_LEVELS", "spread_of_dim",
    "DEMAND_ALLOW_UNKNOWN", "Q_OF", "demand_questions",
}}

_BUILTIN = set(dir(builtins))
bad = []


def chk(c, m):
    print(f"  {'✓' if c else '✗'} {m}")
    if not c:
        bad.append(m)


for fname in SHARED:
    path = f"{ROOT}\\{fname}"
    src = open(path, encoding="utf-8").read()
    tree = ast.parse(src)

    # 【哪些名字算「这个文件自己给的」】
    # 【我第一版漏了嵌套函数，于是误报两处】
    # 第一版只在**模块顶层**收集定义，所以像
    # `interview_result` 里面的 `def _sum(mj)`、
    # `run_tool` 里面的 `def norm(s)` 都没被算作「自己给的」，
    # 于是报成「外部名字」——**两条都是假红。**
    # 教训：分析器本身要先被验一遍，别急着信它报出来的东西。
    # 现在改成把**整棵树**都走一遍，所有绑定处（定义、赋值、
    # 参数、推导式变量、import、except as、with as）都收进来。
    defined = set()
    for n in ast.walk(tree):
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef,
                          ast.ClassDef)):
            defined.add(n.name)
        elif isinstance(n, ast.Name) and isinstance(n.ctx, ast.Store):
            defined.add(n.id)
        elif isinstance(n, (ast.Import, ast.ImportFrom)):
            for a in n.names:
                defined.add((a.asname or a.name).split(".")[0])
        elif isinstance(n, ast.arg):
            defined.add(n.arg)
        elif isinstance(n, ast.ExceptHandler) and n.name:
            defined.add(n.name)
        elif isinstance(n, ast.Global):
            defined.update(n.names)
        elif isinstance(n, ast.alias):
            defined.add((n.asname or n.name).split(".")[0])

    free = set()
    for n in ast.walk(tree):
        if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load):
            if n.id not in defined and n.id not in _BUILTIN:
                free.add(n.id)
    free -= ALLOWED_FROM_APP.get(fname, set())

    print()
    print("=" * 74)
    print(f"  {fname}：模块级定义 {len(defined)} 个，"
          f"引用到外部名字 {len(free)} 个")
    print("=" * 74)
    if free:
        print(f"     外部名字：{sorted(free)}")
    chk(not free, f"{fname} 不引用只存在于应用里的名字")
    for nm in sorted(free):
        print(f"       ✗ {nm}（它自己没定义，只能靠调用方的命名空间）")

# 【反向验证：这个闸门真的能抓到东西吗】
# 拿一段**故意依赖外部名字**的代码过一遍同样的逻辑。
# 一个从来没红过的闸门，等于没测过。
_probe = ast.parse("def f(x=None):\n    return x if x else OUTSIDE_NAME\n")
_p_def = {"f"}
for _n in ast.walk(_probe):
    if isinstance(_n, ast.Name) and isinstance(_n.ctx, ast.Store):
        _p_def.add(_n.id)
    if isinstance(_n, ast.FunctionDef):
        for _a in _n.args.args:
            _p_def.add(_a.arg)
_p_free = {n.id for n in ast.walk(_probe)
           if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load)
           and n.id not in _p_def and n.id not in _BUILTIN}
print()
chk(_p_free == {"OUTSIDE_NAME"},
    f"（反向验证）这段故意有问题的代码被查出来了：{sorted(_p_free)}")

print()
if bad:
    print(f"  ✗ {len(bad)} 项不过：")
    for b in bad:
        print(f"     {b}")
    sys.exit(1)
print("  ✓ 共享核心不偷偷依赖应用里的全局名字")
