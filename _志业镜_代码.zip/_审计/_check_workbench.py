# -*- coding: utf-8 -*-
"""访宽工作台的闸门：写进去的数据真的能流到牌里，而且坏数据进不来。

【为什么必须测到「进牌里」这一步】
工作台自己说「落盘了」不算数。**真正要证的是**：
一条记录写进 `_major_interviews.json` 之后，
`_build_major_game.py` 会不会把它并进牌里、
覆盖率数字会不会跟着涨、坏数据会不会被挡在门外。
中间任何一环断了，工作台就只是给一个没人读的文件追加行。

【这一层替身怎么做的】
不真去改动 `_majors.json`（那是人工数据，不能拿测试污染）。
而是把 `_major_interviews.json` 换成一个**临时库**，
跑 `_build_major_game.py`，看 `_majors_game.json` 有没有真的变——
跑完再把临时库还原成空。
"""
import io
import json
import os
import shutil
import subprocess

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(
    _os.path.abspath(__file__))))
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")

# 【解释器用正在跑这个闸门的那一个】
# 原来写死成运行时环境的绝对路径。那台机器上换个位置就找不到，
# 而且**这条闸门验的东西和哪个解释器无关**——
# 它跑的是 `_build_major_game.py`，纯标准库。
PY = sys.executable
STORE = f"{ROOT}\\_major_interviews.json"
GAME = f"{ROOT}\\_majors_game.json"
BAK = f"{ROOT}\\_审计\\_store_backup.json"

bad = []


def chk(c, m):
    print(f"  {'✓' if c else '✗'} {m}")
    if not c:
        bad.append(m)


def run(*args):
    return subprocess.run([PY, "-X", "utf8", *args], cwd=ROOT,
                          capture_output=True)


print("=" * 74)
print("① 现有的 94 个人工画像：每一维都得是真的，排序才稳得住")
print("=" * 74)
M = json.load(open(f"{ROOT}\\_majors.json", encoding="utf-8"))["majors"]
has = [m for m in M if m.get("dims")]
chk(len(has) == 94, f"有画像的 {len(has)} 个（应为 94）")
_partial = [(m.get("_name"), m["dims"]) for m in has
            if any(x is None for x in m["dims"])]
chk(not _partial,
    f"人工画像里没有留白（有 {len(_partial)} 个留白：{_partial[:3]}）")
_badval = [(m.get("_name"), m["dims"]) for m in has
           if not all(isinstance(x, int) and 1 <= x <= 5
                      for x in m["dims"] if x is not None)]
chk(not _badval, f"每一维都在 1—5（越界 {len(_badval)} 个）")
chk(all(len(m["dims"]) == 7 for m in has), "每一份都是 7 个数")

print()
print("=" * 74)
print("② 空库不影响现状（没记录时覆盖率就是 94）")
print("=" * 74)
shutil.copyfile(STORE, BAK)
cur = json.load(open(GAME, encoding="utf-8"))["majors"]
chk(sum(1 for m in cur if m.get("dims")) == 94,
    "空库时牌堆里有画像的还是 94 个")

print()
print("=" * 74)
print("③ 写一条进去 → 真的进到牌里")
print("=" * 74)
# 挑一个确实没有画像的、而且有真名的专业
_miss = [m for m in cur if not m.get("dims")]
_target = next(m for m in _miss if m.get("n") == "农学")
print(f"  目标专业：{_target['n']}（现在 dims = {_target.get('dims')}）")

seed = {"records": [{
    "major": "农学",
    "dims": [3, 3, 3, 5, None, 3, 5],
    "who": "闸门自测用·不是真访谈",
    "on": "2026-10-13",
    "evidence": ["闸门自测，不是真人说的"],
    "tier": "C1"}]}
json.dump(seed, open(STORE, "w", encoding="utf-8"),
          ensure_ascii=False, indent=2)
r = run("_build_major_game.py")
chk(r.returncode == 0, f"重建跑通（exit {r.returncode}）")
g = json.load(open(GAME, encoding="utf-8"))["majors"]
n_now = sum(1 for m in g if m.get("dims"))
chk(n_now == 95, f"有画像的变成 {n_now} 个（应为 95）")
t = next(m for m in g if m.get("n") == "农学")
chk(t.get("dims") == [3, 3, 3, 5, None, 3, 5],
    f"农学的 dims 真的是写进去那份：{t.get('dims')}")
chk(t.get("dims_tier") == "C1", f"等级标成 {t.get('dims_tier')}")
chk("访谈工作台" in str(t.get("dims_src")),
    f"出处写明了是工作台来的：{t.get('dims_src')}")
chk(t.get("dims_src") and "闸门自测" in t["dims_src"],
    "出处里带了受访者署名")

print()
print("=" * 74)
print("④ 已经有画像的专业，**不能被静默改掉**")
print("=" * 74)
_before = next(m for m in g if m.get("n") == "建筑学")["dims"]
seed = {"records": [
    {"major": "农学", "dims": [3, 3, 3, 5, None, 3, 5],
     "who": "闸门自测", "on": "2026-10-13", "evidence": ["自测"]},
    {"major": "建筑学", "dims": [1, 1, 1, 1, 1, 1, 1],
     "who": "故意来捣乱的", "on": "2026-10-13", "evidence": ["自测冲突"]}]}
json.dump(seed, open(STORE, "w", encoding="utf-8"),
          ensure_ascii=False, indent=2)
r = run("_build_major_game.py")
_after = next(m for m in json.load(open(GAME, encoding="utf-8"))["majors"]
              if m.get("n") == "建筑学")["dims"]
chk(_after == _before,
    f"建筑学的画像没被动（人工 {_before}，还是 {_after}）")
prev = open(f"{ROOT}\\_majors_preview.txt", encoding="utf-8").read()
chk("和已有画像冲突、没动的：1 个" in prev,
    "冲突被报出来了，不是静默忽略")

print()
print("=" * 74)
print("⑤ 坏数据一条都不许进（工作台自己的校验）")
print("=" * 74)
evil = {"records": [
    {"major": "库里没有的专业", "dims": [3] * 7, "who": "x",
     "on": "2026-10-13", "evidence": ["y"]},
    {"major": "动物医学", "dims": [3, 3, 9, 5, 3, 3, 4], "who": "x",
     "on": "2026-10-13", "evidence": ["y"]},
    {"major": "林学", "dims": [3, 3, 3], "who": "x", "on": "2026-10-13",
     "evidence": ["y"]},
    {"major": "园艺", "dims": [3, 3, 3, 5, 3, 3, 4], "who": "",
     "on": "2026-10-13", "evidence": ["y"]},
    {"major": "水产养殖学", "dims": [3, 3, 3, 5, 3, 3, 4], "who": "x",
     "on": "", "evidence": ["y"]}]}
json.dump(evil, open(STORE, "w", encoding="utf-8"),
          ensure_ascii=False, indent=2)
r = run("_iv_workbench.py", "--from-file", "_major_interviews.json")
out = r.stdout.decode("utf-8", "replace")
chk("没写进去" in out, "五条坏数据全被拒（输出里逐条说了原因）")
chk("库里没有「库里没有的专业」" in out, "「库里没这个专业」被指出")
chk("要 1—5，给了 9" in out, "越界的 9 被指出")
chk("要 7 个数，给了 3" in out, "只给 3 个被指出")
chk(r.returncode == 1, f"退出码是 1（实际 {r.returncode}）——坏数据算失败")
# 【断言要改对方向】
# 我第一版断言「库里还是空的」——那**是错的**：
# `--from-file _major_interviews.json` 读的就是那个文件本身，
# 坏数据当然还在文件里。工作台拒的是**写**，不是删源文件。
# 真正该证的是：**它们进不了牌堆。**
_saved = json.load(open(STORE, encoding="utf-8"))["records"]
chk(all(x["major"] == "库里没有的专业" or x["major"] == "动物医学"
        or x["major"] == "林学" or x["major"] == "园艺"
        or x["major"] == "水产养殖学" for x in _saved),
    f"文件里仍然是那 5 条坏数据（{len(_saved)} 条），没有新增")
r = run("_build_major_game.py")
g2 = json.load(open(GAME, encoding="utf-8"))["majors"]
n_after_evil = sum(1 for m in g2 if m.get("dims"))
chk(n_after_evil == 94,
    f"坏数据一条都没进牌堆（有画像的还是 {n_after_evil} 个）")
_t = next((m for m in g2 if m.get("n") == "动物医学"), None)
chk(_t is not None and not _t.get("dims"),
    "「动物医学」那个越界的 9 没有被写成画像")
chk(next((m for m in g2 if m.get("n") == "林学"), {}).get("dims") is None,
    "「林学」那份只有 3 个数的没被收下")

print()
print("=" * 74)
print("⑥ 还原成空库")
print("=" * 74)
shutil.copyfile(BAK, STORE)
r = run("_build_major_game.py")
g = json.load(open(GAME, encoding="utf-8"))["majors"]
n_end = sum(1 for m in g if m.get("dims"))
chk(n_end == 94, f"还原后回到 94 个（实际 {n_end}）")
chk(not json.load(open(STORE, encoding="utf-8"))["records"],
    "库是空的")

print()
if bad:
    print(f"  ✗ {len(bad)} 项不过：")
    for b in bad:
        print(f"     {b}")
    sys.exit(1)
print("  ✓ 工作台到牌堆这条链路是通的，坏数据进不来，人工数据不会被改")
