# -*- coding: utf-8 -*-
"""对话应用（志业镜.py）里有没有新加的字段？

【为什么必须查】
`sources_rows` 是**两个应用共用**的（装配时用同一份 _majors_src.py）。
我刚往里加了读 `m.get("avoid_tier")` 的一行。
如果对话应用内嵌的专业数据里没有这个字段，
那它里面所有专业都会被标成「公开资料整理·没有逐一核实」——
**包括那 6 个真的逐个访谈核实过的。**
这和卡片应用刚出过的坑是同一个：代码写了，数据到不了，不报错。
"""
import io
import json
import re
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")

for f in ("志业镜.py", "_majors_src.py"):
    s = open(f, encoding="utf-8").read()
    print("=" * 70)
    print(f"{f}　{len(s):,} 字符")
    for kw in ('"avoid"', '"avoid_tier"', '"ir"', '"tilt"', "sources_rows",
               "什么情况会让你想跑", "avoid_block", "ai_block"):
        print(f"   {kw:26} {s.count(kw):5} 次")
    # 试着把内嵌的 JSON 取出来
    for var in ("MAJOR_DATA", "MAJORS", "_MAJOR_DATA"):
        i = s.find(f"{var} = json.loads(")
        if i < 0:
            i = s.find(f"{var} = ")
        if i >= 0:
            print(f"   → 找到 {var} 的定义在 {s[:i].count(chr(10)) + 1} 行")
    print()

# 用 json 直接抽第一段大 JSON，看键
s = open("志业镜.py", encoding="utf-8").read()
m = re.search(r'json\.loads\(r"""(\{.*?\})"""\)', s, re.S)
if m:
    try:
        d = json.loads(m.group(1))
        print("=" * 70)
        print("对话应用内嵌的第一段 JSON，顶层键：", list(d.keys())[:12])
        for k, v in list(d.items())[:1]:
            if isinstance(v, dict):
                print(f"   {k} 的子键：{list(v.keys())[:30]}")
            elif isinstance(v, list) and v and isinstance(v[0], dict):
                print(f"   {k} 是列表，第一项键：{list(v[0].keys())[:40]}")
    except Exception as e:
        print("   解析失败：", type(e).__name__, e)
else:
    print("（没匹配到 json.loads(r\"\"\"...\"\"\") 形式）")

# 对话应用里的专业数据到底长什么样：找 n / dims 这类键
s2 = open("志业镜.py", encoding="utf-8").read()
for probe in ('"dims"', '"cost_hours"', '"suits"', '"chsi_jyfx"', '"core"'):
    print(f"   {probe:16} {s2.count(probe):5} 次")
