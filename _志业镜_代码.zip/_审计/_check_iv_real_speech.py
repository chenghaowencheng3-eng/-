# -*- coding: utf-8 -*-
"""访谈在**真人话**上到底能不能用——这是核心功能，不是演示效果。

【背景：为什么重写这一层】
原来模型要把**用户的原话**当 answer 传回来，代码拿它跟选项标签比字面。
我用 15 句真人会说的话试过：**只对 3 句。**
「一道题卡一星期也会接着做」和选项「失败了反而更想弄明白为什么」
之间一个字都不重合——中文短文本字面匹配的天花板就在这。

改成：**模型判断语义（它擅长），代码校验它的依据（它不擅长撒谎）。**
模型要把他的回答判成某一档，就必须把依据的那句话照抄回来，
代码核对引文真的在他的话里。

【这一层测什么】
  ① 真人话：模型判分 + 真引文 → 分对
  ② 恶意：编引文 / 给非法分 / 引文只一个字 → 一律不采信
  ③ 合法答案「没试过」 → 记不知道，不是低分
  ④ 老路（字面匹配）还在，不该崩
"""
import io

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(
    _os.path.abspath(__file__))))
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")

sys.path.insert(0, ROOT)
from _mirror_core import OPTIONS                    # noqa: E402
from _tools_core import DIM_KEYS, interview_run     # noqa: E402

bad = []


def fresh():
    return {"iv": {}, "trace": []}


print("=" * 78)
print("① 真人话：模型判分 + 他真说过的引文")
print("=" * 78)
# (维度, 用户说的话, 模型判的分, 模型交的引文, 期望记下的分)
SPOKEN = [
    ("认知负荷", "我坐得住，能一口气看两三个小时", 4,
     "能一口气看两三个小时", 4),
    ("认知负荷", "坐不住，看十分钟就想刷手机", 2, "看十分钟就想刷手机", 2),
    ("记忆量", "基本不背，理解就行", 1, "基本不背，理解就行", 1),
    ("记忆量", "背得挺多的，一个学期几百个名词", 5,
     "一个学期几百个名词", 5),
    ("动手要求", "手残，装个椅子都能装反", 1, "装个椅子都能装反", 1),
    ("动手要求", "拆过家里的旧电脑，还装回去了", 5,
     "拆过家里的旧电脑，还装回去了", 5),
    ("自驱要求", "没人催就不动", 2, "没人催就不动", 2),
    ("自驱要求", "有过一个自己啃了半年的爱好", 5,
     "自己啃了半年的爱好", 5),
    ("挫折耐受", "错一次就不想再试了", 1, "错一次就不想再试了", 1),
    ("挫折耐受", "一道题卡一星期也会接着做", 5,
     "一道题卡一星期也会接着做", 5),
    ("慢反馈耐受", "干一个月没反馈就撤", 1, "一个月没反馈就撤", 1),
    ("慢反馈耐受", "一个项目做了两年，中间一直没人夸", 5,
     "做了两年，中间一直没人夸", 5),
]
n_ok = 0
for dim, said, sc, quote, want in SPOKEN:
    ctx = fresh()
    r = interview_run({"dimension": dim, "score": sc, "quote": quote,
                       "answer": said}, ctx)
    got = ctx["iv"].get(dim)
    ok = got == want
    n_ok += ok
    print(f"  {'✓' if ok else '✗'} {dim}　「{said}」")
    print(f"        模型判 {sc} + 引文「{quote}」→ 记下 {got}（期望 {want}）")
    if not ok:
        bad.append((dim, said, got, want))
print(f"\n  {n_ok}/{len(SPOKEN)} 条")

print()
print("=" * 78)
print("② 恶意：模型想蒙混，看拦不拦得住")
print("=" * 78)
# 【期望值：全 None】
# 第一版我把「编引文」期望成 1——因为旧代码拒了假依据之后
# **退回字面匹配**，从用户真话里捞出了正确的 1 分。
# 结果碰巧对，语义是错的：模型交了假依据，回一个分给它，
# 而且事后分不清「模型试了没成」还是「模型没试」。
# 现在两条路互斥，所以这些**全部**该记 None。
EVIL = [
    ("编一句用户没说过的话当引文",
     {"dimension": "记忆量", "score": 5,
      "quote": "我背下了整本教材", "answer": "基本不背，理解就行"}),
    ("引文只一个字（「我」）",
     {"dimension": "记忆量", "score": 5, "quote": "我",
      "answer": "基本不背，理解就行"}),
    ("给一个这一维根本没有的分（4）",
     {"dimension": "记忆量", "score": 4,
      "quote": "背得挺多的", "answer": "背得挺多的，一个学期几百个名词"}),
    ("引文对但分数不是选项里的（0）",
     {"dimension": "认知负荷", "score": 0, "quote": "看十分钟就想刷手机",
      "answer": "坐不住，看十分钟就想刷手机"}),
    ("引文是改写过的（不是照抄）",
     {"dimension": "挫折耐受", "score": 5,
      "quote": "遇到难题会一直做下去", "answer": "一道题卡一星期也会接着做"}),
    ("给了分但引文空着",
     {"dimension": "动手要求", "score": 5, "quote": "",
      "answer": "拆过家里的旧电脑"}),
]
for why, args in EVIL:
    ctx = fresh()
    interview_run(args, ctx)
    got = ctx["iv"].get(args["dimension"])
    reason = (ctx.get("iv_why") or [("", "", "")])[-1]
    ok = got is None
    print(f"  {'✓' if ok else '✗'} {why}")
    print(f"        记下 {got}（期望 None）　可以说清原因：{reason[1]}")
    if not ok:
        bad.append((why, got, None))

# 反证：模型**没**给分、只转述原话 → 字面匹配照样能用
print()
print("   反证：模型没给分、老实转述原话（这条老路还在）：")
ctx = fresh()
interview_run({"dimension": "认知负荷",
               "answer": "有，连着熬过，而且是常态"}, ctx)
got = ctx["iv"].get("认知负荷")
print(f"     记下 {got}（期望 5）")
if got != 5:
    bad.append(("转述原话", got, 5))

print()
print("=" * 78)
print("③ 「没试过」是合法答案，不是低分")
print("=" * 78)
for dim, said in (("记忆量", "没试过"), ("挫折耐受", "说不好"),
                  ("慢反馈耐受", "想不起来")):
    ctx = fresh()
    interview_run({"dimension": dim, "answer": said}, ctx)
    got = ctx["iv"].get(dim)
    ok = got is None
    print(f"  {'✓' if ok else '✗'} {dim}　「{said}」→ 记下 {got}"
          f"（None = 不知道，不是低分）")
    if not ok:
        bad.append((dim, said, got, None))

print()
print("=" * 78)
print("④ 老路还在：直接给选项原话，照样认得出")
print("=" * 78)
for dim in DIM_KEYS:
    # 取这一维分数最高那条选项的原话
    opts = [o for o in OPTIONS[dim] if o[0] is not None]
    sc, label, _r = max(opts, key=lambda o: o[0])
    ctx = fresh()
    interview_run({"dimension": dim, "answer": label}, ctx)
    got = ctx["iv"].get(dim)
    ok = got == sc
    print(f"  {'✓' if ok else '✗'} {dim}　最高档原话 → {got}（期望 {sc}）")
    if not ok:
        bad.append((dim, "原话", got, sc))

print()
if bad:
    print(f"  ✗ {len(bad)} 处不对：")
    for b in bad:
        print(f"     {b}")
else:
    print("  ✓ 访谈在真人话上可用，而且蒙混不过去")
