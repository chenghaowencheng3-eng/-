# -*- coding: utf-8 -*-
"""合并后的名字撞车检查。

【为什么要专门查】
刚把 `_cards_core.py` 注入对话版，而两个模块里都有 `IR_NAMES`。
撞车的症状**不是报错**，是「后定义的悄悄把前面的盖掉」——
`_majors_src.py` 里就吃过这个：`CAT_IDX` 那个变量因为叫了 `CATALOG`
把官方目录的元数据整个盖掉，侧栏「官方目录共 N 个专业」变成 None，
**6 条测试同时变红，而症状出现在完全不相干的地方。**

所以：同一个名字在生成的文件里出现两次定义 → 必须报出来。
"""
import ast
import io
import sys
from collections import defaultdict

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(
    _os.path.abspath(__file__))))
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")

bad = []


def chk(c, m):
    print(f"  {'✓' if c else '✗'} {m}")
    if not c:
        bad.append(m)


for fname in ("志业镜.py", "职业游乐场.py"):
    path = f"{ROOT}\\{fname}"
    tree = ast.parse(open(path, encoding="utf-8").read())
    defs = defaultdict(list)
    for n in tree.body:
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef,
                          ast.ClassDef)):
            defs[n.name].append(n.lineno)
        elif isinstance(n, ast.Assign):
            for t in n.targets:
                if isinstance(t, ast.Name):
                    defs[t.id].append(n.lineno)
    dups = {k: v for k, v in defs.items() if len(v) > 1}
    print()
    print(f"  {fname}：模块级定义 {len(defs)} 个，"
          f"同名重复 {len(dups)} 个")
    chk(not dups, f"{fname} 没有同名重复定义")
    for k, v in sorted(dups.items()):
        print(f"       ✗ {k} 在第 {v} 行各定义了一次"
              f"（后一个会静默盖掉前一个）")

# 卡片模块和对话版之间，**故意的**同名要单独确认语义一致
_c = ast.parse(open(f"{ROOT}\\_cards_core.py", encoding="utf-8").read())
_a = ast.parse(open(f"{ROOT}\\_agent2_src.py", encoding="utf-8").read())


def consts(tree, name):
    for n in tree.body:
        if isinstance(n, ast.Assign):
            for t in n.targets:
                if isinstance(t, ast.Name) and t.id == name:
                    try:
                        return ast.literal_eval(n.value)
                    except Exception:
                        return "（算不出来）"
    return None


print()
print("  两边同名的常量，语义必须一致：")
for nm in ("IR_NAMES",):
    _cv, _av = consts(_c, nm), consts(_a, nm)
    print(f"     {nm}：卡片模块 {_cv}　对话版 {_av}")
    if _cv is not None and _av is not None:
        chk(_cv == _av, f"{nm} 两边一致")

print()
if bad:
    print(f"  ✗ {len(bad)} 项不过：")
    for b in bad:
        print(f"     {b}")
    sys.exit(1)
print("  ✓ 合并后没有名字撞车")
