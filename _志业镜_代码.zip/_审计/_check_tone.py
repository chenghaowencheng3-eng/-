# -*- coding: utf-8 -*-
"""语言闸门：那些「人机话」不许再回来。

【为什么这条要单独有闸门】
用户的原话是「一些比较人机的话太多了，会让人比较烦」，
并且明确要「真正的交谈」。这类问题**测试不会红、页面不会崩**，
只有人看着烦——所以必须把「不许出现」写成硬断言，
否则下次改文案时很容易又漂回去。
"""
import io
import re

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(
    _os.path.abspath(__file__))))
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")

bad = []


def chk(c, m):
    print(f"  {'✓' if c else '✗'} {m}")
    if not c:
        bad.append(m)


def user_text(path, source=False, drop_prompt=False):
    """只取**会给用户看到的**文字。

    【为什么要剔掉注释、docstring 和 CSS】
    源码里大量文字是写给我自己看的（「不许各写一套」这种是**给我的指令**，
    不是给用户的）。把它们算进来会得出「界面很凶」这个错结论——
    同一个错我在 `_test_majors.py` 的 `blob()` 上刚犯过一次
    （把 4,332 字 CSS 当成「界面文字」）。
    docstring 也要剔：`_prompt_core.py` 里那段
    「✗『这个我不能说』（堵门）」**是反面示范**，
    抓关键词会把它当成违规——**这个假红我第一版就踩了。**

    【为什么只剔 docstring 还不够】
    产品里嵌着**系统提示词的全文**（`SYSTEM_PROMPT = \"\"\"...\"\"\"`），
    它不是 docstring，是模块级变量，所以上面那套剔不掉它。
    而提示词里**故意**写着 `✗「我不替你挑」` 这种反面示范——
    那是给模型看的，不是给用户看的。
    所以再给一个 `drop_prompt=True`：**按内容**把提示词那一段切掉。
    用内容当锚点、不用变量名——名字会改，内容不会。

    `source=True` 拿**原文**（含注释）。
    切片必须用原文：注释里为了留历史，会引用被删掉的那些句子。
    """
    import ast
    src = open(path, encoding="utf-8").read()
    if source:
        return src
    src = re.sub(r"<style[^>]*>.*?</style>", "", src, flags=re.S)
    if drop_prompt:
        src = _cut_prompt(src)
    tree = ast.parse(src)
    # 把所有 docstring 的位置标出来
    doc_lines = set()
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef,
                             ast.AsyncFunctionDef, ast.ClassDef)):
            body = getattr(node, "body", None)
            if (body and isinstance(body[0], ast.Expr)
                    and isinstance(body[0].value, ast.Constant)
                    and isinstance(body[0].value.value, str)):
                d = body[0]
                doc_lines |= set(range(d.lineno, (d.end_lineno or d.lineno) + 1))
    out = []
    for i, line in enumerate(src.splitlines(), start=1):
        s = line.strip()
        if s.startswith("#") or i in doc_lines:
            continue
        out.append(line)
    return "\n".join(out)


def _prompt_body():
    """提示词正文（`_prompt_core.py` 里那个三引号字符串的内容）。"""
    _p = open(f"{ROOT}\\_prompt_core.py", encoding="utf-8").read()
    _i = _p.find("SYSTEM_PROMPT")
    _b = _p[_p.find('"""', _i) + 3:]
    return _b[:_b.find('"""')]


def _cut_prompt(src):
    """按**内容**把嵌在文件里的系统提示词那一整段切掉。

    切不掉就**当场报错**，不许静默放过——
    静默放过的表现是「这条闸门查了一堆它不该查的东西」，
    而那看起来像「有内容可查」，不像出错。
    """
    body = _prompt_body()
    anchor = re.sub(r"\s+", "", body)[:60]
    if anchor not in re.sub(r"\s+", "", src):
        raise SystemExit(
            "  ✗ 文件里找不到系统提示词，这条闸门**测不到东西**，"
            f"不能当它过了。锚点：{anchor[:30]!r}")
    # 在原文里定位：用提示词开头那 12 个字（去掉首尾空白）
    head = body.strip()[:12]
    k = src.find(head)
    if k < 0:
        raise SystemExit(f"  ✗ 定位不到提示词开头：{head!r}")
    tail = body.strip()[-12:]
    m = src.find(tail, k)
    if m < 0:
        raise SystemExit(f"  ✗ 定位不到提示词结尾：{tail!r}")
    return src[:k] + src[m + len(tail):]


def prompt_text():
    """提示词全文。

    **提示词要单独看**：它是给模型的指令，里面**故意**放着
    「✗『这个我不能说』」这种反面示范。在这里抓关键词是抓错了地方。
    """
    return open(f"{ROOT}\\_prompt_core.py", encoding="utf-8").read()


SOURCES = {
    "对话版源": f"{ROOT}\\_agent2_src.py",
    "提示词": f"{ROOT}\\_prompt_core.py",
    "牌局源": f"{ROOT}\\_majors_src.py",
}

print("=" * 74)
print("  ① 「堵门」式说法不许再出现在**用户能看到的地方**")
print("=" * 74)
# 这些是把用户挡在门外的说法。**注意区分**：
#   「这个我手上没有材料」= 说实话（留着）
#   「这个我不能说」/「不给你看」= 堵门（清掉）
#
# 【提示词不在这一节里查】它里面**故意**放着「✗『这个我不能说』」，
# 那是教模型别这么说。在这里查它等于把反面教材当违规。
BLOCKING = ["我不能说", "不给你看", "不告诉你", "这个我不讲",
            "不方便说", "无可奉告"]
for label, path in (("对话版源", f"{ROOT}\\_agent2_src.py"),
                    ("牌局源", f"{ROOT}\\_majors_src.py")):
    t = user_text(path)
    for w in BLOCKING:
        chk(w not in t, f"{label} 没有「{w}」")

# 提示词里查的是**另一件事**：那些堵门的话只能出现在 ✗ 那一侧
P = prompt_text()
_lines = P.splitlines()
_hits = [l.strip() for l in _lines
         if "这个我不能说" in l or "不给你看" in l or "不告诉你" in l]
print(f"     提示词里提到堵门说法 {len(_hits)} 处，逐条看是不是反面示范：")
for h in _hits:
    _ok = "✗" in h or "别" in h or "不要" in h or "堵门" in h
    chk(_ok, f"  这处是反面示范：{h[:60]}")
if not _hits:
    chk(True, "  （提示词里一处都没提到——也合格）")

print()
print("=" * 74)
print("  ② 提示词要给出「可以说」的正面示范，不能只有禁令")
print("=" * 74)
chk("你也有想法，可以说出来" in P, "提示词明说「你也有想法，可以说出来」")
chk("只要说清那是你的想法" in P, "要求区分「我的看法」和「事实」")
chk("别装懂" in P, "正面写出「别装懂」，而不是一堆「不许」")
# 【禁令词密度】这是这次改动的核心指标：通篇「不许/绝不」会漏到用户耳朵里
_n_ban = len(re.findall(r"不许|绝不|禁止|严禁", P))
print(f"     提示词里「不许/绝不/禁止/严禁」出现 {_n_ban} 次")
chk(_n_ban <= 2, f"禁令词 ≤ 2 次（实际 {_n_ban}）——语气靠示范，不靠吼")
_n_bad = len(re.findall(r"✗", P))
_n_good = len(re.findall(r"✓", P))
print(f"     正反示范：✗ {_n_bad} 处　✓ {_n_good} 处")
chk(_n_bad >= 3, f"反面例子还在（✗ {_n_bad} 处）")
# 【这条我第一版写错了】要求 ✓ ≥ 3，但提示词里只有 2 处 ✓。
# 看过之后：这里**不需要 3 处**——✓ 是示范「该怎么说」，
# 2 个具体例子已经把「说出来但标明是自己的看法」讲清了。
# 硬凑到 3 个只会往里塞水话。所以门槛改成「至少和 ✗ 一样能对上话」：
chk(_n_good >= 2, f"正面例子至少 2 处（✓ {_n_good} 处）")

print()
print("=" * 74)
print("  ③ 人格设定：要像个大几岁的人，不是客服")
print("=" * 74)
for w in ("比他大几岁", "把他当一个能听懂话的人"):
    chk(w in P, f"提示词里有「{w}」")
# 【这三句是「别用」清单】它们本来就长这样，不是违规。
# 我第一版断言 `f"别用「{w}」" in P`——对「我理解你的感受」成立，
# 但另两句在原文里是合成一句写的（「别用『我理解你的感受』
# 『希望对你有帮助』『让我们一起』」），于是假红。
# 改成：**只要这三句都出现在「别用」那一行的上下文里**就行。
_cs = [l for l in P.splitlines() if "别用" in l or "希望对你有帮助" in l]
_ctx = "\n".join(_cs)
for w in ("我理解你的感受", "希望对你有帮助", "让我们一起"):
    chk(w in _ctx, f"仍然禁止客服腔「{w}」")

print()
print("=" * 74)
print("  ④ 界面文字：越界时的说法要留门，不要关门")
print("=" * 74)
M = user_text(f"{ROOT}\\_majors_src.py")
A = user_text(f"{ROOT}\\_agent2_src.py")
# 【产品本身也要查】只查源会漏掉「源干净、产物脏」的情况
# （产物是拼出来的，拼接过程本身可能带进东西）。
AP = user_text(f"{ROOT}\\志业镜.py")
chk("查不到我直说" in M, "查不到时说的是「我直说」")
chk("没有材料我就不编" in M, "立场还在：没有材料就不编")
chk("我只把我真有的给你" in M, "说清「给真有的」，不是「不给」")
chk("我就不装细了" in M or "我就不装细了" in M, "画像粗细那句改成人话了")
chk("我手上有什么、没有什么" in A, "折叠区标题改成大白话")

print()
print("=" * 74)
print("  ⑤ 【不许把「我不替你决定」说出口】")
print("=" * 74)
# 【这条是用户直接要求的，所以要做成反向断言】
# 用户原话：「不需要你管做不做决定」。
# 那道线由**代码**守着（`guard` 里的 BANNED 一个字没动），
# 但**一个字都不许漏到界面上**——
# 「我不替你挑」这种话看起来像负责，其实是**在提醒用户
# 我们防着他**，而且它本身就是一种表态。
#
# 【为什么必须做成断言】
# 这类话说起来「感觉很对」，最容易在改文案时被重新加回来。
# 断言在这里，下次谁想加都得先改这条闸门——那时候就会想起来为什么删。
#
# 注意：只查**界面文字**，不查注释、也不查嵌在应用里的**系统提示词**。
# 注释里要留着这段历史，不然下一个人还会把它加回去。
#
# 【提示词为什么必须排除】
# 产品里嵌着 `_prompt_core.py` 的**全文**，而提示词里
# **故意**写着 `✗「这个我不能说」「我不替你挑」` 这种反面示范——
# 那是给模型看的「这么说不行」，不是给用户看的。
# （我第一次写这条断言时整份产物一起扫，4 项全红，全是假红；
# 第二次去切提示词，结果拿 `user_text()` 剥过 docstring 的文本去切——
# **提示词在产物里就是 `SYSTEM_PROMPT = \"\"\"...\"\"\"`，
# 正好是被剥掉的那种**，所以那份文本里压根没有它。
# 两个数字互相矛盾的时候，是我搞错了对象，不是数据在骗人。）
UI = re.sub(r"\s+", "", user_text(f"{ROOT}\\志业镜.py", drop_prompt=True))

_NO_SAY = ["我不替你挑", "不替你挑", "这句我不替你说", "替你挑专业了",
           "这是替你做决定", "越线了", "我自己收回来"]
_SRCS = [("_agent2_src.py", re.sub(r"\s+", "", A)), ("志业镜.py 界面", UI)]
for _w in _NO_SAY:
    _in = [nm for nm, src in _SRCS if _w in src]
    chk(not _in, f"界面文字里没有「{_w}」（出现在 {_in}）")
# 但提示词里也要说清：**别讲你为什么讲不了**
chk("把机制讲出来" in P, "提示词明说「别把机制讲出来」")
chk("表态和免责声明都不要" in P, "提示词明说「表态和免责声明都不要」")
# 【反向也验一下】提示词里不许再写「你不替他做决定」当第一条
chk("你不替他做决定" not in P,
    "提示词第一条不再是「你不替他做决定」（改成「给东西，不给结论」了）")

print()
if bad:
    print(f"  ✗ {len(bad)} 项不过：")
    for b in bad:
        print(f"     {b}")
    sys.exit(1)
print("  ✓ 语言：不堵门、有正面示范、禁令词收敛、人格立住了")
