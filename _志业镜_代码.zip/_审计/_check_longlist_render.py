# -*- coding: utf-8 -*-
"""长名单/短名单的说法：**对话版里也必须分得开**。

【为什么重写这个闸门，而不是改个路径将就用】
原来这一版是把答案塞进牌局那套 session_state（`s["iv_ans"]`、
`mode="iv_res"`）跳到结果页去看。产品合并成一个应用之后那套 state 没了。
我可以照搬去适配对话版的 state——但那样测的仍然是**接线**，
而这段文案的实质是**一个纯函数**：给它 counts/gaps/long_list，
它该输出哪几句。测纯函数更稳，也不会因为界面改版就假红。

【但「接线」不能因此没人管】
`_审计/_check_interview_in_chat.py` 负责那件事：
它真的点侧栏、真的走完七题、真的读页面上的字。
两个闸门各管一头，不重复。
"""
import io

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(
    _os.path.abspath(__file__))))
sys.path.insert(0, ROOT)
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")

import _interview_core as IV                                     # noqa: E402

bad = []


def chk(c, m):
    print(f"  {'✓' if c else '✗'} {m}")
    if not c:
        bad.append(m)


_mc = {}
exec(compile(open(f"{ROOT}\\_mirror_core.py", encoding="utf-8").read(),
             "_mirror_core.py", "exec"), _mc)
DIM_NAMES = _mc["DIM_NAMES"]

CASES = [
    # (标签, counts, gaps, long_list, 该出现 / 不该出现)
    ("长名单 42 个",
     {"对得上": 42, "有落差": 52, "证据不足": 0},
     [{"major": "城乡规划", "why": ["动手要求：它要 5，他答 3"]}],
     True,
     ["这个数太大，等于没说", "确实宽", "愿意先试一下", "不装细"],
     # 【这条禁令我一开始写错了】原写 `"不是「适合你」"`——
     # 而立场句「**这**不是「适合你」」里正好含这个子串，
     # 于是「**没有**说」那条永远红。
     # **拿子串去禁另一句话，会禁到自己。**
     # 长名单真正不该说的是短名单那句「可以先去翻一翻」。
     ["这几个可以先去翻一翻"]),
    ("短名单 3 个",
     {"对得上": 3, "有落差": 91, "证据不足": 0},
     [{"major": "建筑学", "why": ["细节分辨：它要 5，他答 3"]}],
     False,
     ["它都要得起的：3 个", "落差最小的"],
     ["这个数太大", "愿意先试一下"]),
    ("一个都对不上",
     {"对得上": 0, "有落差": 94, "证据不足": 0},
     [{"major": "数学与应用数学", "why": ["认知负荷：它要 5，他答 2"]}],
     False,
     ["一个都对不上", "你都说自己受不了", "落差最小的"],
     ["这个数太大", "它都要得起的"]),
]

for label, counts, gaps, long_list, yes, no in CASES:
    print()
    print("=" * 74)
    print(f"  {label}")
    print("=" * 74)
    rows = IV.interview_result_rows(counts, ["建筑学", "电气工程及其自动化"],
                                    gaps, long_list, DIM_NAMES)
    blob = "\n".join(rows)
    for w in yes:
        chk(w in blob, f"说了「{w}」")
    for w in no:
        chk(w not in blob, f"**没有**说「{w}」")
    # 【这四条立场在三种情况下都必须都在】
    for w in ("这不是「适合你」", "受得了不等于愿意干",
              "没有校准", "一个字都没问你家里"):
        chk(w in blob, f"结果页有立场「{w}」")
    print(f"     共 {len(rows)} 行")

# 【长名单那一支必须比短名单长】——它多说了两件事：
# 「这个数太大」和「画像的粗细」。少了就是把长名单当短名单糊过去了。
_rl = IV.interview_result_rows(
    {"对得上": 42, "有落差": 52, "证据不足": 0}, [], [], True, DIM_NAMES)
_rs = IV.interview_result_rows(
    {"对得上": 3, "有落差": 91, "证据不足": 0}, [], [], False, DIM_NAMES)
print()
print(f"  长名单 {len(_rl)} 行　短名单 {len(_rs)} 行")
chk(len(_rl) > len(_rs), "长名单比短名单多说东西（不是同一套话）")

print()
if bad:
    print(f"  ✗ {len(bad)} 项不过：")
    for b in bad:
        print(f"     {b}")
    sys.exit(1)
print("  ✓ 长/短/零 三种名单的说法分得开，四条立场三种情况都在")
