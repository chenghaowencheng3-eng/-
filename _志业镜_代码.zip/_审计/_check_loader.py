# -*- coding: utf-8 -*-
"""先验证加载器本身，再拿它去改闸门。

【为什么要单独验它】
它会成为好几个闸门的地基。地基错了，上面所有闸门都会
「看起来在测、其实测的是别的东西」——**这个仓库最贵的一类错。**
所以先确认：
  ① 产物是新鲜的（旧的比没有更糟）
  ② 161 张牌 / 94 份画像 / 目录 883 条 都对
  ③ 它和**产品本体**（志业镜.py）的数据逐字段一致
  ④ 缺东西时报错，不静默给空
"""
import io
import json
import os
import re

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(
    _os.path.abspath(__file__))))
sys.path.insert(0, ROOT)
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")
import _majors_src_loader as L                                   # noqa: E402

bad = []


def chk(c, m):
    print(f"  {'✓' if c else '✗'} {m}")
    if not c:
        bad.append(m)


print("=" * 74)
print("  ① 产物是新鲜的")
print("=" * 74)
p = L.ensure_built()
_age = os.path.getmtime(p)
print(f"     产物：{os.path.basename(p)}　"
      f"{(os.path.getsize(p) / 1024):.0f} KB")

# 【输入清单必须写死，不能用「目录里所有 .py/.json」】
# 我第一版就是那么写的，于是 `_agent2_src.py`（**对话版的源**，
# 跟这个产物毫无关系）一被改动，这条就红。
# 那是个**假红**：它把「谁是谁的输入」这件事猜成了「谁比谁新」。
# 真正的输入清单在 `_assemble_majors.py` 里，
# 下面这些就是它读的那几份（改了组装器要同步改这里）。
INPUTS = [
    "_majors_src.py",
    "_mirror_core.py",
    "_theme_core.py",
    "_majors_game.json",
    "_occ_detail.json",
    "_occ_index.json",
    "_official_2026_tree.json",
    "_assemble_majors.py",       # 组装器自己也算输入
]
_newer = [f for f in INPUTS
          if os.path.exists(os.path.join(ROOT, f))
          and os.path.getmtime(os.path.join(ROOT, f)) > _age]
chk(not _newer, f"没有比它更新的输入（{_newer[:4]}）")
# 【反向也要验】清单里的文件必须真的存在，不然这条闸门是空转的
_miss = [f for f in INPUTS if not os.path.exists(os.path.join(ROOT, f))]
chk(not _miss, f"输入清单里的文件都在（缺 {_miss}）")

print()
print("=" * 74)
print("  ② 加载出来的东西是对的")
print("=" * 74)
NS = L.load(need=("MAJORS", "BY_NAME", "resolve_major", "CAT_MAJOR",
                  "CAT_CLASS", "interview_result", "OCC", "OCC_ALIAS"))
print(f"     MAJORS {len(NS['MAJORS'])}　BY_NAME {len(NS['BY_NAME'])}　"
      f"CAT_MAJOR {len(NS['CAT_MAJOR'])}　CAT_CLASS {len(NS['CAT_CLASS'])}")
chk(len(NS["MAJORS"]) == 161, f"161 张牌（实际 {len(NS['MAJORS'])}）")
chk(len(NS["CAT_MAJOR"]) == 883, f"官方目录 883 条（实际 {len(NS['CAT_MAJOR'])}）")
chk(len(NS["CAT_CLASS"]) == 93, f"93 个专业类（实际 {len(NS['CAT_CLASS'])}）")
_has_dims = sum(1 for m in NS["MAJORS"] if m.get("dims"))
chk(_has_dims == 94, f"94 个有需求画像（实际 {_has_dims}）")

print()
print("=" * 74)
print("  ③ 和**产品本体**的数据逐字段一致")
print("=" * 74)
# 【这是这个闸门最要紧的一条】
# 如果加载器拿到的数据和 `志业镜.py` 里跑的不是同一份，
# 那后面所有用它的闸门都在测一个不存在的东西。
_app = open(f"{ROOT}\\志业镜.py", encoding="utf-8").read()
_m = re.search(r'MAJOR_DATA = json\.loads\(r"""(.*?)"""\)', _app, re.S)
chk(_m is not None, "在产品里找到了数据块")
if _m:
    _appdata = json.loads(_m.group(1))
    _an = [x["n"] for x in _appdata["majors"]]
    _bn = [x["n"] for x in NS["MAJORS"]]
    chk(_an == _bn, f"名字顺序逐条一致（{len(_an)} 个）")
    _diff = []
    for _a, _b in zip(_appdata["majors"], NS["MAJORS"]):
        for _k in ("dims", "cost_hours", "cost_templated", "cost_tier",
                   "gate", "专业类", "chsi_jyfx", "hook", "core_s"):
            if _a.get(_k) != _b.get(_k):
                _diff.append((_a["n"], _k))
    print(f"     字段级差异 {len(_diff)} 处"
          f"{'：' + str(_diff[:4]) if _diff else ''}")
    chk(not _diff, "字段级也一致（不是只对上名字）")

print()
print("=" * 74)
print("  ④ 缺东西时**报错**，不静默给空")
print("=" * 74)
try:
    L.load(need=("THIS_NAME_DOES_NOT_EXIST",))
    chk(False, "缺名字时应该报错")
except RuntimeError as e:
    chk("THIS_NAME_DOES_NOT_EXIST" in str(e), "缺名字时报了 RuntimeError")
except Exception as e:                                           # noqa: BLE001
    chk(False, f"报的错类型不对：{type(e).__name__}: {e}")

# 锚点变了也要报错，不能默默切错地方
print()
print("=" * 74)
print("  ⑤ 锚点变了会报错（不许静默切错）")
print("=" * 74)
_orig = open(L.BUILT, encoding="utf-8").read()
try:
    open(L.BUILT, "w", encoding="utf-8").write(
        _orig.replace("st.set_page_config", "st.SOMETHING_ELSE"))
    try:
        L.load()
        chk(False, "锚点没了应该报错")
    except RuntimeError as e:
        chk("st.set_page_config" in str(e), f"锚点没了会报错：{str(e)[:60]}")
finally:
    open(L.BUILT, "w", encoding="utf-8").write(_orig)
    chk(True, "（已还原产物）")

print()
if bad:
    print(f"  ✗ {len(bad)} 项不过：")
    for b in bad:
        print(f"     {b}")
    sys.exit(1)
print("  ✓ 加载器可用：新鲜、数字对、和产品逐字段一致、出错会报")
