# -*- coding: utf-8 -*-
"""`_cards_core.exits_rows` 的取样口——**只给测试用**。

【为什么单独放一个文件】
闸门要在「结构化数据」上验出口，而不是在渲染出来的长文本里抠字
（在长文本里按名字定位一小段，名字重复时就会定位错，
我为此连错两版）。但 `_cards_core.py` 和 `_majors_src.py` 都是
**产品文件**，不该为了测试多长出一个函数。

所以这里做一层薄薄的适配：从加载器给的命名空间里，按产品真实
调用方式把 `exits_rows` 调起来。

【它会不会替产品做决定】
不会。它不判断、不加工，只是把参数凑齐——
凑参数的方式和产品里 `card_data` 的调法**逐字对齐**。
如果哪天 `card_data` 的参数变了，这里会因为 `TypeError` 当场炸，
而不会静默改变测试的含义。
"""

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(
    _os.path.abspath(__file__))))
sys.path.insert(0, ROOT)


def exits_of(m, ns, dim_names, dim_plain):
    """取一张牌的结构化出口列表。

    `ns` 是 `_majors_src_loader.load()` 的返回值。
    """
    return ns["exits_rows"](
        m,
        ns.get("OCC_BY_NAME"),
        ns.get("OCC_ALIAS"),
        ns.get("NOT_JOBS"),
        ns.get("OCC_NODETAIL"),
        ns.get("OCC"),
    )
