# -*- coding: utf-8 -*-
"""选牌页上「查一个不在牌堆里的专业」——走 session_state 驱动。

【上一版为什么假通过】
我用 `AT.text_input[i].set_value(q)` 再 `AT.run()`，四次输出**一模一样**，
都停在第一次的「世界语」上。也就是说 set_value 根本没进去，
而我差一点就把这个当成「四种输入都渲染正确」。

所以这一版不碰控件句柄，直接设 `AT.session_state["_lookup_q"]`，
值在 run 之前就位，读的是**新跑出来的那棵树**。
"""
import io
import sys

from streamlit.testing.v1 import AppTest

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
# ==================================================================
# 【已停用：它驱动的那个界面已经并入产品了】
# ==================================================================
# 这个脚本原来用 `AppTest` 驱动 `专业游乐场.py`（牌局界面）。
# 用户把产品合并成了一个应用（对话为主、翻牌做进对话里），
# 那个界面文件已经不再生成（见 `_assemble_majors.py`）。
#
# 【为什么不把路径改指到 `志业镜.py` 了事】
# 那会让它去驱动**另一个界面**，断言逐条都对不上——
# **一个必然假的绿，比一个红更糟。**
# 它守的那件事（访谈/查询在真页面上走得通）现在由这些闸门守：
#   · `_审计/_check_interview_in_chat.py`（侧栏进得去、七题走完、结果带立场）
#   · `_审计/_check_merged_app.py`（首屏起得来、翻牌画得出、展开是完整的）
#   · `_审计/_check_exit_render.py`（出口那一行印得对）
# 所以它是被**取代**了，不是被绕过。
print("  （这个闸门已停用：它驱动的界面已并入产品，"
      "由 _check_interview_in_chat / _check_merged_app 取代）")
raise SystemExit(0)
# ------------------------------------------------------------------
# 下面保留原文，供查阅；不再执行。
# ------------------------------------------------------------------

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")


def collect(at):
    parts = []
    for kind in ("markdown", "caption", "warning", "success", "info",
                 "error"):
        try:
            for e in getattr(at, kind):
                parts.append(str(e.value))
        except Exception:
            pass
    return "\n".join(parts)


AT = AppTest.from_file(
        os.path.join(ROOT, "_专业游乐场.build-check.py"), default_timeout=90)
AT.run()
print(f"启动异常：{AT.exception if AT.exception else '无 ✓'}")
print()

blob = collect(AT)
print("选牌页上有这些吗：")
for kw in ("想查一个不在牌堆里的专业",
           "官方目录里一共 883 个专业",
           "我做了牌的只有 161 个",
           "不编"):
    print(f"   {'✓' if kw in blob else '✗'} 「{kw}」")

print()
print("页面上的输入控件：")
for w in AT.text_input:
    print(f"   text_input  label={getattr(w, 'label', None)!r}")
for w in AT.selectbox:
    print(f"   selectbox   label={getattr(w, 'label', None)!r}")
print()
print("→ 如果 jump_to_major 的 selectbox 不在这里，说明它没渲染。")
print()

CASES = [
    ("世界语", ("文学", "外国语言文学类", "050241", "还没做成牌")),
    ("中医儿科学", ("医学", "中医学类", "100512", "还没做成牌")),
    ("临床医学", ("我有这张牌",)),
    ("哲学", ("我有这张牌",)),
    ("临床医学类", ("专业类", "7 个专业")),
    ("计算机科学与技术x", ("你是不是想说", "计算机科学与技术")),
    ("完全不存在的东西", ("没有", "不等于它不存在")),
    ("", ()),
]
bad = []
for q, need in CASES:
    AT.session_state["_lookup_q"] = q
    AT.run()
    b = collect(AT)
    exc = AT.exception
    if exc:
        bad.append((q, f"异常 {exc}"))
        print(f"✗ 「{q or '(空)'}」抛异常：{exc}")
        continue
    miss = [t for t in need if t not in b]
    if miss:
        bad.append((q, miss))
    print(f"{'✓' if not miss else '✗'} 「{q or '(空)'}」　{len(b)} 字"
          + (f"　少了 {miss}" if miss else ""))

print()
print("=" * 72)
print("  ✓ 四种分支在选牌页上都工作" if not bad else f"  ✗ {bad}")
