# -*- coding: utf-8 -*-
"""查专业那块界面：四种分支都要渲染出来、且不崩。

【为什么不能只测解析器】
解析器返回对了，界面照样可能崩或者少显示——
比如 `payload` 解包错了、某个分支忘了 return 导致下面接着跑。
所以这一层走的是**界面的真实路径**（`lookup_block`），
每种输入都跑一遍，看它写出来的字对不对。
"""
import io

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(
    _os.path.abspath(__file__))))
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")



class F:
    def __init__(self):
        self.marked, self.captions, self.session_state = [], [], {}
        self.warn = []
        self.ok = []
        self._q = ""
        self.buttons = []

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    @property
    def sidebar(self):
        return self

    def columns(self, x):
        return [self] * (x if isinstance(x, int) else len(x))

    def tabs(self, n):
        return [self] * len(n)

    def expander(self, *a, **k):
        return self

    def spinner(self, *a, **k):
        return self

    def multiselect(self, *a, **k):
        return []

    def selectbox(self, *a, **k):
        return (a[0][0] if a and a[0] else "")

    def radio(self, *a, **k):
        return (a[0][0] if a and a[0] else "")

    def text_area(self, *a, **k):
        return ""

    def text_input(self, *a, **k):
        return self._q

    def button(self, *a, **k):
        if a:
            self.buttons.append(str(a[0]))
        return False

    def __getattr__(self, name):
        def f(*a, **k):
            if name == "markdown":
                self.marked.append(str(a[0]) if a else "")
            if name == "caption":
                self.captions.append(str(a[0]) if a else "")
            if name == "warning":
                self.warn.append(str(a[0]) if a else "")
            if name == "success":
                self.ok.append(str(a[0]) if a else "")
            if name in ("info", "error"):
                self.marked.append(str(a[0]) if a else "")
            return None
        return f


sys.path.insert(0, ROOT)
import _majors_src_loader as _L                                  # noqa: E402
# 【数据从加载器来，不自己 exec 源码】
# 源码里是 `__MAJOR_DATA__` 这类占位符，直接 exec 会 JSONDecodeError。
# 加载器先让组装器拼好，再切断界面。
saved = sys.modules.get("streamlit")
fake = F()
sys.modules["streamlit"] = fake
NS = _L.load()

TESTS = [
    ("世界语", dict(has="文学", must=("外国语言文学类", "050241"),
                    warn=True)),
    ("中医儿科学", dict(has="医学", must=("中医学类", "100512"),
                        warn=True)),
    ("临床医学", dict(has=None, must=("我有这张牌",), ok=True)),
    ("临床医学类", dict(has="专业类", must=("7", "专业"), warn=False)),
    ("计算机科学与技术x", dict(has="你是不是想说",
                              must=("计算机科学与技术",), warn=False)),
    ("完全不存在的东西", dict(has="没有", must=("不等于它不存在",),
                              warn=False)),
    ("", dict(has=None, must=(), warn=False)),
]

bad = []
for q, want in TESTS:
    fake._q = q
    fake.marked.clear()
    fake.captions.clear()
    fake.warn.clear()
    fake.ok.clear()
    fake.buttons.clear()
    try:
        NS["lookup_block"]()
    except Exception as e:
        bad.append((q, f"崩了 {type(e).__name__}: {e}"))
        print(f"✗ 「{q}」崩了：{type(e).__name__}: {e}")
        continue
    blob = ("\n".join(fake.marked) + "\n" + "\n".join(fake.captions)
            + "\n" + "\n".join(fake.warn) + "\n" + "\n".join(fake.ok))
    misses = [t for t in want.get("must", ()) if t not in blob]
    if want.get("warn") and not fake.warn:
        misses.append("缺 warning")
    if not want.get("warn", False) and fake.warn:
        misses.append("不该有 warning")
    if want.get("ok") and not fake.ok:
        misses.append("缺 success")
    if misses:
        bad.append((q, f"少了 {misses}"))
    print(f"{'✓' if not misses else '✗'} 「{q or '(空)'}」"
          f"　{len(blob)} 字"
          f"　warn={len(fake.warn)} ok={len(fake.ok)}"
          + (f"　✗ {misses}" if misses else ""))

print()
# 确认「没有材料就不说」这句在 catalog 分支里
fake._q = "世界语"
fake.marked.clear()
fake.captions.clear()
fake.warn.clear()
NS["lookup_block"]()
_w = "\n".join(fake.warn)
_c = "\n".join(fake.captions) + "\n" + "\n".join(fake.marked)
print("catalog 分支的诚实说明：")
print("   warning：", _w[:96])
for kw in ("学什么", "代价", "出口", "不编", "没有材料"):
    print(f"   {'✓' if kw in _c or kw in _w else '✗'} 说了「{kw}」")

print()
print("=" * 70)
print("  ✓ 四种分支都渲染、不崩" if not bad else f"  ✗ {len(bad)} 处：{bad}")
