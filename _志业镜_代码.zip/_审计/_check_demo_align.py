# -*- coding: utf-8 -*-
"""每一步的讲解词提到的主区块，主区里必须真的在。

【为什么这条最要紧】
讲解词是**给台上的人看的提示**：「主区『什么情况会让你想跑』那段，可以这么说」。
如果主区里根本没有那一段，台上的人就会**对着空气指**——
投影上是别的东西，嘴里在讲这一段。这是课堂展示最尴尬的一类事故，
而且它**不会有任何报错**：讲解词写得好好的，数据也在，只是两边错位。

所以要一条一条对：讲解词里出现的「主区『X』那段」，
X 必须在同一步的主区文字里出现。
这是**交叉核对**，不是自查——两边来自不同代码路径。
"""
import io

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(
    _os.path.abspath(__file__))))
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")



class F:
    def __init__(self):
        self.marked, self.captions, self.session_state = [], [], {}

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    @property
    def sidebar(self):
        return self

    def columns(self, x):
        return [self] * (x if isinstance(x, int) else len(x))

    def tabs(self, n):
        return [self] * len(n)

    def expander(self, *a, **k):
        return self

    def spinner(self, *a, **k):
        return self

    def multiselect(self, *a, **k):
        return []

    def selectbox(self, *a, **k):
        return (a[0][0] if a and a[0] else "")

    def radio(self, *a, **k):
        return (a[0][0] if a and a[0] else "")

    def text_area(self, *a, **k):
        return ""

    def text_input(self, *a, **k):
        return ""

    def __getattr__(self, name):
        def f(*a, **k):
            if name in ("markdown", "info", "warning", "error", "success"):
                self.marked.append(str(a[0]) if a else "")
            if name == "caption":
                self.captions.append(str(a[0]) if a else "")
            if name == "button":
                self.marked.append(str(a[0]) if a else "")
                return False
            return None
        return f


sys.path.insert(0, ROOT)
import _majors_src_loader as _L                                  # noqa: E402
# 【数据从加载器来，不自己 exec 源码】
# 源码里是 `__MAJOR_DATA__` 这类占位符，直接 exec 会 JSONDecodeError。
# 加载器先让组装器拼好，再切断界面。
saved = sys.modules.get("streamlit")
fake = F()
sys.modules["streamlit"] = fake
NS = _L.load()

import re

bad = 0
print("=" * 74)
print("讲解词说「主区『X』那段」，X 在主区里吗")
print("=" * 74)
for i in range(len(NS["WALKTHROUGH"])):
    st = NS["new_state"]()
    st["mode"] = "demo"
    st["step"] = i
    nm = NS["WALKTHROUGH"][i]["major"]

    fake.marked.clear()
    fake.captions.clear()
    NS["demo_step"](st)
    MAIN = "\n".join(fake.marked) + "\n" + "\n".join(fake.captions)

    fake.marked.clear()
    fake.captions.clear()
    NS["demo_presenter_panel"](st)
    SIDE = "\n".join(fake.marked) + "\n" + "\n".join(fake.captions)

    # 讲解词里所有「主区『X』那段」
    refs = re.findall(r"主区「([^」]+)」那段", SIDE)
    print(f"\n第 {i + 1} 步 · {nm}")
    if not refs:
        print("    （讲解词没有指向主区的段落）")
    for ref in refs:
        ok = ref in MAIN
        if not ok:
            bad += 1
        print(f"    {'✓' if ok else '✗ 主区里没有这段！'}　「{ref}」")

    # 讲解词提到 avoid 那条时，主区必须真有「什么情况会让你想跑」
    if "什么情况会让你想跑" in SIDE:
        ok = "什么情况会让你想跑" in MAIN
        if not ok:
            bad += 1
        print(f"    {'✓' if ok else '✗'}　讲解词提了「想跑」，主区也有")
    # 反过来：主区有这块，讲解词一个字都不提，台上会不知道说什么
    if "什么情况会让你想跑" in MAIN and "什么情况会让你想跑" not in SIDE:
        bad += 1
        print("    ✗ 主区有「想跑」那块，讲解词却没提——台上不知道说什么")

print()
print("=" * 74)
print("第 7 步（没有 avoid 数据）不该出现这一块")
print("=" * 74)
st = NS["new_state"]()
st["mode"] = "demo"
st["step"] = 6
fake.marked.clear()
fake.captions.clear()
NS["demo_step"](st)
M7 = "\n".join(fake.marked)
fake.marked.clear()
fake.captions.clear()
NS["demo_presenter_panel"](st)
S7 = "\n".join(fake.marked)
print(f"    主区出现「什么情况会让你想跑」："
      f"{'✗ 出现了' if '什么情况会让你想跑' in M7 else '✓ 没出现'}")
print(f"    讲解词提了它："
      f"{'✗ 提了' if '什么情况会让你想跑' in S7 else '✓ 没提'}")
if "什么情况会让你想跑" in M7 or "什么情况会让你想跑" in S7:
    bad += 1

print()
print("=" * 74)
if bad == 0:
    print("  ✓ 讲解词和主区完全对得上，没有空指")
else:
    print(f"  ✗ {bad} 处错位")
