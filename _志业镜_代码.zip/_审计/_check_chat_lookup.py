# -*- coding: utf-8 -*-
"""对话版的 lookup_unavailable：官方目录里有没有，和「我库里有没有」分开答。

【这个区别为什么重要】
「我库里没有」和「这个专业不存在」是两件事。
用户问「世界语」——我库里没这张牌，但教育部目录里真有。
说成「没有」就是在给他错的信息。

而且它只准答官方目录印着的四个字段。
「学什么」「代价多少」「出口在哪」没材料就不说。
"""
import io
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")

s = open("志业镜.py", encoding="utf-8").read()
c = s.find('if __name__ == "__main__"')
NS = {"__name__": "chat"}
exec(compile(s[:c if c > 0 else len(s)], "志业镜.py", "exec"), NS)

bad = []
ctx = NS["new_ctx"]()
print(f"官方目录索引：{len(NS['CAT_MAJOR'])} 个专业 / "
      f"{len(NS['CAT_CLASS'])} 个专业类")
print()

CASES = [
    ("世界语", "有牌吗", True, "文学"),
    ("中医儿科学", "有牌吗", True, None),
    ("软件工程", "我库里有这张牌", True, None),
    ("临床医学类", "专业类", None, None),
    ("完全不存在的东西", "没有", False, None),
    ("辐射防护与核安全", "有牌吗", True, None),
]
for nm, want, expect_cat, expect_gate in CASES:
    r = NS["run_tool"]("lookup_unavailable", {"name": nm}, ctx)
    has = r.get("in_official_catalog")
    off = r.get("official") or {}
    print(f"  「{nm}」")
    print(f"     我库里有牌 = {r.get('is_major')}　"
          f"官方目录里有 = {has}")
    if off:
        print(f"     官方：{off}")
    if r.get("is_official_class"):
        print(f"     是专业类：{off}")
        print(f"     {r.get('note','')[:90]}")
    print(f"     规矩：{(r.get('rule') or r.get('note') or '')[:96]}")
    if expect_cat is not None and has != expect_cat:
        bad.append((nm, "官方目录判断错了", has, expect_cat))
    if expect_gate and off.get("门类") != expect_gate:
        bad.append((nm, "门类错了", off.get("门类"), expect_gate))
    # 没有材料的项目一个字都不许出现
    blob = str(r)
    for kw in ("学什么", "课程", "薪资", "就业方向"):
        if kw in blob and "没有材料" not in blob:
            bad.append((nm, f"编了「{kw}」"))
    print()

# 有牌的不能说自己没有
ctx2 = NS["new_ctx"]()
r2 = NS["run_tool"]("lookup_unavailable", {"name": "软件工程"}, ctx2)
print(f"  「软件工程」in_official_catalog={r2.get('in_official_catalog')} "
      f"is_major={r2.get('is_major')}")
if not r2.get("is_major"):
    bad.append(("软件工程", "库里明明有牌"))

# 883 个官方专业里，没做成牌的 722 个都必须答得出官方字段
print()
_n_ok = 0
_n_fail = []
_carded = []          # 有牌的那些必须走到「直接给他看牌」那条规矩
for nm in list(NS["CAT_MAJOR"])[:400]:
    # 【by_name 在 ctx 里，不是模块级】
    # 我第一版写了 NS["by_name"]，直接 KeyError——和上一轮
    # 「_Fake 缺属性」是同一类错误：**我以为它在，但我没查。**
    if nm in ctx["by_name"]:
        r = NS["run_tool"]("lookup_unavailable", {"name": nm}, ctx)
        if "有这张牌" not in (r.get("rule") or ""):
            _carded.append(nm)
        continue
    r = NS["run_tool"]("lookup_unavailable", {"name": nm}, ctx)
    if r.get("in_official_catalog") and (r.get("official") or {}).get("专业代码"):
        _n_ok += 1
    else:
        _n_fail.append(nm)
print(f"  抽 400 个官方专业核对：{_n_ok} 个答出了官方字段，"
      f"{len(_n_fail)} 个没答出来")
if _n_fail:
    bad.append(("有官方专业答不出来", _n_fail[:5]))
if _carded:
    bad.append(("有牌的专业没说「有这张牌」", _carded[:5]))
else:
    print(f"  有牌的那些全都说了「我库里有这张牌」✓")

print()
print("  ✓ 对话版查库外专业全部通过" if not bad else f"  ✗ {len(bad)} 处：{bad}")
