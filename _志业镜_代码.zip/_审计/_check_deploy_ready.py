# -*- coding: utf-8 -*-
"""上线前的闸门：云上那三个真问题，是不是真的修好了。

【为什么不能只看代码】
我改了三处（记号文件、密钥来源、费用上限），
但「代码里写了」和「真的会走那条路」是两件事。
尤其**只读文件系统**这个场景：我本机盘是能写的，
所以「写不进去会怎样」这条分支**在我这儿永远走不到**。

做法：把内建 `open` 换掉，**让任何往非临时目录的写都抛 OSError**，
这就是云上仓库目录的行为。然后照常跑一遍应用。
"""
import io
import os
import re
import shutil
import sys
import tempfile

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(
    _os.path.abspath(__file__))))
DEPLOY = os.path.join(ROOT, "_部署_streamlit")
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")

# 【这一条验的是「部署目录做得对不对」，所以它得先有那个目录】
# 它自己被拷进交付包之后，包里没有 `_部署_streamlit/`——
# 因为**部署目录不该套在交付包里**（那是两个不同的产物）。
# 这时候要**说清楚跳过**，不能红：
# 出一条永远红的闸门，等于把真问题埋进噪声里。
if not os.path.isdir(DEPLOY):
    print("=" * 74)
    print("  · 跳过：这一层里没有 `_部署_streamlit/`")
    print("    这条闸门验的是「部署目录做得对不对」。")
    print("    在源码根目录跑它才有意义；在交付包里它是空转的。")
    print("=" * 74)
    raise SystemExit(0)

bad = []


def chk(c, m):
    print(f"  {'✓' if c else '✗'} {m}")
    if not c:
        bad.append(m)


print("=" * 74)
print("  ① 部署目录里就是该有的那几个文件")
print("=" * 74)
_want = {"志业镜.py", "_mirror_core.py", "requirements.txt",
         "部署说明.md", os.path.join(".streamlit", "config.toml")}
_have = set()
for base, _d, files in os.walk(DEPLOY):
    for f in files:
        rel = os.path.relpath(os.path.join(base, f), DEPLOY)
        # `__pycache__` 是**跑测试时生成的**，不是打包时放进去的——
        # 它不该算「多余文件」，否则每跑一次这条闸门就红一次。
        if "__pycache__" in rel:
            continue
        _have.add(rel)
chk(_want <= _have, f"该有的都在（缺 {sorted(_want - _have)}）")
_extra = _have - _want
chk(not _extra, f"没有多余文件（多出来 {sorted(_extra)}）")

print()
print("=" * 74)
print("  ② 部署用的源码里不许有本机路径；不许往仓库目录写")
print("=" * 74)
_src = open(os.path.join(DEPLOY, "志业镜.py"), encoding="utf-8").read()
chk("C:\\Users\\Lenovo" not in _src, "产物里没有写死本机路径")
chk("_writable_dir" in _src, "有「找一个真能写的目录」那段")
# 【老写法必须真的不在了——但只能查真实字符串，不能查注释】
# 我第一次写成 `'os.path.join(os.getcwd(), "_开场记号.txt")' not in _src`，
# 于是**红了**：注释里为了说明这个坑，原样引用了那句老代码。
# 注释是历史，不是代码。**这个错我这轮已经犯过三次了**——
# 所以这次用 AST，只取真正的字符串字面量。
import ast                                                        # noqa: E402
_lits = [n.value for n in ast.walk(ast.parse(_src))
         if isinstance(n, ast.Constant) and isinstance(n.value, str)]
_joined = "\n".join(_lits)
chk("_开场记号.txt" in _joined, "记号文件名这个字符串还在（不是把功能删了）")
chk("os.getcwd()" not in _joined,
    "真实字符串里不再有 os.getcwd()（老写法的特征）")
chk(any("_开场记号.txt" in x for x in _lits), "记号文件名仍是个字符串")

print()
print("=" * 74)
print("  ③ 密钥：三种来源按云上可行性排序")
print("=" * 74)
chk("st.secrets" in _src, "会先读 st.secrets（云上唯一可行的方式）")
chk("DEEPSEEK_API_KEY" in _src, "读的是 DEEPSEEK_API_KEY")
# 【访问 secrets 必须包 try】没有 secrets 文件时它是抛异常，不是返回空
_m = re.search(r"try:\s*\n\s*key = st\.secrets", _src)
chk(_m is not None, "访问 st.secrets 包在 try 里（没 secrets 文件时会抛）")
chk("os.environ.get(\"DEEPSEEK_API_KEY\"" in _src,
    "环境变量还在（本机/自建服务器走这条）")

print()
print("=" * 74)
print("  ④ 只读文件系统下，应用照常跑得起来")
print("=" * 74)
# 【怎么模拟】把内建 open 换掉：往「非临时目录」写就抛 OSError。
_TMP = os.path.abspath(tempfile.gettempdir())
_real_open = open
_blocked = []


def _ro_open(file, mode="r", *a, **kw):
    if any(c in str(mode) for c in "wax+"):
        p = os.path.abspath(str(file))
        if not p.startswith(_TMP):
            _blocked.append(p)
            raise OSError(30, "Read-only file system", str(file))
    return _real_open(file, mode, *a, **kw)


import builtins                                                  # noqa: E402
builtins.open = _ro_open
try:
    from streamlit.testing.v1 import AppTest                      # noqa: E402
    AT = AppTest.from_file(os.path.join(DEPLOY, "志业镜.py"),
                           default_timeout=300)
    AT.run()
    _exc = list(AT.exception) if AT.exception is not None else []
    chk(not _exc, f"只读文件系统下首屏无异常（{len(_exc)} 条）")
    if _exc:
        print(f"       {str(getattr(_exc[0], 'value', _exc[0]))[:300]}")
    print(f"      （这一轮被挡下的写操作：{len(_blocked)} 次"
          f"{'，例如 ' + os.path.basename(_blocked[0]) if _blocked else ''}）")
finally:
    builtins.open = _real_open

print()
print("=" * 74)
print("  ⑤ 费用上限：公开部署时防账单失控")
print("=" * 74)
chk("ZHIYEJING_MAX_TURNS" in _src, "上限可按环境变量调（演示时放宽、公开时收紧）")
chk("disabled=_used_up" in _src, "用满就禁用输入框")
chk("重开一页就能接着聊" in _src, "用满时说清为什么、并给一条出路")

print()
if bad:
    print(f"  ✗ {len(bad)} 项不过：")
    for b in bad:
        print(f"      {b}")
    raise SystemExit(1)
print("  ✓ 这个部署目录可以在只读文件系统上跑起来")

# 【自己造的字节码自己收】
# 这条闸门要 import 部署副本里的 `_mirror_core.py`，于是会在那儿留下
# `__pycache__`。上面第 ① 项故意忽略它（不然每跑一次就红一次，那是假的红）。
# 但**这个目录就是用户要整个传上去的那 5 个文件**——
# 多一个 `__pycache__` 就会被一起传上去，而且在本地看不出来。
# 「不算多余」和「不该留着」是两件事：前者管判定，后者管收拾。
_pyc = os.path.join(DEPLOY, "__pycache__")
if os.path.isdir(_pyc):
    shutil.rmtree(_pyc, ignore_errors=True)
