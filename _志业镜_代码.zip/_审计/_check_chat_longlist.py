# -*- coding: utf-8 -*-
"""对话版：名单长的时候，模型拿到的信号对不对。

【这个脚本我写了三版才对，三处错全在我这边】
① 参数名凭印象编：写成 `{"answer": {七个分}}`。
   真实参数是 `dimension` + `score` + `quote`，
   而 `answer` 是**用户的原话文本**，不是分。→ 一次都没认到分。
② 不给 `answer`：给了 `score` 就必须给 `quote`，
   而 `quote` 必须真的出现在 `answer` 里。→ 七项全变「不知道」。
③ **给每一维都传 4。** 而 `记忆量` 的合法分是 `[1,3,5,None]`、
   `自驱要求` 是 `[1,2,5]`——**这两维根本没有 4。**
   工具把非法分拒掉、记成「不知道」，**这是产品正确，
   是我的测试在喂假数据。** 我看到 `对得上 0 / 证据不足 91`
   那一瞬间差点以为算法坏了。

所以现在分数**从该维的真实选项里取**，不再由我拍。
"""
import io
import itertools
import math
import json

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(
    _os.path.abspath(__file__))))
sys.path.insert(0, ROOT)
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")

import _tools_core as T                                       # noqa: E402

# 【把共享核心的名字注进工具层】
# `_tools_core.py` 单独跑时没有 `interview_result`——
# 它在 `_mirror_core.py` 里，由 `_assemble_agent2.py` **内联**进最终文件。
# 所以直接 import 会 NameError：**这个工具层单独跑不起来，它依赖组装。**
import _mirror_core as MC                                     # noqa: E402
for _n in ("interview_result", "ASK", "OPTIONS", "DIM_NAMES", "DIM_SHORT",
           "Q_OF"):
    if hasattr(MC, _n):
        setattr(T, _n, getattr(MC, _n))

G = json.load(open(f"{ROOT}\\_majors_game.json", encoding="utf-8"))
MAJORS = G["majors"]
DIM_KEYS = T.DIM_KEYS
bad = []


def chk(c, m):
    print(f"  {'✓' if c else '✗'} {m}")
    if not c:
        bad.append(m)


def legal(dim):
    return [s for s, _l, _r in MC.OPTIONS[dim] if s is not None]


def pick(dim, want):
    """在该维的合法分里挑一个最接近 want 的。"""
    ls = legal(dim)
    return min(ls, key=lambda v: abs(v - want)) if ls else None


def ctx():
    return {"majors": MAJORS, "by_name": {m["n"]: m for m in MAJORS},
            "occ_by_id": {}, "major_occ": {}, "mirror": {}, "notes": [],
            "trace": []}


def call(wants):
    """按每一维的真实选项取合法分，逐维调用（工具的真实用法）。"""
    c = ctx()
    last = None
    for d, w in zip(DIM_KEYS, wants):
        v = pick(d, w)
        said = f"我说的是{d}这一维，就是这个数"
        last = T.run_tool("interview",
                          {"dimension": d, "score": v,
                           "quote": said, "answer": said}, c)
    return last, c


print("=" * 74)
print("  ① 非法分必须被拒（这是早就定下的对抗样本）")
print("=" * 74)
print(f"  记忆量的合法分：{[s for s, _l, _r in MC.OPTIONS['记忆量']]}")
c = ctx()
said = "我背东西很快，反复几遍就记住了"
T.run_tool("interview", {"dimension": "记忆量", "score": 4,
                         "quote": said, "answer": said}, c)
chk(c.get("iv", {}).get("记忆量") is None,
    "记忆量填 4（这一维没有 4）→ 记成「不知道」，不是 4")
chk("合法分" in str(c.get("iv_why")),
    "而且说清了原因是「不是这一维的合法分」")
print(f"     iv_why = {c.get('iv_why')}")
print(f"  自驱要求的合法分：{[s for s, _l, _r in MC.OPTIONS['自驱要求']]}")
c2 = ctx()
T.run_tool("interview", {"dimension": "自驱要求", "score": 4,
                         "quote": said, "answer": said}, c2)
chk(c2.get("iv", {}).get("自驱要求") is None,
    "自驱要求填 4（这一维没有 4）→ 记成「不知道」")

print()
print("=" * 74)
print("  ② 七维取各自的合法分、都答满 → 拿到的信号")
print("=" * 74)
o, _c = call([9] * 7)                 # 每维取它合法分里最大的
n_ag = o["counts"]["对得上"]
print(f"  每维取最高合法分：counts = {o['counts']}")
chk(n_ag == 94, f"对上 {n_ag} 个（全取最高 → 谁都放得下）")
chk(o.get("long_list") is True, "long_list 为 True")
chk(any("太多了，等于没说" in s for s in o["must_say"]),
    "must_say 第一条点明「太多了，等于没说」")
chk(any("确实宽" in s for s in o["must_say"]),
    "说清成因是「他答的这几项确实宽」")
chk(any("不许挑几个名字出来夸匹配度" in s for s in o["must_say"]),
    "明令禁止挑名字夸匹配")
chk("别念名单" in o.get("note", ""), "note 里说「别念名单」")
chk("先试哪一张牌" in o.get("note", ""),
    "note 里给了下一步（问他愿意先试哪一张）")
chk(any("适合他" in s for s in o["must_say"]),
    "原来那四条底线还在（「这不是适合他」等）")
print(f"  must_say 共 {len(o['must_say'])} 条，第一条：")
print(f"     {o['must_say'][0][:100]}")

print()
print("=" * 74)
print("  ③ 短名单不套长名单那套话")
print("=" * 74)
o2, _c2 = call([3, 2, 5, 4, 5, 3, 3])
print(f"  counts = {o2['counts']}")
chk(o2["counts"]["对得上"] < 20,
    f"对得上 {o2['counts']['对得上']} 个（短名单）")
chk(o2.get("long_list") is False, "long_list 为 False")
chk(not any("太多了" in s for s in o2["must_say"]),
    "**短名单没有**那套长名单的话")
chk("别念名单" not in o2.get("note", ""), "短名单没有「别念名单」")
chk(len(o2["must_say"]) == 4,
    f"短名单仍是原来那 4 条（{len(o2['must_say'])}）")

print()
print("=" * 74)
print("  ④ 边界：long_list 与「≥20」严格一致")
print("=" * 74)
# 【「正好 20 个」这个案例在合法答案里不存在——这是查出来的，不是我放过它】
# 我原来断言「(20, True) 必须在表里」。它一直红。
# 查下去才发现：合法选项组合算出来的个数**根本不经过 20**。
# 原因有两个，都很实在：
#   ① 选项里的分是**稀疏的**（认知负荷只有 2/4/5，自驱要求只有 1/2/5），
#      用户不可能给出 `[3,4,4,5,4,4,3]` 里的 3 和 4。
#      `[3,4,4,5,4,4,3]` 算出 20，但那是**真实画像的值域**，
#      工具会正确拒掉其中 5 个非法分 → 只剩 2 项有效 → 落成 0。
#   ② 由此可见，真实画像能取到的值域**比应用能收集到的答案更宽**。
#      这是个值得记下来的事实：**画像比采集细。**
# 所以边界只能这样测：**穷举全部合法答案组合**，
# 逐个数分类是否符合「≥20」这条规则。
LEGAL = [[s for s, _l, _r in MC.OPTIONS[d] if s is not None]
         for d in DIM_KEYS]
print(f"  合法答案空间：{' × '.join(str(len(x)) for x in LEGAL)}"
      f" = {1 if not LEGAL else math.prod(len(x) for x in LEGAL)} 种组合")
_all = list(itertools.product(*LEGAL))
seen_n = {}
_mismatch = []
for combo in _all:
    cc = ctx()
    oo = None
    for d, v in zip(DIM_KEYS, combo):
        said = f"我说的是{d}这一维，就是这个数"
        oo = T.run_tool("interview", {"dimension": d, "score": v,
                                      "quote": said, "answer": said}, cc)
    n = oo["counts"]["对得上"]
    seen_n[n] = seen_n.get(n, 0) + 1
    if oo.get("long_list") != (n >= 20):
        _mismatch.append((combo, n, oo.get("long_list")))
print(f"  穷举了 {len(_all)} 种合法组合")
chk(not _mismatch,
    f"穷举全部合法组合，long_list 与「≥20」**零处不一致**"
    f"（不一致 {len(_mismatch)} 处）")
_ns = sorted(seen_n)
print(f"  合法组合能算出的个数：{_ns}")
_under = [n for n in _ns if n < 20]
_over = [n for n in _ns if n >= 20]
chk(bool(_under) and bool(_over), "阈值两侧都有合法组合")
print(f"     短名单侧最大 {max(_under)}，长名单侧最小 {min(_over)}")
chk(20 not in seen_n,
    f"**20 不在合法组合能算出的个数里**（最近的："
    f"{max(_under)} 与 {min(_over)}）——所以「正好 20」测不到，"
    f"这是选项稀疏造成的，不是闸门漏了")
chk(max(_under) >= 11,
    f"短名单侧够到 {max(_under)}（离阈值 20 还有距离，"
    f"但已是合法答案里最高的）")

print()
print("=" * 74)
print("  ⑤ 两边数出来的「对得上」必须是同一个数")
print("=" * 74)
# 【这是核心一致性】牌局和对话版用的是同一个 interview_result，
# 但对话版这一路多了一层工具封装。**封装不许改变数字。**
_same = 0
_cases = ([9] * 7, [1] * 7, [3] * 7, [4, 4, 4, 5, 4, 4, 4],
          [3, 2, 5, 4, 4, 4, 4], [3, 3, 4, 5, 4, 4, 3])
for wants in _cases:
    got, _cc = call(list(wants))
    direct = [pick(d, w) for d, w in zip(DIM_KEYS, wants)]
    r = MC.interview_result(direct, MAJORS)
    if got["counts"]["对得上"] == len(r["agree"]):
        _same += 1
    else:
        print(f"     ✗ {direct}：工具 {got['counts']['对得上']} vs "
              f"核心 {len(r['agree'])}")
chk(_same == len(_cases),
    f"{_same}/{len(_cases)} 组两边数字一致")

print()
if bad:
    print(f"  ✗ {len(bad)} 项不过：")
    for b in bad:
        print(f"     {b}")
    sys.exit(1)
print("  ✓ 对话版拿到的信号：名单长时被告知「太多了」，且被禁止念名单")
