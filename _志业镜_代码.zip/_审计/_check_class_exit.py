# -*- coding: utf-8 -*-
"""类内同源出口这一层的闸门。

【这层最容易出的事】
不是我加的那 12 个类答错了，而是**门槛失效**：
只要有一个「各走各的」的类被放进来，用户就会看到
「市场营销」的出口是「会计/会计师」——**看着有出处，其实张冠李戴。**
而这正是我前几轮反复说「没有材料就不说」要挡的那件事。

所以这个闸门一半在查「对的类说对了」，一半在查
**「错的类一个字都不许说」**。
"""
import ast
import io
import json

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(
    _os.path.abspath(__file__))))
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")

bad = []


def chk(c, m):
    print(f"  {'✓' if c else '✗'} {m}")
    if not c:
        bad.append(m)


class SS(dict):
    """既能 `st.session_state.ctx` 又能 `st.session_state["ctx"]`。

    【为什么需要它】
    应用里写的是 `st.session_state.ctx = new_ctx()`——**属性**访问。
    我第一版给的是普通 dict，于是 exec 到那一行就报
    `'dict' object has no attribute 'ctx'`。
    那**不是应用的问题，是我的替身太窄**——
    而且我差点把这条红当成「装配后的应用跑不起来」。
    """
    def __getattr__(self, k):
        try:
            return self[k]
        except KeyError:
            raise AttributeError(k) from None

    def __setattr__(self, k, v):
        self[k] = v


class _Any:
    """什么都能当的替身：能调用、能当上下文管理器、能取属性、能迭代。

    【为什么要这么宽】
    这是第三次同类错误了：假对象每窄一点，就有一条**看起来像应用崩了**
    的红。先是 dict 不支持 `st.session_state.ctx`，
    然后是函数不支持 `with st.spinner(...)`。
    报错信息指向那个 `with` 或那个点号，真凶却是我的替身。
    """
    def __call__(self, *a, **k):
        return _Any()

    def __enter__(self):
        return _Any()

    def __exit__(self, *a):
        return False

    def __getattr__(self, k):
        return _Any()

    def __iter__(self):
        return iter(())

    def __len__(self):
        return 0

    def __bool__(self):
        return False


class Fake:
    def __init__(self):
        self.marked, self.captions = [], []
        self.session_state = SS()
        self.err, self.warn, self.ok = [], [], []
        self._progress = []
        # `st.sidebar` 是**模块属性**，不走 __getattr__——
        # 而应用里写 `with st.sidebar:`，于是又一条同类的红。
        self.sidebar = _Any()

    def progress(self, *a, **k):
        self._progress.append(a[0] if a else None)
        return self

    def columns(self, spec, *a, **k):
        # 应用里写 `a, b, c = st.columns(3)`，要按个数还回去
        n = spec if isinstance(spec, int) else len(spec)
        return [_Any() for _ in range(n)]

    def tabs(self, spec, *a, **k):
        n = spec if isinstance(spec, int) else len(spec)
        return [_Any() for _ in range(n)]

    def __getattr__(self, name):
        def f(*a, **k):
            if a:
                self.marked.append(str(a[0]))
            return _Any()
        return f


src = open(f"{ROOT}\\志业镜.py", encoding="utf-8").read()
ast.parse(src)
_saved = sys.modules.get("streamlit")
sys.modules["streamlit"] = Fake()
ns = {"__name__": "cls_exit_check"}
try:
    exec(compile(src, "志业镜.py", "exec"), ns)
    _exc = None
except Exception as e:                                       # noqa: BLE001
    _exc = e
finally:
    if _saved is not None:
        sys.modules["streamlit"] = _saved

chk(_exc is None, f"装配后的应用能跑起来（{_exc}）")

CAT = ns["CAT_MAJOR"]
CLS = ns["CAT_CLASS"]
CE = ns["CLS_EXIT"]
MAJORS = ns["MAJORS"]
BY = ns["by_name"] if "by_name" in ns else {m["n"]: m for m in MAJORS}
carded = {m["n"] for m in MAJORS}
D = json.load(open(f"{ROOT}\\_chsi_detail.json", encoding="utf-8"))
tree = json.load(open(f"{ROOT}\\_official_2026_tree.json", encoding="utf-8"))

maj2cls = {}
for g, gv in tree.items():
    for cls, cv in (gv.get("classes") or {}).items():
        for mj in cv["majors"]:
            maj2cls[mj["name"]] = cls

print()
print("=" * 74)
print("① 放出来的类，和我按数据算出来的是同一批")
print("=" * 74)
# 独立重算一遍——不引用装配器的结果，两边对不上就说明有一边错了
want = {}
for g, gv in tree.items():
    for cls, cv in (gv.get("classes") or {}).items():
        sig = {}
        for mj in cv["majors"]:
            jf = (D.get(mj["name"]) or {}).get("jyfx") or []
            if jf:
                sig.setdefault(tuple(jf), []).append(mj["name"])
        n = sum(len(v) for v in sig.values())
        if n < 3 or not sig:
            continue
        top, names = max(sig.items(), key=lambda kv: len(kv[1]))
        if len(names) / n >= 0.75:
            want[cls] = {"方向": list(top)[:6], "同类专业数": len(names),
                         "该类有数据的专业数": n}
chk(set(CE) == set(want), f"类名单一致（应用 {len(CE)} 个，重算 {len(want)} 个）")
_diff = [k for k in want if CE.get(k) != want[k]]
chk(not _diff, f"每个类的方向/数字都一致（不一致 {len(_diff)} 个：{_diff[:3]}）")
chk(len(CE) == 12, f"放出 {len(CE)} 个类（应为 12）")

# 门槛必须真的在起作用：有没有「不该进」的类混进来？
_slips = []
for cls, cv in ((c, cc) for g, gg in tree.items()
                for c, cc in gg["classes"].items()):
    sig = {}
    for mj in cv["majors"]:
        jf = (D.get(mj["name"]) or {}).get("jyfx") or []
        if jf:
            sig.setdefault(tuple(jf), []).append(mj["name"])
    n = sum(len(v) for v in sig.values())
    if not sig:
        continue
    share = max(len(v) for v in sig.values()) / n
    if cls in CE and (share < 0.75 or n < 3):
        _slips.append((cls, n, round(share, 2)))
chk(not _slips, f"没有低于门槛的类混进来（{_slips}）")
print(f"     门槛边界上的例子：")
for cls in ("工商管理类", "历史学类", "生物科学类", "哲学类"):
    cv = next(cc for g, gg in tree.items()
              for c, cc in gg["classes"].items() if c == cls)
    sig = {}
    for mj in cv["majors"]:
        jf = (D.get(mj["name"]) or {}).get("jyfx") or []
        if jf:
            sig.setdefault(tuple(jf), []).append(mj["name"])
    n = sum(len(v) for v in sig.values())
    share = max(len(v) for v in sig.values()) / n if n else 0
    print(f"       {cls:<12} {n} 个专业　最大一撮 {share * 100:.0f}%　"
          f"{'放行' if cls in CE else '**挡下**'}")

print()
print("=" * 74)
print("② 没牌、但在放行的类里 → 说得出「这是这一类的」")
print("=" * 74)


def call(name, ctx):
    return ns["run_tool"]("lookup_unavailable", {"name": name}, ctx)


ctx = {"by_name": BY, "majors": MAJORS, "occ_by_name": {},
       "cat_major": CAT, "cat_class": CLS, "cls_exit": CE}
_targets = [n for n in CAT if n not in carded
            and maj2cls.get(n) in CE]
chk(bool(_targets), f"有 {len(_targets)} 个没牌的专业落在放行的类里")
_can = 0
_badlab = []
for n in _targets:
    r = call(n, ctx)
    if r.get("class_exit"):
        _can += 1
        rule = r.get("rule") or ""
        cls = maj2cls[n]
        # 必须说清是「这一类的」，不能让人以为是这个专业单独的
        if ("这一类的" not in rule or n not in rule
                or "不是" not in rule):
            _badlab.append(n)
    else:
        _badlab.append(f"{n}(没有 class_exit)")
chk(_can == len(_targets),
    f"每一个都给了 class_exit（{_can}/{len(_targets)}）")
chk(not _badlab,
    f"每一个都写明是「这一类的、不是它单独的」（{len(_badlab)} 个没写："
    f"{_badlab[:3]}）")
# 【等级必须写在数据里，不能只靠提示词提醒模型打折】
# 这几条不是这个专业自己的官方就业方向，是**同类的别的专业**的。
# 靠一句提示词去让模型「记得打折」是不可靠的——
# 模型就算不提醒，返回值里也得带着「类级代理」这个等级。
_nosrc = []
for n in _targets:
    r = call(n, ctx)
    s = r.get("class_exit_src") or {}
    if "类级代理" not in str(s.get("等级") or ""):
        _nosrc.append(n)
    elif "不是这个专业自己的" not in str(s.get("等级") or ""):
        _nosrc.append(f"{n}(等级没写明不是它的)")
chk(not _nosrc,
    f"每一条 class_exit 都带着「类级代理」等级（缺 {len(_nosrc)}："
    f"{_nosrc[:3]}）")
_r0 = call(_targets[0], ctx)
print(f"     class_exit_src = {_r0.get('class_exit_src')}")
_ex = call(_targets[0], ctx)
print(f"     例：「{_targets[0]}」（{maj2cls[_targets[0]]}）")
print(f"       class_exit = {_ex.get('class_exit')}")
print(f"       official   = {_ex.get('official')}")

print()
print("=" * 74)
print("③ 没牌、但在**挡下**的类里 → 一个字都不许按类说")
print("=" * 74)
_blocked = [n for n in CAT if n not in carded
            and maj2cls.get(n) not in CE]
_leak = []
for n in _blocked:
    r = call(n, ctx)
    if r.get("class_exit"):
        _leak.append(n)
chk(not _leak,
    f"{len(_blocked)} 个挡下的专业，一个都没有 class_exit"
    f"（泄漏 {len(_leak)} 个：{_leak[:4]}）")
# 而且要说清「没材料就不说」，并给出**同类里有牌的那几张**
_bt = next((n for n in _blocked if maj2cls.get(n)), None)
if _bt:
    r = call(_bt, ctx)
    rule = r.get("rule") or ""
    print(f"     例：「{_bt}」（{maj2cls[_bt]}）")
    print(f"       {rule[:150]}")
    chk("没有材料就不说" in rule, "仍然明说「没有材料就不说」")
    chk("不能套到它头上" in rule or "别的专业" in rule,
        "而且提醒同类里那几张牌是别的专业")

print()
print("=" * 74)
print("④ 有牌的专业，规矩不变（不许被类内出口带偏）")
print("=" * 74)
_c = next(iter(carded))
r = call(_c, ctx)
chk("我库里有这张牌" in (r.get("rule") or ""),
    f"「{_c}」仍然直接指向牌，没被类内出口带偏")
chk("class_exit" not in r, "有牌的不会被塞一个 class_exit")

print()
print("=" * 74)
print("⑤ 覆盖：这一层到底帮到多少个没牌的专业")
print("=" * 74)
print(f"  没牌的专业 {len(_blocked) + len(_targets)} 个")
print(f"  能拿到「这一类典型出口」的：{_can} 个")
print(f"  其余 {len(_blocked)} 个照旧说「没有材料」")
_cls_used = sorted({maj2cls[n] for n in _targets})
print(f"  用到的专业类 {len(_cls_used)} 个：{_cls_used}")

print()
if bad:
    print(f"  ✗ {len(bad)} 项不过：")
    for b in bad:
        print(f"     {b}")
    sys.exit(1)
print("  ✓ 类内同源出口这一层：门槛在起作用，说法分得清")
