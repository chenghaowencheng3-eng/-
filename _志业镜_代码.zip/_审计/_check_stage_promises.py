# -*- coding: utf-8 -*-
"""稿子在台上承诺的 6 个动作，逐个核。

【为什么这件事优先于补数据】
稿子上第 16 页写着「试着让它说一个错的数字，看会不会被拦下」，
讲的人会**当着全班**做。要是拦不住，或者拦错了，
那比某个专业缺画像严重得多——**那是当场翻车。**
我上一轮把这两个标成「待验证」就过去了，这一轮先补上。
"""
import io
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")

s = open("志业镜.py", encoding="utf-8").read()
c = s.find('if __name__ == "__main__"')
NS = {"__name__": "chat"}
exec(compile(s[:c if c > 0 else len(s)], "志业镜.py", "exec"), NS)

guard = NS["guard"]
bad = []

# 【① 这一节必须喂真实的 calls】
# 第一版我拿 `guard(text, [])` 去测「陈述牌面数据该放行」，
# 结果「自驱要求是 4 分」「45 小时」全被拦——**这不是守卫错了，
# 是我没给它任何工具返回**：一个没查过任何东西的模型说数字，
# 本来就该被拦。
# 这也说明这条守卫是 fail-closed 的：**没材料就不许说数字**，正是我要的。
_call_cs = [("requirements", {"name": "计算机科学与技术"},
             str({"found": True,
                  "dims": {"认知负荷": 5, "记忆量": 2, "细节分辨": 1,
                           "动手要求": 3, "自驱要求": 4, "挫折耐受": 4,
                           "慢反馈耐受": 3},
                  "cost": {"周均小时": 45, "几年能独立": 3,
                           "几个月有反馈": 1}})[:160])]
_call_sw = [("show_major", {"name": "软件工程"},
             str({"found": True, "n": "软件工程",
                  "core_s": "数据结构、操作系统、数据库"})[:160])]

print("=" * 74)
print("① 「试着让它说一个错的数字，看会不会被拦下」")
print("=" * 74)
# 这句在稿子上是「让它说错数字」。真跑起来模型不会自己说错数——
# **真正要防的是它凭空补数**。所以这里测的是 guard 的判断：
# 哪些句子该被拦、哪些不该被误拦。
CASES = [
    # (句子, 该不该拦, 说明, 给它的工具返回)
    ("建议你选软件工程。", True, "直接推荐专业", _call_cs),
    ("你应该选临床医学。", True, "直接推荐专业", _call_cs),
    ("这个最适合你。", True, "说「最适合」", _call_cs),
    ("以你的条件，别学艺术了。", True, "拿现实条件判人", _call_cs),
    ("你能力不足，扛不住这个。", True, "低证据说成低能力", _call_cs),
    ("你缺乏自驱力。", True, "低证据说成低能力", _call_cs),
    ("计算机的七维里自驱要求是 4 分。", False,
     "「七维」是维度名的说法，里面的七不算数字；4 在返回里", _call_cs),
    ("计算机的 7 维里自驱要求是 4 分。", False,
     "同上，写阿拉伯数字的「7 维」也要挡住", _call_cs),
    ("它这七格里自驱是 4。", False, "「七格」同样要遮", _call_cs),
    ("这个专业每周 45 小时，你受得了吗？", False,
     "45 在返回里，该放行", _call_cs),
    ("它主要学数据结构、操作系统、数据库。", False,
     "课程名来自工具返回，没有数字，该放行", _call_sw),
    ("这俩差别在：计算机偏工具，数学偏证明。", False, "对照，该放行",
     _call_cs),
    ("我库里没有那个专业的数据。", False, "如实说没有，该放行", []),
    ("你可以先花一个下午试试写个小脚本。", False,
     "给一个小实验（「一个下午」是量词，但「一」太小不算证据）",
     []),
]
for text, should_block, why, _c in CASES:
    out, why2 = guard(text, _c)
    blocked = bool(why2)
    ok = blocked == should_block
    print(f"   {'✓' if ok else '✗'} {'拦下' if blocked else '放行'}　"
          f"{text[:34]}")
    print(f"        期望{'拦下' if should_block else '放行'}（{why}）"
          + (f"　理由={why2}" if blocked else ""))
    if not ok:
        bad.append((text, "该" + ("拦" if should_block else "放"),
                    "实际" + ("拦了" if blocked else "放了")))

print()
print("=" * 74)
print("② 「不提专业，先随便说说」——聊闲天时它会不会硬塞专业")
print("=" * 74)
# 【这一节要如实区分「拦得住」和「拦不住」】
# 加了事实守卫之后，带数字的事实断言拦得住了；
# **但编课程名、编「能进三甲医院」这种不带数字的断言，仍然拦不住。**
# 那是这套机制的边界，不是 bug——机械核对只能核数字。
# 把边界写出来，比假装它全能有用。
NOCALL = [
    ("临床医学要读五年，出来能进三甲医院。", True,
     "「五年」不在任何返回里 → 数字关拦住"),
    ("就业率 98%。", True, "数字关拦住"),
    ("软件工程主要学 Java、数据结构，毕业做程序员。", False,
     "**拦不住**：没数字，编的课程名机械核不出来"),
    ("哦，那你平时喜欢干什么？随便聊聊。", False, "纯闲聊，该放行"),
    ("打游戏也算，很多人是从游戏里发现自己愿意钻研的。", False,
     "闲聊 + 一句鼓励，该放行"),
]
_lim = []
for text, should_block, why in NOCALL:
    out, why2 = guard(text, [])
    blocked = bool(why2)
    ok = blocked == should_block
    print(f"   {'✓' if ok else '✗'} {'拦下' if blocked else '放行'}　"
          f"{text[:38]}")
    print(f"        {why}" + (f"　理由={why2}" if blocked else ""))
    if not ok:
        bad.append((text, "该" + ("拦" if should_block else "放"),
                    "实际" + ("拦了" if blocked else "放了")))
    if not blocked and should_block:
        _lim.append(why)

print()
print("   一次工具都没调时，不带量词的也算闲聊，不该拦：")
for text in ("咱先聊两三件事。", "这事儿我也说不好。"):
    out, why2 = guard(text, [])
    print(f"     {'拦下' if why2 else '放行'}　{text}")

print()
print("   【这套机制拦不住什么——必须说清】")
print("     · 编课程名、编「能进三甲医院」这种**不带数字**的断言")
print("     · 数字里的小数（「三件事」这种）本来就当闲聊")
print("   它是「机械核对数字」，不是「判断真假」。")
print("   所以稿子上那一页演示的是**数字被拦下**，这一点是真的；")
print("   但别在台上说「它不会编」——它拦住的是数字，别的靠提示词。")

# 事实守卫：句子里有数字但工具没返回过 → 该拦
print()
print("=" * 74)
print("③ 事实守卫：数字必须来自工具返回")
print("=" * 74)
# 【上一版这里传错了形状】
# 真实的 calls 是 `(工具名, 参数, str(返回值)[:160])` 三元组
# （见 stream_llm 里 `calls.append((tc.function.name, args, str(out)...))`）。
# 我第一版传的是 `{"name":..., "result":{...}}`——**守卫压根读不到返回值**，
# 于是三个「编的数字」全被放行，而我差点把它报成代码缺陷。
# 又是「先怀疑代码、后怀疑自己」。
_calls = [("requirements", {"name": "计算机科学与技术"},
           str({"found": True, "major": "计算机科学与技术",
                "dims": {"认知负荷": 5, "记忆量": 2, "细节分辨": 1,
                         "动手要求": 3, "自驱要求": 5,
                         "挫折耐受": 4, "慢反馈耐受": 3},
                "cost": {"周均小时": 45, "几年能独立": 3,
                         "几个月有反馈": 1}})[:160])]
T = [
    ("计算机的认知负荷是 5 分，自驱也是 5 分。", False,
     "数字都在工具返回里"),
    ("这个专业每周要 45 小时。", False, "45 在返回里"),
    ("这个专业每周要 60 小时。", True, "60 不在返回里——编的"),
    ("就业率 98%。", True, "就业率不在任何返回里"),
    ("学费一年 5000 元。", True, "学费不在任何返回里"),
    # 反向：闲聊里的小数字不该被误拦
    ("咱先聊两三件事，不着急。", False, "纯闲聊，没有量词，不该拦"),
    ("打游戏也算，你上面说了一件事。", False, "闲聊，不该拦"),
]
for text, should_block, why in T:
    out, why2 = guard(text, _calls)
    blocked = bool(why2)
    ok = blocked == should_block
    print(f"   {'✓' if ok else '✗'} {'拦下' if blocked else '放行'}　"
          f"{text[:36]}")
    print(f"        {why}" + (f"　理由={why2}" if blocked else ""))
    if not ok:
        bad.append((text, "该" + ("拦" if should_block else "放"),
                    "实际" + ("拦了" if blocked else "放了")))

# ── 跨轮：上一轮查过的数，这一轮复述不该被拦 ──
# 【为什么专门测这个】
# 用户问完计算机、聊两句再回头问「刚才自驱几分」是**很自然的用法**。
# 而这一轮 calls 是空的，守卫只看这一轮就会把 5 判成编的，
# 把整句话吞掉——用户看到的是它莫名其妙不说话。
print()
print("   跨轮复述（上一轮查过、这一轮 calls 为空）：")
_seen = {5.0, 2.0, 1.0, 3.0, 4.0, 45.0}
for text, should_block in (("计算机的自驱要求是 5 分。", False),
                           ("它每周 45 小时，你受得了吗？", False),
                           ("它每周 70 小时。", True)):
    out, why2 = guard(text, [], _seen)
    blocked = bool(why2)
    ok = blocked == should_block
    print(f"     {'✓' if ok else '✗'} {'拦下' if blocked else '放行'}　"
          f"{text[:36]}" + (f"（{why2}）" if why2 else ""))
    if not ok:
        bad.append((text, "跨轮该" + ("拦" if should_block else "放"),
                    "实际" + ("拦了" if blocked else "放了")))

# 一次工具都没调时，任何带量词的数字都该拦
print()
print("   一次工具都没调的情况：")
for text in ("这个专业每周要 45 小时。", "就业率 98%。",
             "咱先聊两三件事。"):
    out, why2 = guard(text, [])
    print(f"     {'拦下' if why2 else '放行'}　{text[:38]}"
          + (f"（{why2}）" if why2 else ""))

print()
print("=" * 74)
print(f"  {'✓ 稿子承诺的拦截行为全部对' if not bad else f'✗ {len(bad)} 处：'}")
if bad:
    for b in bad:
        print(f"     {b}")
