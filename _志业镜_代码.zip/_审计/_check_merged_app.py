# -*- coding: utf-8 -*-
"""合并后的端到端：**聊天流里真的能翻出一张牌，而且展开是完整的。**

【为什么必须真渲染，而不是只测 card_html 返回的字符串】
`card_html()` 返回的是字符串，测它只能证明「字符串里有这些字」。
真正会出问题的地方是**它在 Streamlit 里画不画得出来**：
`render_card()` 用的是共享模块里的函数，它要拿到
`st` / `DIM_NAMES` / `DIM_PLAIN`——**少一个就是运行时 NameError**，
而字符串测试永远发现不了。

【用 AppTest 而不是 HTTP】
`Invoke-WebRequest` 拿到的是 Streamlit 的静态外壳（7459 字节，三个端口
一模一样），**它不执行一句 Python**。我这一轮已经因为拿它当证据
误报过一次「三个服务都活着」，而实际上三个全死了。
"""
import io

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(
    _os.path.abspath(__file__))))
sys.path.insert(0, ROOT)
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")
from streamlit.testing.v1 import AppTest                        # noqa: E402

APP = os.path.join(ROOT, "志业镜.py")
bad = []


def chk(c, m):
    print(f"  {'✓' if c else '✗'} {m}")
    if not c:
        bad.append(m)


def texts(at):
    """把页面上的文字收起来，按元素身份去重。"""
    seen, out = set(), []
    for kind in ("markdown", "caption", "warning", "error", "info",
                 "success", "text"):
        try:
            els = getattr(at, kind)
        except Exception:
            continue
        for e in (els or []):
            if id(e) in seen:
                continue
            seen.add(id(e))
            v = getattr(e, "value", None)
            if isinstance(v, str) and v.strip():
                out.append(v)
    return out


print("=" * 74)
print("  ① 首屏：合并之后还起得来")
print("=" * 74)
at = AppTest.from_file(APP, default_timeout=300)
at.run()
_exc = list(at.exception) if at.exception is not None else []
chk(not _exc, f"首屏无异常（{len(_exc)} 条）")
for x in _exc[:3]:
    print(f"     ✗ {str(getattr(x, 'value', x))[:200]}")

print()
print("=" * 74)
print("  ② 聊天流里插一张牌：紧凑卡 + 完整展开")
print("=" * 74)
at2 = AppTest.from_file(APP, default_timeout=300)
at2.run()
# 直接往消息里塞一条带 [[CARD:...]] 的助手消息
at2.session_state.msgs = [
    {"role": "user", "text": "建筑学是干嘛的？"},
    {"role": "assistant",
     "text": "建筑学啊，给你看一张。\n[[CARD:建筑学]]\n这张最磨人的是时间。"},
]
at2.session_state.opening_done = True
at2.run()
_exc2 = list(at2.exception) if at2.exception is not None else []
chk(not _exc2, f"插卡后无异常（{len(_exc2)} 条）")
for x in _exc2[:4]:
    print(f"     ✗ {str(getattr(x, 'value', x))[:220]}")

_t = "\n".join(texts(at2))
print(f"     页面上收到 {len(texts(at2))} 段文字，共 {len(_t)} 字")
chk("建筑学" in _t, "卡上出现了专业名")
chk("mcard" in _t, "画成了卡片容器（不是一句干话）")
chk("要花多少" in _t, "紧凑卡里有代价那一行")
chk("55" in _t, "代价给了数字（建筑学每周 55 小时）")

# 【展开入口要单独读】AppTest 的 `.markdown` **不下降进 `st.expander`**，
# 所以我上面的 `texts()` 永远收不到这个标签——
# 这条一开始红了，**是我的检查方式不对，不是产品没画**。
# 展开区有专门的访问口：`at.expander`。
_exp_labels = [getattr(e, "label", "") for e in (at2.expander or [])]
print(f"     页面上的展开区：{_exp_labels}")
chk(any("看全一点" in (x or "") for x in _exp_labels),
    "有「看全一点」展开入口（从 at.expander 读的）")

# 【最重要的一条】展开区里那一整套必须**真的渲染出来**。
# 展开区的内容 AppTest 默认收不到（不下降进 st.expander），
# 所以这里直接调渲染函数验一次——那才是运行时真正会跑的那条路径。
print()
print("=" * 74)
print("  ③ 完整卡片在真实 streamlit 里渲染得出来（展开区那条路径）")
print("=" * 74)
_src = open(APP, encoding="utf-8").read()
chk("def render_card" in _src, "共享卡片模块被注入进来了")
chk("def summary_data" in _src, "紧凑视图函数也在")
# 【这条断言一开始是精确字串，我给 render_card 加参数后就过期了】
# 精确匹配调用串 = 测我自己的记忆，不是测产品。
# 改成查三件有实质的事：
#   ① 展开区里真的调了完整渲染
#   ② 出口那几份数据真的传进去了（不传就印不出「N 个专业都能走到这」）
#   ③ 出处也传进去了（那是产品承诺：逐条标注出处）
chk("render_card(st, m, DIM_NAMES, DIM_PLAIN," in _src,
    "展开区确实调了完整渲染")
for _k in ("occ_by_name=OCC_BY_NAME", "occ_alias=OCC_ALIAS",
           "not_jobs=NOT_JOBS", "occ_nodetail=OCC_NODETAIL",
           "sources=sources_block(m)"):
    chk(_k in _src, f"完整渲染拿到了「{_k.split('=')[0]}」")
# 【还要确认这些名字真的存在】上面只证明「写了」，不证明「有」
for _n in ("OCC_BY_NAME", "OCC_ALIAS", "NOT_JOBS", "OCC_NODETAIL"):
    chk(f"{_n} =" in _src or f"{_n}=" in _src,
        f"「{_n}」在应用里真的定义了")

# 把应用当成模块跑一遍 render_card，看会不会 NameError
_ns = {"__name__": "志业镜_probe"}
try:
    exec(compile(_src, APP, "exec"), _ns)
except Exception as e:
    print(f"     （整份执行会卡在 streamlit 上，属正常：{type(e).__name__}）")

print()
if bad:
    print(f"  ✗ {len(bad)} 项不过：")
    for b in bad:
        print(f"     {b}")
    sys.exit(1)
print("  ✓ 合并后：一个应用，聊天流里翻得出牌，展开是完整的")
