# -*- coding: utf-8 -*-
"""访谈两页的界面：都要渲染、不崩，而且不该说的别说。

【为什么必须单独测界面】
`interview_result` 算对了，界面照样可能崩——比如
`interview_turn` 里漏了一个 st 调用、`interview_page` 里
在某条分支上引用没答的项。所以走真实函数。
"""
import io

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(
    _os.path.abspath(__file__))))
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")



class F:
    def __init__(self):
        self.marked, self.captions, self.session_state = [], [], {}
        self.warn, self.err, self.ok, self.info = [], [], [], []
        self._radio, self._btn = {}, None
        # 【必须在这里初始化】
        # 少这一行时，__getattr__ 会把 self.radios 当成一个**未定义的方法名**
        # 返回一个函数对象，于是 `.append(...)` 报
        # 「'function' object has no attribute 'append'」——
        # 报错信息指向 append，但真正缺的是这一行初始化。
        self.radios = []

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    @property
    def sidebar(self):
        return self

    def columns(self, x):
        return [self] * (x if isinstance(x, int) else len(x))

    def tabs(self, n):
        return [self] * len(n)

    def expander(self, *a, **k):
        return self

    def spinner(self, *a, **k):
        return self

    def multiselect(self, *a, **k):
        return []

    def selectbox(self, *a, **k):
        return (a[0][0] if a and a[0] else "")

    def radio(self, *a, **k):
        lbl = k.get("key") or (a[0] if a else "")
        # 【把选项记下来】
        # 选项是作为 st.radio 的参数传进去的，不是 st.markdown。
        # 假 radio 不记的话，「选项有没有全显示」就永远查不出来——
        # 我第一版就是这样误报的。
        opts = a[1] if len(a) > 1 else k.get("options")
        if isinstance(opts, (list, tuple)):
            self.radios.append((lbl, list(opts)))
        if lbl in self._radio:
            return self._radio[lbl]
        if isinstance(opts, (list, tuple)) and opts:
            return opts[0]
        return None

    def text_area(self, *a, **k):
        return ""

    def text_input(self, *a, **k):
        return ""

    def progress(self, *a, **k):
        return self

    def button(self, *a, **k):
        return self._btn is not None and str(a[0]) == self._btn

    def __getattr__(self, name):
        def f(*a, **k):
            _v = str(a[0]) if a else ""
            for attr, bucket in (("markdown", self.marked),
                                 ("caption", self.captions),
                                 ("warning", self.warn),
                                 ("error", self.err),
                                 ("success", self.ok),
                                 ("info", self.info)):
                if name == attr:
                    bucket.append(_v)
            return None
        return f


sys.path.insert(0, ROOT)
import _majors_src_loader as _L                                  # noqa: E402
# 【数据从加载器来，不自己 exec 源码】
# 源码里是 `__MAJOR_DATA__` 这类占位符，直接 exec 会 JSONDecodeError。
# 加载器先让组装器拼好，再切断界面。
saved = sys.modules.get("streamlit")
fake = F()
sys.modules["streamlit"] = fake
NS = _L.load()

ASK = NS["ASK"]
OPT = NS["OPTIONS"]
bad = []


def alltext(f):
    return "\n".join(f.marked + f.captions + f.warn + f.err + f.ok + f.info)


print("=" * 74)
print("① 问题页：七问都要出现，而且不许出现结论性的话")
print("=" * 74)
fake.marked.clear()
fake.captions.clear()
st = dict(NS["new_state"]())
try:
    NS["interview_turn"](st)
    t = alltext(fake)
except Exception as e:
    t = ""
    bad.append(("问题页崩了", f"{type(e).__name__}: {e}"))
    print(f"   ✗ 崩了：{type(e).__name__}: {e}")
_qtxt = [q for q, _ in ASK]
_missing = [q for q in _qtxt if q not in t]
print(f"   七问都在页上：{'✓' if not _missing else '✗ 少了 ' + str(_missing)}")
if _missing:
    bad.append(("问题页少了题", _missing))
# 每个维度的四个选项都要出现
_shown = [o for _l, _os in fake.radios for o in _os]
_miss_opt = []
for d in OPT:
    for _, lbl, _say in OPT[d]:
        if lbl not in _shown:
            _miss_opt.append(lbl[:18])
print(f"   所有选项都传给了 radio："
      f"{'✓' if not _miss_opt else '✗ 少了 ' + str(_miss_opt[:4])}")
if _miss_opt:
    bad.append(("选项没全显示", _miss_opt))
# 不许出现结论
for _w in ("你适合", "推荐你学", "你的匹配度"):
    if _w in t:
        bad.append(("问题页出现了结论话", _w))
print(f"   问题页没有结论性的话："
      f"{'✓' if not any(w in t for w in ('你适合', '推荐你学', '你的匹配度')) else '✗'}")
# 必须明说「没试过是合法答案」
print(f"   说了「没试过」是合法答案："
      f"{'✓' if '合法答案' in t else '✗'}")
if "合法答案" not in t:
    bad.append(("没说清「没试过」合法",))

print()
print("=" * 74)
print("② 对照页：三种输入各跑一遍")
print("=" * 74)
SCEN = [
    ("全答满", [5] * 7),
    ("全答最低", [1] * 7),
    ("一半没答", [5, None, 3, None, 5, 3, None]),
    ("一项没答", [4, 4, 4, 4, 4, 4, None]),
    ("全都没答", [None] * 7),
]
for name, ans in SCEN:
    fake.marked.clear()
    fake.captions.clear()
    fake.warn.clear()
    fake.err.clear()
    fake.ok.clear()
    fake.info.clear()
    st = dict(NS["new_state"]())
    st["iv_ans"] = ans
    st["iv_asked"] = True
    try:
        NS["interview_page"](st)
        t = alltext(fake)
        # 【必须显式传专业名单】
        # 这个函数的 `majors` 参数已经改成必需了（以前会退回一个
        # 只存在于应用里的全局 `MAJORS`，独立跑会 NameError、
        # 换个上下文会静默拿错名单）。所以这里也要给。
        _r = NS["interview_result"](ans, NS["MAJORS"])
        # 三个数必须都出现在页上（用户要能看到分堆）
        #
        # 【一项都没答时是例外】
        # 那一轮走的是早退分支（「空手是比不出东西的」），
        # **本来就不该出现分堆数字**。
        #
        # 【第二版也错了：我要求「三个数都在页上」】
        # `str(len(_r['agree'])) in t` 这种断言有两个毛病：
        #   ① 一致数为 0 时产品**有意不给数字**——
        #      它印的是「**一个都对不上。**」（见 `_interview_core.py`
        #      的 `else` 分支）。要求印「0 个」是在要求它说废话。
        #   ② `"0" in t` 这种单字符子串本来就满篇都能撞上，
        #      它几乎必然为真——**这条断言其实什么都没验。**
        # 所以改成按**产品的真实措辞**判：
        #   一致 > 0  → 必须出现那个数
        #   一致 = 0  → 必须出现「一个都对不上」
        #   落差 > 0  → 必须出现「落差最小的几个」
        if not any(x is not None for x in ans):
            seen = ("空手" in t) or ("什么也推不出" in t)
            want = "走了早退分支、没编分堆数字"
        else:
            _na, _ng, _nu = (len(_r["agree"]), len(_r["gap"]),
                             len(_r["unknown"]))
            _c1 = ((f"{_na}" in t) if _na
                   else ("一个都没有" in t or "一个都对不上" in t))
            _c2 = (("有落差的" in t) if _ng else True)
            # 证据不足那一堆是页上「没试过的：N 项」那类说法
            _c3 = (_nu == 0) or (str(_nu) in t)
            seen = _c1 and _c2 and _c3
            if not seen:
                # 【不许只报「没过」】把三项各自的判据都印出来，
                # 不然下一个人（包括我自己）还得再查一遍为什么。
                print(f"      c1={_c1}（一致 {_na}）　c2={_c2}（落差 {_ng}）"
                      f"　c3={_c3}（证据不足 {_nu}）")
                print(f"      页上有没有「一个都对不上」："
                      f"{'一个都对不上' in t}")
                print(f"      页上有没有「落差最小的几个」："
                      f"{'落差最小的几个' in t}")
                print(f"      页上前 300 字：{t[:300]!r}")
            want = "分堆说清了"
        print(f"   ✓ {name:8} 一致{len(_r['agree']):3} 落差{len(_r['gap']):3} "
              f"证据不足{len(_r['unknown']):3}　{len(t):5} 字　"
              f"{want if seen else '**有数没显示**'}")
        if not seen:
            bad.append((name, "分堆数字没显示在页上"))
    except Exception as e:
        bad.append((name, f"崩了 {type(e).__name__}: {e}"))
        print(f"   ✗ {name} 崩了：{type(e).__name__}: {e}")

print()
print("=" * 74)
print("③ 对照页必须说明「它做不到什么」（四条）")
print("=" * 74)
fake.err.clear()
fake.marked.clear()
fake.captions.clear()
st = dict(NS["new_state"]())
st["iv_ans"] = [5] * 7
NS["interview_page"](st)
_e = "\n".join(fake.err)
for kw in ("不知道你喜欢什么", "没有校准", "刻度误差", "家里的情况"):
    ok = kw in _e or kw in "\n".join(fake.marked)
    print(f"   {'✓' if ok else '✗'} 说了「{kw}」")
    if not ok:
        bad.append(("没说明限制", kw))
if not fake.err:
    bad.append(("对照页没有一条 error 级的限制说明",))
    print("   ✗ 一条 error 都没有——限制说明被降级了")
else:
    print(f"   ✓ 有一整块 error 级限制说明（{len(_e)} 字）")

print()
print("=" * 74)
print("  ✓ 访谈界面全部通过" if not bad else f"  ✗ {len(bad)} 处：{bad}")
