# -*- coding: utf-8 -*-
"""界面啰嗦的闸门：给侧栏和主区定字数预算，超了就红。

【为什么要有这个】
用户原话：「你的侧栏废话太多了，比较啰嗦」。
而我每一轮都在往里加东西，**每一条加的时候都有理由**。
没有预算，界面只会单向变长，而「这次读着还行」不是标准。

【为什么预算按「不同文字」算，以及为什么这条注释这么长】
这一个量法我前后写错四次，每次错法不同，而**每一个错法都会让我
得出一个相反的结论**：
  ① `AT.children` 是 `None` → 从根节点就断了 → 侧栏 0 字
     → 差点得出「侧栏不啰嗦」，而用户说的恰恰是侧栏
  ② `Block.children` 里含着那些元素，我又单独遍历元素列表
     → 同一段收 2—3 遍 → 侧栏 668 字（虚高 3 倍）
  ③ 同一个元素的 `body` 和 `value` 是同一句话 → 又收两遍
  ④ 内联 CSS 有 822 字、一次都不出现在屏幕上；
     而 `AT.markdown` 会把**侧栏那一份也算进主区**
     → 对话版主区看起来 1,360 字，真实 99 字
所以这里要同时做三件事：按元素身份去重、按文本去重、剔掉 CSS
和侧栏那一份。少做任何一件，数字都是假的。

【预算怎么定】
不是拍脑袋：定在「当前实测值 + 一小截余量」。
将来加东西的时候，一旦顶破，就得先想清楚删什么。
"""
import io
import sys

from streamlit.testing.v1 import AppTest

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(
    _os.path.abspath(__file__))))
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")

ELEMS = ("markdown", "caption", "warning", "success", "info", "error",
         "button", "radio", "selectbox", "text_input", "multiselect",
         "checkbox", "text_area")

# ── 预算 ──
# 侧栏是用户点名抱怨的地方，卡得紧一点。
BUDGET = {
    #                       侧栏字数   主区字数
    # 【牌局那一项撤了】产品合并成一个应用，那个界面不在产品里了。
    # 它现在只剩源文件 `_majors_src.py`（讲稿和工作台还在读它），
    # 所以「它字多不多」不再是这个产品的预算问题。
    "对话 · 开场": (520, 200),
    # 访谈第一题：出了题干 + 四到五个选项，所以主区放宽到 520。
    # **但它仍然要有上限**——七题全铺一屏就是「读报告」，
    # 而这份问卷的用法是「一题一屏」。
    "对话 · 访谈第一题": (520, 520),
}
# 「解释我自己怎么想的」——注释漏到界面上就是这种句子。
# 允许 1 处（查库外专业那段必须解释「不编」，那是立场不是注释）。
META_BUDGET = 1

bad = []


def chk(c, m):
    print(f"  {'✓' if c else '✗'} {m}")
    if not c:
        bad.append(m)


def collect(block, side):
    seen, out = set(), []

    def take(e):
        if id(e) in seen:
            return False
        seen.add(id(e))
        return True

    def rec(node, d=0):
        if d > 12 or not take(node):
            return
        for name in ("body", "value", "label"):
            v = getattr(node, name, None)
            if isinstance(v, str) and v.strip() and v.strip() != "False":
                out.append((side, v))
        kids = getattr(node, "children", None)
        if isinstance(kids, dict):
            for c in kids.values():
                rec(c, d + 1)
        elif isinstance(kids, (list, tuple)):
            for c in kids:
                rec(c, d + 1)
        for name in ELEMS:
            try:
                seq = getattr(node, name, None)
            except Exception:                                # noqa: BLE001
                continue
            if seq is None or not hasattr(seq, "__iter__"):
                continue
            try:
                for e in seq:
                    if hasattr(e, "children"):
                        rec(e, d + 1)
                    elif take(e):
                        for a in ("value", "label"):
                            v2 = getattr(e, a, None)
                            if isinstance(v2, str) and v2.strip() \
                                    and v2.strip() != "False":
                                out.append((side, v2))
            except Exception:                                # noqa: BLE001
                pass
    rec(block)
    uniq = {}
    for s, t in out:
        tt = t.strip()
        if tt.startswith("<") or set(tt) <= set("-— "):
            continue
        uniq.setdefault(tt, s)
    return [(s, t) for t, s in uniq.items()]


def grab(path, clicks=()):
    at = AppTest.from_file(path, default_timeout=180)
    at.run()
    for c in clicks:
        btn = next((b for b in at.button if c in (b.label or "")), None)
        if btn is None:
            return None, None, at
        btn.click()
        at.run()
    side = collect(at.sidebar, "sidebar")
    main = collect(at, "main")
    st_ = {t for _s, t in side}
    main = [(s, t) for s, t in main if t not in st_]
    return main, side, at


CASES = [
    # 【产品合并成一个应用了，这里跟着改】
    # 原来第一项测的是牌局那个独立应用（专业游乐场.py）。
    # 现在产品只有 `志业镜.py`，所以两项都指向它，
    # 但**测的是两个不同的界面**：开场，和访谈。
    # 访谈那一页是主区里字数最多的一屏（七题 + 结果），
    # 它是最该被预算盯住的那一页，所以不能省掉。
    ("对话 · 开场", f"{ROOT}\\志业镜.py", ()),
    # 【这里传的是按钮的**标签片段**，不是 key】
    # 我第一版传了 key（"iv_enter"），`grab()` 找的是 `c in b.label`，
    # 于是「点不到预期的按钮」——**报的错和真因差得很远**，
    # 差一点让我去查按钮的 key 设得对不对。
    ("对话 · 访谈第一题", f"{ROOT}\\志业镜.py", ("换我问你",)),
]

tot = []
for label, path, clicks in CASES:
    main, side, _at = grab(path, clicks)
    if main is None:
        chk(False, f"{label}：点不到预期的按钮")
        continue
    mtot = sum(len(t) for _s, t in main)
    stot = sum(len(t) for _s, t in side)
    tot.append((label, stot, mtot))
    bs, bm = BUDGET.get(label) or BUDGET["对话 · 开场"]
    print("=" * 74)
    print(f"  {label}")
    print("=" * 74)
    chk(stot <= bs, f"侧栏 {stot} 字 ≤ 预算 {bs}（{len(side)} 段）")
    chk(mtot <= bm, f"主区 {mtot} 字 ≤ 预算 {bm}（{len(main)} 段）")

    # 「解释我自己怎么想的」
    import re                                                # noqa: E402
    META = [r"我第[一二三四五六七八九十]版", r"我原来", r"第一版",
            r"我核过一?遍", r"我逐条核过", r"不是我挑的", r"算出来",
            r"我确实没有材料", r"我不编", r"别用别的专业",
            r"为什么要", r"这个字段", r"返回值", r"等于让人信",
            r"用户会怀疑"]
    allt = [t for _s, t in main] + [t for _s, t in side]
    hits = [(p, t) for p in META for t in allt if re.search(p, t)]
    chk(len(hits) <= META_BUDGET,
        f"「解释我自己怎么想的」{len(hits)} 处 ≤ {META_BUDGET}"
        + (f"　{hits[0][1][:50]!r}" if hits else ""))

    # 空话：没有任何数字、也没有任何具体名词的短句
    # （提醒自己别再加「功能是全的」这种）
    print(f"     侧栏在这：{[t[:26] for _s, t in side]}")
    print()

print("=" * 74)
print("  汇总")
print("=" * 74)
for label, s, m in tot:
    print(f"   {label:<16} 侧栏 {s:>4} 字　主区 {m:>4} 字")

print()
if bad:
    print(f"  ✗ {len(bad)} 项超预算：")
    for b in bad:
        print(f"     {b}")
    sys.exit(1)
print("  ✓ 两个界面的字数都在预算内，没有把注释漏到界面上")
