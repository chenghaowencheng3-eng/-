# -*- coding: utf-8 -*-
"""查一个没做的专业：883 个全部逐个核对。

【核对哪几件事】
1. 883 个官方专业名，每一个都要解析成 catalog 或 card，**一个都不能落到 none**
2. 库里 161 个卡，每一个都要解析成 card（我做的牌不能被自己的查询判成「没有」）
3. 93 个专业类名，每一个都要解析成 class
4. 那一小撮情况必须落到各自的分支，不许串：
   打错字→near / 瞎写→none / 空→none
5. 【最容易错的一条】专业类名和某个专业同名时会不会认错？
   比如「哲学类」是类，「哲学」是专业——两个都要分得清。
"""
import io

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(
    _os.path.abspath(__file__))))
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")


class F:
    def __init__(self):
        self.marked, self.captions, self.session_state = [], [], {}

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    @property
    def sidebar(self):
        return self

    def columns(self, x):
        return [self] * (x if isinstance(x, int) else len(x))

    def tabs(self, n):
        return [self] * len(n)

    def expander(self, *a, **k):
        return self

    def spinner(self, *a, **k):
        return self

    def multiselect(self, *a, **k):
        return []

    def selectbox(self, *a, **k):
        return (a[0][0] if a and a[0] else "")

    def radio(self, *a, **k):
        return (a[0][0] if a and a[0] else "")

    def text_area(self, *a, **k):
        return ""

    def text_input(self, *a, **k):
        return ""

    def __getattr__(self, name):
        def f(*a, **k):
            if name in ("markdown", "info", "warning", "error", "success"):
                self.marked.append(str(a[0]) if a else "")
            if name == "caption":
                self.captions.append(str(a[0]) if a else "")
            if name == "button":
                self.marked.append(str(a[0]) if a else "")
                return False
            return None
        return f


# 【产品合并成一个应用之后，这个闸门改成走共享加载器】
# 它测的是**数据和查询逻辑**，不是界面：
# 883 个官方专业名逐个查得到、161 张牌不被自己的查询判成没有、
# 93 个专业类认得出、「哲学类」和「哲学」分得清。
# 这些和有几个界面没关系，所以不该因为少了一个应用就失去被测的机会。
#
# 【而且走加载器比原来更可靠】
# 原来这里自己读 `专业游乐场.py`、自己切 `if __name__` 守卫。
# 现在 `_majors_src_loader` 用的是**组装器自己拼出来的那一份**，
# 并且刚验过它和产品本体的数据逐字段一致（`_审计/_check_loader.py`）。
sys.path.insert(0, ROOT)
import _majors_src_loader as _L                                 # noqa: E402

NS = _L.load(need=("resolve_major", "CAT_MAJOR", "CAT_CLASS", "MAJORS"))

R = NS["resolve_major"]
CAT = NS["CAT_MAJOR"]
CLS = NS["CAT_CLASS"]
MAJORS = NS["MAJORS"]

bad = []
print("=" * 74)
print(f"① 官方目录 {len(CAT)} 个专业，逐个解析")
print("=" * 74)
kinds = {}
for nm in CAT:
    k, p = R(nm)
    kinds[k] = kinds.get(k, 0) + 1
    if k not in ("card", "catalog"):
        bad.append((nm, k))
print(f"   结果分布：{kinds}")
print(f"   落到 card/catalog 之外的：{bad[:8] or '无 ✓'}")

print()
print("=" * 74)
print(f"② 库里 {len(MAJORS)} 张牌，每张都要解析成 card")
print("=" * 74)
_wrong = []
for m in MAJORS:
    k, p = R(m["n"])
    if k != "card":
        _wrong.append((m["n"], k))
print(f"   不是 card 的：{_wrong[:8] or '无 ✓'}")
bad += _wrong

print()
print("=" * 74)
print(f"③ {len(CLS)} 个专业类名")
print("=" * 74)
_cbad = []
for c in CLS:
    k, p = R(c)
    if k != "class":
        _cbad.append((c, k))
print(f"   不是 class 的：{_cbad[:8] or '无 ✓'}")
bad += _cbad
# 带「类」后缀也要认
_cbad2 = []
for c in list(CLS)[:30]:
    k, p = R(c + "类")
    if k != "class":
        _cbad2.append((c + "类", k))
print(f"   加「类」后缀后不是 class 的：{_cbad2[:6] or '无 ✓'}")
bad += _cbad2

print()
print("=" * 74)
print("④ 各类边界情况必须落对分支")
print("=" * 74)
CASES = [
    ("世界语", "catalog"), ("中医儿科学", "catalog"),
    ("哲学", "card"), ("临床医学", "card"),
    ("哲学类", "class"), ("临床医学类", "class"),
    ("完全不存在的东西", "none"), ("   ", "none"), ("", "none"),
    # 【这一条我原来期望 near，是错的】
    # 「研究生方向：算法」不是专业名，正确行为就是 none。
    # 我第一版期望它给建议——那个「期望」本身就是错的期待，
    # 也正是它掩盖了「只要有字重叠就给建议」这个真问题。
    ("研究生方向：算法", "none"),
]
# 【打错字的情形改成自动生成，不再手写期望】
# 我手写期望已经错了两次（「数据科学与大数据技术」其实库里有卡），
# 而每一次错都让我差点去改没坏的代码。
# 现在从官方目录里取真名字去掉一个字，期望就是「必须给出那个真身」。
_typos = []
for _nm in list(CAT):
    if len(_nm) >= 5 and _nm not in NS["BY_NAME"]:
        _typos.append((_nm[:-1], _nm))
    if len(_typos) >= 12:
        break
print("自动生成的打错字（去掉最后一个字），要求给出真身：")
_tbad = []
for _wrong, _right in _typos:
    _k, _p = R(_wrong)
    _ok = _k == "near" and _right in _p
    if not _ok:
        _tbad.append((_wrong, _k, _right))
    print(f"   {'✓' if _ok else '✗'} 「{_wrong}」→ {_k}"
          f"{'（含' + _right + '）' if _ok else '　应为 near 且含 ' + _right}")
bad += _tbad
print()
for text, want in CASES:
    k, p = R(text)
    ok = (k == want)
    if not ok:
        bad.append((text, f"期望{want} 实际{k}"))
    show = ""
    if k == "near":
        show = " → " + "、".join(p[:3])
    elif k == "class":
        show = f" → {p[0]}（{p[2]} 个专业）"
    elif k == "catalog":
        show = f" → {p[0]} / {p[1]} / {p[2]} / 满意度 {p[3]}"
    print(f"   {'✓' if ok else '✗'} 「{text}」→ {k}{show}")

print()
print("=" * 74)
print("⑤ 同名陷阱：专业类和专业名会不会串")
print("=" * 74)
# 找专业类名恰好也是某个专业名的情况
_overlap = [c for c in CLS if c in CAT]
print(f"   既是专业类名、又是专业名的：{_overlap or '无'}")
for c in _overlap[:4]:
    k, p = R(c)
    print(f"      「{c}」→ {k}")

print()
print("=" * 74)
if not bad:
    print("  ✓ 883 个官方专业、161 张牌、93 个专业类，全部解得对")
else:
    print(f"  ✗ {len(bad)} 处不对")
    for x in bad[:10]:
        print("     ", x)
