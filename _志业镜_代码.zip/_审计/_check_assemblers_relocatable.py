# -*- coding: utf-8 -*-
"""拼装器必须把产物写在自己所在的那一层，不许写回别的目录。

【这个坑长什么样，以及为什么值得单独一条闸门】
`_assemble_majors.py` 的 `ROOT` 原来写死成 `ROOT`。
我把代码打包给别人之后，在包里跑它：

  · 它的 stdout 说「已校验…落在 _专业游乐场.build-check.py」——**看着挺成功**
  · 包里那个文件**始终不存在**
  · 于是 `_majors_src_loader.ensure_built()` 每轮都以为「重拼了但产物还是没有」
  · 报出来的是 `RuntimeError: 拼装失败`，方向完全指错了

**它没撒谎，它说的是另一个目录的事。**
这种错不看审计钩子根本查不出来——我最后是靠 `sys.addaudithook`
抓 `open` 事件，才看见那条路径用的是正斜杠（拼出来的），
而包里文件都是反斜杠（拷出来的）。

所以这条闸门验的是：
  ① 拼装器里不许有写死的本机绝对路径
  ② 直接跑一遍拼装器，**产物必须出现在拼装器旁边**
  ③ 而且是这一轮刚写出来的（mtime 变新），不是捡了个旧的
"""
import io
import os
import re
import subprocess
import sys
import time

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(
    _os.path.abspath(__file__))))
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")

bad = []


def chk(c, m):
    print(f"  {'✓' if c else '✗'} {m}")
    if not c:
        bad.append(m)


# 拼装器 → 它该写出来的产物
PAIRS = [
    ("_assemble_majors.py", "_专业游乐场.build-check.py"),
    ("_assemble_agent2.py", "志业镜.py"),
]

print("=" * 74)
print("  ① 拼装器里不许写死本机绝对路径")
print("=" * 74)
for a, _out in PAIRS:
    src = open(os.path.join(ROOT, a), encoding="utf-8").read()
    # 【只查真正的赋值/字符串，不查注释】
    # 注释里为了说明这个坑，会引用那个路径——那是历史，不能算违规。
    body = "\n".join(ln for ln in src.splitlines()
                     if not ln.strip().startswith("#"))
    body = re.sub(r'"""(?:.|\n)*?"""', "", body)      # 模块 docstring
    chk("zhiyejing" not in body, f"{a} 里没有写死本机路径")
    chk("_root" in src and "find_root" in src,
        f"{a} 用 find_root() 定位")

print()
print("=" * 74)
print("  ② 跑一遍拼装器，产物必须出现在**它自己旁边**")
print("=" * 74)
for a, out in PAIRS:
    p = os.path.join(ROOT, out)
    _old = os.path.getmtime(p) if os.path.exists(p) else 0
    _t0 = time.time()
    r = subprocess.run([sys.executable, os.path.join(ROOT, a)], cwd=ROOT,
                       capture_output=True, text=True, encoding="utf-8",
                       errors="replace", timeout=900,
                       env={**os.environ, "PYTHONIOENCODING": "utf-8"})
    chk(r.returncode == 0, f"{a} 跑通（退出码 {r.returncode}）")
    if r.returncode != 0:
        print(f"       stderr 尾：{(r.stderr or '')[-300:]}")
        continue
    chk(os.path.exists(p), f"产物真出现在 {out}")
    if not os.path.exists(p):
        # 【把证据摆出来】它去哪儿了？在 ROOT 附近找找同名文件
        _found = []
        for _d in (ROOT, os.path.dirname(ROOT), os.getcwd()):
            _c = os.path.join(_d, out)
            if os.path.exists(_c) and os.path.abspath(_c) != os.path.abspath(p):
                _found.append(_c)
        print(f"       → 别处找到同名文件：{_found or '（没找到，那就是没写）'}")
        continue
    _new = os.path.getmtime(p)
    chk(_new >= _t0 - 2,
        f"{out} 是这一轮刚写的（不是捡了个旧的）")

print()
if bad:
    print(f"  ✗ {len(bad)} 项不过：")
    for b in bad:
        print(f"      {b}")
    raise SystemExit(1)
print("  ✓ 拼装器可搬迁，产物落在它自己旁边")
