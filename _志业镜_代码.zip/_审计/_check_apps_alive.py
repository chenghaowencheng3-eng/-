# -*- coding: utf-8 -*-
"""真页面冒烟：牌局和对话版的首屏到底渲染得出来吗。

【为什么不能看 HTTP 200】
我上一轮报「三个服务 HTTP 200」，而实际上**三个都在报「加载不出来」**。
`Invoke-WebRequest http://127.0.0.1:8503` 拿到的是 Streamlit 的
**静态 HTML 外壳（7459 字节，三端口一模一样）**——
**它不执行一句 Python。应用脚本崩了，这个请求照样 200。**
所以「HTTP 200」对这个产品**什么也没证明**。
这个脚本才是能证明「页面能出来」的东西。
"""
import io
import sys

from streamlit.testing.v1 import AppTest

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(
    _os.path.abspath(__file__))))
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")

bad = []


def chk(c, m):
    print(f"  {'✓' if c else '✗'} {m}")
    if not c:
        bad.append(m)


APPS = [
    # 【产品合并成一个应用了】
    # 原来这里有三个：牌局、对话、职业游乐场。
    # 现在用户要的是**一个应用**，所以主应用只有 `志业镜.py`。
    # 【但「页面能不能起来」这件事不能只验一个】
    # `_check_apps_alive.py` 的立论是「**真跑一遍**，而不是
    # 看 HTTP 200」——我拿 HTTP 200 误报过一次「三个服务都活着」，
    # 而当时三个全死了（Streamlit 的外壳在任何情况下都是 200）。
    # 所以这份清单里留的是**产品里真实存在的应用文件**：
    #   · 志业镜.py —— 唯一的产品
    #   · 职业游乐场.py —— 另一个可玩的雏形，还在仓库里，也得起得来
    ("志业镜（唯一应用 · 8503）", f"{ROOT}\\志业镜.py"),
    ("职业游乐场（8502）", f"{ROOT}\\职业游乐场.py"),
]

for label, path in APPS:
    print("=" * 74)
    print(f"  {label}")
    print("=" * 74)
    at = AppTest.from_file(path, default_timeout=300)
    at.run()
    exc = list(at.exception) if at.exception is not None else []
    chk(not exc, f"首屏渲染无异常（{len(exc)} 条）")
    for x in exc[:3]:
        print(f"     ✗ {str(getattr(x, 'value', x))[:200]}")
    # 首屏至少有内容
    n_md = len(at.markdown) if at.markdown is not None else 0
    chk(n_md > 0, f"首屏有 markdown 内容（{n_md} 块）")
    # 标题类文字非空
    ts = []
    for e in (at.markdown or []):
        v = getattr(e, "value", None)
        if isinstance(v, str) and v.strip():
            ts.append(v.strip())
    chk(bool(ts), f"收集到 {len(ts)} 段非空文字")
    if ts:
        print(f"     首段：{ts[0][:90]}")
    # 交互控件在
    n_btn = len(at.button) if at.button is not None else 0
    print(f"     控件：markdown {n_md} 块，button {n_btn} 个")
    print()

if bad:
    print(f"  ✗ {len(bad)} 项不过")
    for b in bad:
        print(f"     {b}")
    sys.exit(1)
print(f"  ✓ {len(APPS)} 个应用首屏都真的渲染得出来"
      f"（这才算「页面能加载」）")
