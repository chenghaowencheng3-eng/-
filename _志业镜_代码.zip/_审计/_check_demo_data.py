# -*- coding: utf-8 -*-
"""看七步各自有没有 avoid / ir 数据，以及第 2 步的讲解词。

【产品合并成一个应用之后这里改了什么】
这七步演示（`WALKTHROUGH`）**只活在牌局的源文件里**，
对话版没有搬它——所以它现在不是产品的一部分，只是源里有的一段材料，
讲稿要用。所以这个脚本留着，改成走共享加载器
（`_majors_src_loader`），不再自己读一个已经不存在的应用文件。

【执行顺序这一条踩过坑】
我第一次把假 streamlit 装在了 `L.load()` **之后**——
可加载器执行 `_tools_core.py` 时会 `import streamlit`，
于是真 streamlit 被导进来了，整页刷屏
「missing ScriptRunContext」。
**假模块必须在加载之前就位。** 所以下面先装、后加载。
"""
import io
import json
import sys
import types

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(
    _os.path.abspath(__file__))))
sys.path.insert(0, ROOT)
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")

_collected = {"markdown": [], "caption": []}


def _rec(kind):
    def _f(*a, **k):
        if a:
            _collected[kind].append(str(a[0]))
        return False
    return _f


class _Ctx:
    """假的上下文管理器 / 容器。"""

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def __getattr__(self, name):
        return _rec("markdown")


_fake = types.ModuleType("streamlit")
for _m in ("markdown", "warning", "error", "info", "success", "text",
           "write", "header", "subheader", "title"):
    setattr(_fake, _m, _rec("markdown"))
setattr(_fake, "caption", _rec("caption"))


def _cols(x, **k):
    n = x if isinstance(x, int) else len(x)
    return [_Ctx() for _ in range(n)]


setattr(_fake, "columns", _cols)
setattr(_fake, "tabs", _cols)
setattr(_fake, "container", _Ctx())
setattr(_fake, "expander", lambda *a, **k: _Ctx())
setattr(_fake, "spinner", lambda *a, **k: _Ctx())
setattr(_fake, "form", lambda *a, **k: _Ctx())
setattr(_fake, "sidebar", _Ctx())
setattr(_fake, "button", lambda *a, **k: False)
setattr(_fake, "selectbox", lambda *a, **k: (a[0][0] if a and a[0] else ""))
setattr(_fake, "radio", lambda *a, **k: (a[0][0] if a and a[0] else ""))
setattr(_fake, "multiselect", lambda *a, **k: [])
setattr(_fake, "text_area", lambda *a, **k: "")
setattr(_fake, "text_input", lambda *a, **k: "")
setattr(_fake, "session_state", {})
setattr(_fake, "set_page_config", lambda *a, **k: None)
setattr(_fake, "rerun", lambda *a, **k: None)
setattr(_fake, "stop", lambda *a, **k: None)

# 【必须在加载之前装好】见文件头注释
sys.modules["streamlit"] = _fake

import _majors_src_loader as L                                   # noqa: E402

NS = L.load(need=("WALKTHROUGH", "BY_NAME", "new_state",
                  "demo_presenter_panel"))

print("七步各自有没有新块的数据：")
for i, st in enumerate(NS["WALKTHROUGH"]):
    m = NS["BY_NAME"][st["major"]]
    av = m.get("avoid") or []
    print(f"  第{i + 1}步  {st['major']:14}  avoid {len(av)} 条"
          f"   ir {bool(m.get('ir'))}   tilt {m.get('tilt')}")

print()
print("=" * 70)
print("第 2 步（数学与应用数学）的讲解词")
print("=" * 70)
st = NS["new_state"]()
st["mode"] = "demo"
st["step"] = 1
_collected["markdown"].clear()
_collected["caption"].clear()
NS["demo_presenter_panel"](st)
for l in _collected["markdown"]:
    print("   ", str(l)[:116])
for l in _collected["caption"]:
    print("    ·", str(l)[:116])

print()
print("=" * 70)
print("数学与应用数学的 avoid 原文（讲解词要能对上）")
print("=" * 70)
print(json.dumps(NS["BY_NAME"]["数学与应用数学"].get("avoid"),
                 ensure_ascii=False, indent=2))
