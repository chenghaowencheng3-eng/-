# -*- coding: utf-8 -*-
"""把压缩包解到一个干净目录，看看它到底跑不跑得起来。

【为什么必须实测】
「打包成功」和「拿到手能跑」是两件事。包里的 `志业镜.py` 是个
1.7 MB 的拼装产物，它**依赖四个 JSON**；漏一个就是起来就崩。
而我在自己的工作目录里跑，那些 JSON 都在——**所以我自己这儿永远是绿的**。
只有解到别处才知道包里到底缺不缺东西。
"""
import io
import os
import shutil
import subprocess
import sys
import zipfile

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(
    _os.path.abspath(__file__))))
# 【包内容和这个检查必须共用同一份清单】
# 两份清单一定会漂移，而漂移的样子是「闸门说齐了、包里其实没有」——
# 一个必然假的绿。所以清单住在 `_delivery_manifest.py` 里，两边都读它。
from _delivery_manifest import (DATA, FIXTURES, GATE_DIR,   # noqa: E402
                                PREBUILT, PRODUCT, SOURCES, TESTS,
                                TESTS_IN_GATE_DIR)
from _find_python import (find_streamlit_python,     # noqa: E402
                          run_with_fallback)
ZIP = os.path.join(ROOT, "_志业镜_代码.zip")
# 【解压目录必须**每次唯一**】
# 原来写死成 `_交付_实测`。这条闸门自己也在包里，
# 于是包里那条同名闸门被外层从 `_交付_实测` 里跑起来的时候，
# 它又去删掉并重建 `_交付_实测`——**删自己正踩着的树枝**。
# Windows 上目录被占用删不掉 → 内层崩 → 目录被拆了一半 →
# 后面 30 个闸门全报「文件不存在」，而我看到的是「30 个闸门不过」。
# 一个自己踩自己的测试，比没有测试更误导。
SANDBOX = os.path.join(ROOT, "_交付_实测_%d" % os.getpid())
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")

# 【这一条验的是「打出来的包对不对」，所以它得先有那个包】
# 它自己也在包里，于是会被包里的闸门再跑一遍——
# 那一轮没有 zip 也没关系，**跳过就行**。
# 出一条永远红的闸门，等于把真问题埋进噪声里：
# 每次看到红都以为是「已知的那条」，真出事就不看了。
if not os.path.exists(ZIP):
    print("=" * 74)
    print("  · 跳过：这一层里没有 `_志业镜_代码.zip`")
    print("    这条闸门验的是「打出来的包对不对」。")
    print("    在源码根目录跑它才有意义；在包里它是空转的。")
    print("=" * 74)
    raise SystemExit(0)

# 【解释器必须问出来，不能写死、也不能用 sys.executable】
# 用 `sys.executable` 的话：如果启动本闸门的是运行时环境（没有 streamlit），
# 那十几个 UI 闸门会齐刷刷报 `No module named 'streamlit'`——
# **看起来像包里缺东西，其实是我拿错了解释器。**
PY = find_streamlit_python()
if PY is None:
    raise SystemExit(
        "  ✗ 这台机器上找不到装了 streamlit 的解释器，"
        "包里的 UI 测试没法验——**不能当它过了**。")
print(f"  验证用的解释器：{PY}")

if os.path.isdir(SANDBOX):
    shutil.rmtree(SANDBOX)
os.makedirs(SANDBOX)
with zipfile.ZipFile(ZIP) as z:
    z.extractall(SANDBOX)

print(f"  解到：{SANDBOX}")
print()
for base, _d, files in os.walk(SANDBOX):
    rel = os.path.relpath(base, SANDBOX)
    if files:
        print(f"  {rel}\\  ({len(files)} 个)")
        for f in sorted(files)[:4]:
            print(f"      {f}")
        if len(files) > 4:
            print(f"      …还有 {len(files) - 4} 个")

bad = []


def chk(c, m):
    print(f"  {'✓' if c else '✗'} {m}")
    if not c:
        bad.append(m)


print()
print("  ── ① 清单里的文件都在包里（**按清单查，不按我记忆查**）──")
_WANT = (PRODUCT + SOURCES + DATA + TESTS + FIXTURES + PREBUILT
         + ["代码地图.md"])
_miss = [f for f in _WANT if not os.path.exists(os.path.join(SANDBOX, f))]
chk(not _miss, f"{len(_WANT)} 个文件都在（缺 {_miss}）")
_gd = os.path.join(SANDBOX, GATE_DIR)
chk(os.path.isdir(_gd), f"闸门目录 {GATE_DIR}/ 在包里")
_n_gates = len([f for f in (os.listdir(_gd) if os.path.isdir(_gd) else [])
                if f.startswith("_check_") and f.endswith(".py")])
_rg = len([f for f in os.listdir(os.path.join(ROOT, GATE_DIR))
           if f.startswith("_check_") and f.endswith(".py")])
chk(_n_gates == _rg, f"闸门一个不少（包里 {_n_gates} / 源里 {_rg}）")

print()
print("  ── ② 在干净目录里跑单元测试（数据齐不齐一眼看出来）──")
for t in TESTS:
    p = os.path.join(SANDBOX, t)
    if not os.path.exists(p):
        chk(False, f"{t} 不在包里")
        continue
    # 【cwd 用包根】和开发目录同构：测试就是在那儿跑起来的
    # 【解释器按脚本自己要什么挑，缺模块就换另一个】
    # 这台机器两个环境是分工的（见 `_find_python.run_with_fallback`）。
    # 一刀切会出现「十几条闸门齐刷刷报 No module named 'streamlit'」，
    # 看着像包里缺东西——**其实是解释器拿错了**。
    r = run_with_fallback(p, cwd=SANDBOX, timeout=900)
    tail = [ln for ln in (r.stdout or "").splitlines()
            if "结果：" in ln]
    chk(r.returncode == 0,
        f"{t}　{tail[-1].strip() if tail else f'退出码 {r.returncode}'}")
    if r.returncode != 0:
        for ln in (r.stdout or "").splitlines():
            if "✗" in ln:
                print(f"       {ln.strip()}")
        print("       stderr 尾：", (r.stderr or "")[-300:])

print()
print("  ── ③ 闸门在干净目录里也跑得起来 ──")
# 【先验「有没有闸门可跑」】
# 我第一版这里算出 0 过 / 0 不过，然后 `chk(_no == 0, ...)` **报了绿**——
# 一个空转的闸门比没有闸门更糟：它看起来像验过了。
#
# 【为什么跳过同名那一条】
# `_check_delivery.py` 自己也在包里。外层从 `_交付_实测` 里把它跑起来，
# 它又去删掉并重建 `_交付_实测`——**删自己正踩着的树枝**。
# Windows 上目录被占用删不掉，内层崩，目录被拆了一半，
# 后面 30 个闸门全报「文件不存在」。
# 更根本的是：**它就是外层正在跑的这条**，再跑一遍只是在递归，
# 而且它 `--` 的那种「包在不在」的问题外层已经验过。
# 跳过它不算放水——下面的计数用「跑过的 + 跳过的 == 总数」卡住，
# 保证这不是一个静默空转。
_SELF = os.path.basename(os.path.abspath(__file__))
_ok = _no = _skip = 0
_all_gates = (sorted(os.listdir(_gd)) if os.path.isdir(_gd) else [])
for g in _all_gates:
    if not (g.startswith("_check_") and g.endswith(".py")):
        continue
    if g == _SELF:
        _skip += 1
        continue
    _gp = os.path.join(_gd, g)
    r = run_with_fallback(_gp, cwd=SANDBOX, timeout=900)
    if r.returncode == 0:
        _ok += 1
    else:
        _no += 1
        if _no <= 3:
            print(f"       ✗ {g}（exit {r.returncode}）")
            # 【把两头都印出来】只印 stdout 的第一条 ✗，
            # 我会以为是闸门自己在报问题；真正的原因常常在 stderr。
            for ln in (r.stderr or "").splitlines()[-4:]:
                print(f"           stderr: {ln.strip()[:150]}")
            for ln in (r.stdout or "").splitlines()[-3:]:
                print(f"           stdout: {ln.strip()[:150]}")
print(f"     干净目录里：{_ok} 过 / {_no} 不过"
      f"（跳过同名那一条 {_skip} 个）")
chk(_ok + _no + _skip == _n_gates and _no == 0,
    f"闸门在干净目录里全过（{_ok}/{_n_gates}，跳过 {_skip}）")
# 【单独卡住「跳过的恰好一条」】否则哪天跳过变成 30 条，
# 上面那个加法照样成立，而实际上什么都没跑。
chk(_skip == 1, f"跳过的只有同名那一条（实际 {_skip} 个）")

print()
if bad:
    print(f"  ✗ {len(bad)} 项不过：")
    for b in bad:
        print(f"      {b}")
    raise SystemExit(1)
print("  ✓ 这个包解到干净目录里能跑，测试和闸门都过")

# 【自己搭的目录自己收】
# 不收的话，每跑一次就在仓库里留一个 `_交付_实测_<pid>`，
# 而且下一次遍历仓库的脚本会把它当成真目录扫进去。
try:
    shutil.rmtree(SANDBOX)
except OSError:
    pass                    # 删不掉就留着，不重要，不该因此报红
