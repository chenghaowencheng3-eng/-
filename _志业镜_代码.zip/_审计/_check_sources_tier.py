# -*- coding: utf-8 -*-
"""验证：出处行按 avoid_tier 区分，别把访谈核实过的标成「没有核实」。"""
import io

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(
    _os.path.abspath(__file__))))
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")



class F:
    def __init__(self):
        self.marked, self.captions, self.session_state = [], [], {}

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    @property
    def sidebar(self):
        return self

    def columns(self, x):
        return [self] * (x if isinstance(x, int) else len(x))

    def tabs(self, n):
        return [self] * len(n)

    def expander(self, *a, **k):
        return self

    def spinner(self, *a, **k):
        return self

    def multiselect(self, *a, **k):
        return []

    def selectbox(self, *a, **k):
        return (a[0][0] if a and a[0] else "")

    def radio(self, *a, **k):
        return (a[0][0] if a and a[0] else "")

    def text_area(self, *a, **k):
        return ""

    def text_input(self, *a, **k):
        return ""

    def __getattr__(self, name):
        def f(*a, **k):
            if name in ("markdown", "info", "warning", "error", "success"):
                self.marked.append(str(a[0]) if a else "")
            if name == "caption":
                self.captions.append(str(a[0]) if a else "")
            if name == "button":
                self.marked.append(str(a[0]) if a else "")
                return False
            return None
        return f


sys.path.insert(0, ROOT)
import _majors_src_loader as _L                                  # noqa: E402
# 【数据从加载器来，不自己 exec 源码】
# 源码里是 `__MAJOR_DATA__` 这类占位符，直接 exec 会 JSONDecodeError。
# 加载器先让组装器拼好，再切断界面。
saved = sys.modules.get("streamlit")
fake = F()
sys.modules["streamlit"] = fake
NS = _L.load()

APP = NS["MAJORS"]
print("avoid_tier 分布：")
from collections import Counter
c = Counter(m.get("avoid_tier") for m in APP if m.get("avoid"))
for k, v in c.items():
    print(f"   {k}  {v}")
print()

for nm in ("建筑学", "临床医学", "哲学", "汉语言文学"):
    m = NS["BY_NAME"][nm]
    fake.marked.clear()
    fake.captions.clear()
    NS["sources_rows"](m)
    t = "\n".join(fake.marked)
    print(f"--- {nm}　avoid_tier={m.get('avoid_tier')} "
          f"ir={'有' if m.get('ir') else '无'} ---")
    got = False
    for line in t.split("\n"):
        if "想跑" in line or "AI 位置" in line:
            print("   ", line[:136])
            got = True
    if not got:
        print("    （没有这两行——该专业没有 avoid/ir 数据）")

# 逐条核对：标了「访谈核实」的必须 tier=C1
bad = []
for m in APP:
    fake.marked.clear()
    fake.captions.clear()
    try:
        NS["sources_rows"](m)
    except Exception as e:
        bad.append((m["n"], f"崩溃 {type(e).__name__}"))
        continue
    t = "\n".join(fake.marked)
    for line in t.split("\n"):
        if "什么情况会让你想跑" in line:
            said_c1 = "访谈核实" in line
            is_c1 = m.get("avoid_tier") == "C1"
            if said_c1 != is_c1:
                bad.append((m["n"], f"说{said_c1} 实际{is_c1}"))
print()
print(f"161 个专业的「想跑」出处标注核对："
      f"{'全部一致 ✓' if not bad else '✗ ' + str(bad[:6])}")
print(f"（其中标「访谈核实」的应有 "
      f"{c.get('C1', 0)} 个）")
