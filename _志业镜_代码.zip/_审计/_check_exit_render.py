# -*- coding: utf-8 -*-
"""出口名单里「点不开」的名字，应用**实际印了什么**。

【这个闸门为什么必须存在】
出口那一行里有两类名字：
  · 平台做过详情页的 → 可以点开看
  · 平台登记了、但还没做详情页的 → **点不开**
这两类长得一模一样，如果不说清楚，用户会以为「点不开」= 这个专业没出路。
所以应用必须**当场印出来**：「平台登记了，还没做详情页」，
并说清「N 个专业都能走到这」——那是**通用出口，不是这一张牌的特征出口**。

【合并成一个应用之后，这个闸门改了什么】
原来它驱动牌局应用（点「直接翻开 X」按钮）去看那一句。
产品合并了，那个界面不在了；但这句话**现在必须印在
对话版那个「看全一点」展开区里**（`render_card` 的出口块）。
所以改成直接调那个渲染函数——它正是展开区调的那个。

【这个文件我写错过三版，每一版都留着】
① `chk(AT.exception is None, ...)` —— `AT.exception` 是 `ElementList`，
   空列表**也不等于 None**，所以那三条「无异常」永远为假。
② 只收 `AT.markdown` —— 出口详情在 `st.expander` 里，而它是 Block，
   顶层收不到。于是「页面只有 261 字」，我一度以为应用没跳过去。
③ 我以为「直接翻开「X」」会直接翻牌 —— 它进的是**对话**，
   要用户先说两句才发牌。**我没读 `deal_turn` 就来写断言。**
这一版（第四版）不再驱动界面，直接测渲染函数的输出，
但**用真实数据**（走 `_majors_src_loader`，它刚验过和产品逐字段一致）。
"""
import io

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(
    _os.path.abspath(__file__))))
sys.path.insert(0, ROOT)
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")

import _majors_src_loader as L                                   # noqa: E402

NS = L.load(need=("MAJORS", "OCC", "OCC_ALIAS", "NOT_JOBS",
                  "OCC_NODETAIL", "render_card"))
M = NS["MAJORS"]
OCC = NS["OCC"]
ALIAS = NS["OCC_ALIAS"]
NOT_JOBS = NS["NOT_JOBS"]
NODETAIL = NS["OCC_NODETAIL"]
render_card = NS["render_card"]

_mc = {}
exec(compile(open(f"{ROOT}\\_mirror_core.py", encoding="utf-8").read(),
             "_mirror_core.py", "exec"), _mc)
DIM_NAMES = _mc["DIM_NAMES"]
DIM_PLAIN = _mc["DIM_PLAIN"]

bad = []


def chk(c, m):
    print(f"  {'✓' if c else '✗'} {m}")
    if not c:
        bad.append(m)


class FakeSt:
    """只实现 `_cards_core.render_card` 会用到的那几个方法。"""

    def __init__(self):
        self.parts = []

    def markdown(self, body, **kw):
        self.parts.append(str(body))

    def caption(self, body, **kw):
        self.parts.append(str(body))

    def warning(self, body, **kw):
        self.parts.append(str(body))

    def columns(self, n, **kw):
        class _C:
            def __enter__(s):
                return s

            def __exit__(s, *a):
                return False
        return [_C() for _ in range(n if isinstance(n, int) else len(n))]

    def text(self):
        return "\n".join(self.parts)


def render(name):
    mm = next((x for x in M if x.get("n") == name), None)
    if mm is None:
        return None, f"库里没有「{name}」"
    st = FakeSt()
    try:
        render_card(st, mm, DIM_NAMES, DIM_PLAIN,
                    occ_by_name=NS.get("OCC_BY_NAME"),
                    occ_alias=ALIAS, not_jobs=NOT_JOBS,
                    occ_nodetail=NODETAIL, occ_by_id=OCC)
    except Exception as e:                                       # noqa: BLE001
        return None, f"渲染抛异常：{type(e).__name__}: {e}"
    return st.text(), None


# ── 挑样本：平台登记了、但没做详情页的那些 ──
# 【我第一版这里挑到 0 个，原因值得记下来】
# 我写的条件是 `j not in ALIAS`，而 ALIAS 是**非空 dict**——
# `j not in ALIAS` 在 j 不是键时为 True，逻辑本身没错；
# 但我同时用 `if _wide and ...` 把 n_majors 当成必要条件，
# 而 `OCC_NODETAIL` 的值是**专业名列表**、长度要用 `len()`。
# 写复杂条件去筛样本，是**先猜哪条路走得到**；
# `_审计/_probe_exit_samples.py` 直接把数据摆出来（159 处），
# 一眼就看到「建筑学 → 项目专员/助理（46 个专业）」。
# 所以这里改成最简单的写法：**只按 NID 筛**。
cands = []
for m in M:
    for j in (m.get("chsi_jyfx") or []):
        if j in NOT_JOBS:
            continue
        if j in NODETAIL:
            cands.append((m["n"], j, len(NODETAIL[j])))
            break
print(f"  找到 {len(cands)} 个「登记了但没详情页」的样本，前 4 个：")
for _c in cands[:4]:
    print(f"     {_c[0]:<16} → {_c[1]}（{_c[2]} 个专业）")

print()
print("=" * 74)
print("① 翻开一张，看它印的出口说明")
print("=" * 74)
chk(bool(cands), "有可测的样本（不然这个闸门是空转的）")
if cands:
    TARGET, JOB, WIDE = cands[0]
    blob, err = render(TARGET)
    chk(not err, f"「{TARGET}」渲染得出来（{err}）")
    if blob:
        print(f"     「{TARGET}」的卡收了 {len(blob)} 字")
        chk(JOB in blob, f"出口名单里有「{JOB}」")
        chk("还没做详情页" in blob,
            "说明是「平台登记了、还没做详情页」——不是「查不到」")
        chk(f"{WIDE} 个专业都能走到这" in blob,
            f"说出了平台登记的那个数字（{WIDE} 个专业通向它）")
        chk("通用出口" in blob, "提醒这是通用出口，不是特征出口")
        chk("没有独立页" not in blob, "不再印旧那句「没有独立页」")

    print()
    print("=" * 74)
    print("② 全部样本过一遍：每个出口都必须带上它那一条说明")
    print("=" * 74)
    # 【我前两版这里都是错的，错法值得记下来】
    # 第一版：挑 4 张牌，逐张断言「必须含『还没做详情页』」——
    #   58/129 红。但产品是对的：那个名字在职业库里有详情
    #   （只是平台叫法和族名不同），走的是另一条支路。
    #   **拿一条只对某个分支成立的字串当所有分支的门。**
    # 第二版：改成在**整张卡的文字**里 `find(职业名)`，
    #   再断言后面 400 字里有「还没做详情页」。又红了 34 张。
    #   原因：那个名字在**别处**也出现过（它同时是另一个职业的别名），
    #   `find` 找到的是**前一处**。**在一个长文本里按名字定位一小段，
    #   名字重复时就会定位错——这不是断言问题，是方法本身不可靠。**
    #
    # 第三版（就是这一版）：不再从渲染出来的长文本里抠字，
    #   直接查**结构化数据**——`exits_rows` 返回的就是每条出口的
    #   `{name, kind, detail, note}`。要验什么一目了然。
    from _cards_core_data import exits_of                       # noqa: E402
    _bad_note, _bad_kind, _bad_width = [], [], []
    _n_checked, _n_with_note = 0, 0
    for nm, job, wide in cands:
        mm = next((x for x in M if x["n"] == nm), None)
        if mm is None:
            continue
        _n_checked += 1
        for e in exits_of(mm, NS, DIM_NAMES, DIM_PLAIN):
            if e["name"] in NOT_JOBS:
                continue
            if not (e.get("note") or "").strip():
                _bad_note.append((nm, e["name"]))
                continue
            _n_with_note += 1
            # 【分类要和产品同序判，不能各判各的】
            # 我上一版先查「这个名字在不在 OCC_NODETAIL 里」，
            # 于是 123 条红。真因：**一个名字可以两边都在**——
            # 它在 NODETAIL 里，但通过别名又能解析到详情记录。
            # 产品是**先试解析、解析到了就说宽窄**（对的），
            # 我却按「在 NODETAIL 里」判它错了。
            # 所以这里照产品的优先顺序判：先解析，解析不到再看 NODETAIL。
            _o = OCC.get(ALIAS.get(e["name"]) or "")
            _n_maj = _o.get("n_majors") if _o else None
            if _o is not None:
                if isinstance(_n_maj, int) and _n_maj <= 5:
                    # 【≤5 的时候产品说的是「特征出口」，不印数字】
                    # 我第二版要求必须印数字，又是我的断言错。
                    if "特征出口" not in e["note"]:
                        _bad_width.append((nm, e["name"], _n_maj))
                elif isinstance(_n_maj, int):
                    if f"{_n_maj} 个专业" not in e["note"]:
                        _bad_width.append((nm, e["name"], _n_maj))
            elif e["name"] in NODETAIL:
                if "还没做详情页" not in e["note"]:
                    _bad_kind.append((nm, e["name"]))
    print(f"     过了 {_n_checked} 张牌，{_n_with_note} 条出口带说明")
    for _lbl, _lst in (("没说明的", _bad_note), ("分类不对的", _bad_kind),
                       ("宽窄不对的", _bad_width)):
        if _lst[:5]:
            print(f"     {_lbl}：{_lst[:5]}")
    chk(not _bad_note, f"没有一条出口光印名字（{len(_bad_note)} 条）")
    chk(not _bad_kind,
        f"「登记了没详情页」的都说了那句（{len(_bad_kind)} 条不对）")
    chk(not _bad_width, f"宽窄都说清了（{len(_bad_width)} 条不对）")

print()
print("=" * 74)
print("③ 一个都点不开的那批，走的还是原来那条早退分支")
print("=" * 74)
_early = None
for m in M:
    # 【要照 `_career_items` 的真实规则挑，不能只看 car】
    # 我第一版写的是「car 里没有一个能点开」就当早退样本，
    # 结果挑中「建筑学」——它**有官方数据**，`_career_items` 会走官方那条。
    # 真规则是：官方优先，官方没有才用 car；只有**结果**一个都点不开
    # 且来源是「整理」时才早退。
    jf = m.get("chsi_jyfx") or []
    car = m.get("car") or []
    items = jf if jf else car
    how = "官方" if jf else ("整理" if car else "无")
    jobs = [j for j in items if j not in NOT_JOBS]
    if how == "整理" and jobs and not any(j in ALIAS for j in jobs):
        _early = m["n"]
        break
if _early:
    bl, e3 = render(_early)
    if e3:
        chk(False, f"「{_early}」渲染不出来：{e3}")
    else:
        # 【判据必须和产品的真实规则一致，不能比它严】
        # 产品在 `exits_rows` 里对「解析不到、也不在 NODETAIL」的名字
        # 说的是：**可能是名字口径不同，也可能它确实还没被收录。
        # 我手上没有它的详情，所以不给你一个点不动的链接。**
        # 我第一版找的是「能给的只有线索 / 查不到这个专业」——
        # 那是牌局**更早一版**的说法，我拿旧字串当了门。
        _ok = ("可能它确实还没被收录" in bl
               or "没能和官方职业库对上" in bl
               or "能给的只有线索" in bl
               or "查不到这个专业" in bl)
        chk(_ok, f"「{_early}」走的是「官方还没收录」那条说明")
        chk("没有独立页" not in bl, "也没印旧那句")
else:
    chk(True, "没有「一个都点不开」的专业，跳过")

print()
if bad:
    print(f"  ✗ {len(bad)} 项不过：")
    for b in bad:
        print(f"     {b}")
    sys.exit(1)
print("  ✓ 出口那一行：点不开的说得清、数字给得出、旧话没回来")
