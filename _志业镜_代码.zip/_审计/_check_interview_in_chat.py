# -*- coding: utf-8 -*-
"""访谈在对话版里走不走得通——**一通到底，七题走完**。

【为什么必须真走一遍，而不是只测 `_interview_core` 的函数】
真正会出问题的是**接线**：侧栏按钮有没有设对 session_state、
每答一题会不会推进、走完会不会出结果、出结果时 `interview_run`
拿到的 ctx 里有没有 `majors`。
这些都不是纯函数的属性，只有把 AppTest 点一遍才知道。
"""
import io

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(
    _os.path.abspath(__file__))))
sys.path.insert(0, ROOT)
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")
from streamlit.testing.v1 import AppTest                        # noqa: E402

APP = os.path.join(ROOT, "志业镜.py")
bad = []


def chk(c, m):
    print(f"  {'✓' if c else '✗'} {m}")
    if not c:
        bad.append(m)


def texts(at):
    seen, out = set(), []
    for kind in ("markdown", "caption", "warning", "error", "info",
                 "success", "text", "subheader", "header"):
        try:
            els = getattr(at, kind)
        except Exception:
            continue
        for e in (els or []):
            if id(e) in seen:
                continue
            seen.add(id(e))
            v = getattr(e, "value", None)
            if isinstance(v, str) and v.strip():
                out.append(v)
    return out


print("=" * 74)
print("  ① 侧栏入口：点得动，点了进访谈")
print("=" * 74)
at = AppTest.from_file(APP, default_timeout=300)
at.run()
_btns = [getattr(b, "label", "") for b in (at.button or [])]
print(f"     侧栏按钮：{_btns}")
_enter = next((b for b in at.button if "换我问你" in (b.label or "")), None)
chk(_enter is not None, "有「换我问你几个问题」入口")
if _enter is None:
    print("  （入口都没有，后面没法测）")
    sys.exit(1)
_enter.set_value(True)
at.run()
_t = "\n".join(texts(at))
chk("换我问你" in _t, "进了访谈界面")
chk("没试过" in _t or "说不好" in _t or "最像你" in _t,
    "出了第一题和选项")
# 第一题有没有出来
_radios = [r for r in (at.radio or [])]
chk(bool(_radios), f"有选项控件（{len(_radios)} 个）")
if _radios:
    print(f"     第一题的选项：{list(_radios[0].options)[:4]}")

print()
print("=" * 74)
print("  ② 七题走完：每题都能推进，最后出结果")
print("=" * 74)
_n = 0
for step in range(14):
    _r = [r for r in (at.radio or []) if r.key and r.key.startswith("iv_pick_")]
    if not _r:
        break
    _opts = list(_r[0].options)
    # 【每题都换着选，不要每题都选第一档】
    # 全选第一档会让七维都落在同一档上，那样测不出「不同档位不一样」。
    _idx = _n % len(_opts)
    at.session_state[f"iv_pick_{_n}"] = _opts[_idx]
    at.run()
    _n += 1
print(f"     推进了 {_n} 题")
chk(_n == 7, f"七题都推进了（实际 {_n}）")

_t2 = "\n".join(texts(at))
_exc = list(at.exception) if at.exception is not None else []
chk(not _exc, f"走完之后无异常（{len(_exc)} 条）")
for x in _exc[:3]:
    print(f"     ✗ {str(getattr(x, 'value', x))[:200]}")
chk("答完了，对一遍" in _t2, "出结果了")
# 【结果页必须带上那几条立场】
for w in ("这不是「适合你」", "受得了不等于愿意干", "没有校准",
          "一个字都没问你家里"):
    chk(w in _t2, f"结果页有「{w}」")

print()
print("=" * 74)
print("  ③ 走完能回到聊天")
print("=" * 74)
_back = next((b for b in (at.button or []) if "聊点别的" in (b.label or "")),
             None)
chk(_back is not None, "有「聊点别的」出口")
if _back is not None:
    _back.set_value(True)
    at.run()
    _t3 = "\n".join(texts(at))
    chk("换我问你" not in _t3 or "不用想清楚才来" in _t3,
        "回到了聊天（开场白又在了）")

print()
if bad:
    print(f"  ✗ {len(bad)} 项不过：")
    for b in bad:
        print(f"     {b}")
    sys.exit(1)
print("  ✓ 访谈：侧栏进得去、七题推得动、结果带立场、出得来")
