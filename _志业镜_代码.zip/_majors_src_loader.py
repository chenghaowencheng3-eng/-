# -*- coding: utf-8 -*-
"""把牌局那份源当成模块跑起来——**用组装器拼好的那一份，不自建一套**。

【我第一版自己拼，错了】
第一版我在这个文件里重写「读哪几个 JSON、怎么拼 CATALOG、
怎么内联共享核心」，结果第一步就崩：`_catalog_index.json` 不存在。
原因很清楚——**CATALOG 不是文件，是组装器从
`_official_2026_tree.json` 算出来的 883 条目录。**

那一刻我意识到：我在把 `_assemble_majors.py` 的拼装逻辑
再抄一份。这个仓库最大的教训就是这件事：
**两处各留一份、靠人记得同步，迟早对不上。**
（出处行那次：161 个专业里两边只有 4 个对得上。）

【所以改成复用】
`_assemble_majors.py` 现在不落盘应用了，但它**会把拼好的那一份
写到 `_专业游乐场.build-check.py`**——那正是「源 + 真实数据」。
本模块就用它。

于是现在的因果链是干净的：
    `_assemble_majors.py`（唯一一份拼装逻辑）
        → `_专业游乐场.build-check.py`（它的产物）
        → 本模块（把它当模块跑）
        → 那些测数据的闸门
改数据或改占位符，只需要动组装器一处。

用法：
    import _majors_src_loader as L
    NS = L.load(need=("resolve_major", "CAT_MAJOR"))
"""
import os
import subprocess

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
ROOT = os.path.dirname(os.path.abspath(__file__))
BUILT = os.path.join(ROOT, "_专业游乐场.build-check.py")
ASSEMBLER = os.path.join(ROOT, "_assemble_majors.py")


def ensure_built(force=False):
    """确保拼好的那一份是最新的。**旧的那份比没有更糟。**

    【为什么必须重新拼，不能「有就用」】
    如果我用一份三天前的产物去测数据，测出来的结论
    和产品当下的状态毫无关系——**而且它看起来是绿的。**
    所以只要组装器或它的输入比产物新，就重拼。
    """
    if not force and os.path.exists(BUILT):
        t_out = os.path.getmtime(BUILT)
        inputs = [ASSEMBLER, os.path.join(ROOT, "_majors_src.py"),
                  os.path.join(ROOT, "_mirror_core.py"),
                  os.path.join(ROOT, "_theme_core.py")]
        inputs += [os.path.join(ROOT, f) for f in os.listdir(ROOT)
                   if f.endswith(".json")]
        if all(os.path.getmtime(p) <= t_out for p in inputs
               if os.path.exists(p)):
            return BUILT
    # 重拼。用当前解释器跑组装器，捕获输出以便出错时能看见原因。
    r = subprocess.run([sys.executable, ASSEMBLER], cwd=ROOT,
                       capture_output=True, text=True, encoding="utf-8",
                       errors="replace")
    if r.returncode != 0 or not os.path.exists(BUILT):
        raise RuntimeError(
            "拼装 `_majors_src.py` 失败，没法继续测。\n"
            f"  exit={r.returncode}\n"
            f"  stdout={r.stdout[-800:]}\n"
            f"  stderr={r.stderr[-800:]}")
    return BUILT


def load(need=(), force=False):
    """执行拼好的那一份，返回它的命名空间。

    【为什么切掉界面】
    它后半段是真的 streamlit 界面（要 `streamlit run` 才有上下文）。
    这里只取模块级的数据和函数，所以从 `st.set_page_config` 处切断。
    **用锚点，不数行号。**
    """
    path = ensure_built(force=force)
    s = open(path, encoding="utf-8").read()
    cut = s.find("st.set_page_config")
    if cut < 0:
        raise RuntimeError(
            "在拼好的那份里找不到界面起点（st.set_page_config）。"
            "锚点变了——别硬猜行号，去 `_majors_src.py` 里核一下。")
    cut = s.rfind("\n", 0, cut) + 1

    # 【`__file__` 也要给】
    # 拼好的那份里有 `os.path.dirname(os.path.abspath(__file__))`
    # （开场白记号文件用的）。exec 的命名空间默认没有 `__file__`，
    # 会当场 NameError：`name '__file__' is not defined`。
    # 真实模块里这个是解释器给的，所以这里得自己补——
    # 而且要给**真实路径**，不然记号文件会写到别处去。
    NS = {"__name__": "majors_src", "__file__": path}
    exec(compile(s[:cut], path, "exec"), NS)         # noqa: S102

    # 【把共享的卡片/访谈模块也放进来】
    # 产品里跑的那张卡**不是** `_majors_src.py` 里的 `card()`，
    # 而是共享的 `_cards_core.render_card()`（对话版展开区调的就是它）。
    # 测「出口那一行印了什么」必须测真正在跑的那个。
    # 这两个模块是故意独立的（`_check_shared_standalone` 盯着），
    # 所以直接在干净命名空间里执行即可。
    shared = {**NS}
    for f in ("_cards_core.py", "_interview_core.py"):
        p = os.path.join(ROOT, f)
        if not os.path.exists(p):
            continue
        code = open(p, encoding="utf-8").read()
        exec(compile(code, f, "exec"), shared)       # noqa: S102
    # 数据类的名字（MAJORS/OCC/...）以拼好的那份为准，共享模块不覆盖它们
    for k, v in NS.items():
        shared.setdefault(k, v)

    missing = [n for n in need if n not in shared]
    if missing:
        raise RuntimeError(
            f"拼好的那份里没有这些名字：{missing}。"
            f"（名字改了，或者它定义在被切掉的那段里）")
    return shared
