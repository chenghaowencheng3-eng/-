# -*- coding: utf-8 -*-
"""卡片的渲染。**牌局和对话共用这一份，卡片上长什么样只由这里决定。**

【为什么要抽出来，而不是各写一份】
原来牌局的卡片渲染写在 `_majors_src.py` 里（约 900 行：七维、代价、
出口、来源那一长串），对话版另有一个简陋的 `card_html()` 只画名字和门类。
用户最后只要**一个应用**，而且那个应用里也要能翻牌——
如果两边各留一份，卡片上的数字迟早会对不上。
这个仓库里已经因为「两份靠检查同步」栽过好几次：
出处行 161 个专业里只对上 4 个那次，就是这么来的。

【这一份不依赖任何外部全局名】
所有外部名字**从参数传进来**，不靠「运行时恰好有那个变量」。
`_tools_core.py` 就是反面教材：它单独跑会 NameError，
因为它引用了 `_mirror_core.py` 里的 `ASK`/`OPTIONS`——
只有靠组装时把它们内联进去才能跑。**那种代码没法单独测。**

【交付契约】
它只碰 `st` 的这几个方法：`markdown` / `caption` / `warning`，
以及 `st.columns`。不会 rerun、不读 session_state、不发请求。
所以它可以在任何一个 streamlit 页面里直接用。
"""
import html as _html


def _esc(s):
    """把用户/数据里的字放进 HTML 之前转义。

    【为什么必须转义】专业名、出口名里可能出现 `<`、`&`。
    不转义的话，一个带尖括号的名字就能把卡片布局撑坏，
    而且**这是我们自己发出去的 unsafe_allow_html**，等于自己开的口子。
    """
    return _html.escape(str(s), quote=False)


# ------------------------------------------------------------------
# 小工具：把一个「维度名 → 分数」的画成一行
# ------------------------------------------------------------------
def dims_row(m, dim_names, dim_plain, weight=None):
    """七维画像那一行。**没有画像就返回 None，不假装有。**

    返回值是 (markdown 文本, 有几维是 5) 或 None。
    """
    d = m.get("dims")
    if not d or len(d) != len(dim_names):
        return None
    bits = []
    for i, name in enumerate(dim_names):
        v = d[i]
        if v is None:
            bits.append(f"{name} `?`")
        else:
            bits.append(f"{name} `{v}`")
    n5 = sum(1 for v in d if v == 5)
    tier = m.get("dims_tier") or ""
    head = f"**七维需求画像**（每一项都是「这个专业对人要求多高」）"
    if tier:
        head += f"　<span class='dim'>等级 {_esc(tier)}</span>"
    return head + "\n\n" + "　".join(bits), n5


def cost_row(m, dim_names):
    """代价那一行。**模板值必须标出来**，不能当准数。

    返回 (markdown 文本, 是不是模板值) 或 None。
    """
    if not m.get("cost_hours"):
        return None
    tpl = bool(m.get("cost_templated"))
    bits = [f"每周投入约 **{m['cost_hours']}** 小时"]
    if m.get("cost_years"):
        bits.append(f"读到能上手约 **{m['cost_years']}** 年")
    if m.get("cost_feedback_months"):
        bits.append(f"看到反馈约 **{m['cost_feedback_months']}** 个月")
    if "cost_reversible" in m and m["cost_reversible"] is not None:
        bits.append("这条路**可逆**" if m["cost_reversible"]
                    else "这条路**不太好回头**")
    body = "　·　".join(bits)
    tier = m.get("cost_tier") or ""
    tag = ""
    if tpl:
        # 【这一句必须留】88 个专业是模板值。不标出来就是拿估计冒充准数。
        tag = ("　<span class='dim'>⚠ 这几个数是**模板值**——"
               "按这个专业类的常见情况填的，不是实测</span>")
    elif tier:
        tag = f"　<span class='dim'>等级 {_esc(tier)}</span>"
    return f"**要花多少**\n\n{body}{tag}", tpl


def avoid_items(m, limit=None):
    """什么情况会让你想跑。**是排除理由的原料，不是缺点清单。**"""
    av = m.get("avoid")
    if not av:
        return []
    out = []
    for pair in av:
        if not isinstance(pair, (list, tuple)) or len(pair) < 2:
            continue
        out.append((str(pair[0]), str(pair[1])))
    return out[:limit] if limit else out


IR_NAMES = ["要担责", "手艺", "关系", "判断"]


def exits_rows(m, occ_by_name=None, occ_alias=None, not_jobs=None,
               occ_nodetail=None, occ_by_id=None):
    """出口那一行：**每个名字都要说清它是哪一种**。

    【这一块是从牌局搬过来的，为什么要搬】
    合并成一个应用之后，`_cards_core` 的出口只写了个名字。
    但名字长得一样、含金量差得远，有三种情况：
      ① 平台做了详情页     → 能点开，有学历要求、薪资满意度
      ② 平台登记了、没做详情页 → **点不开，但这是官方信息**，
                              而且平台自己登记了「N 个专业都能走到这」
      ③ 连平台都没登记     → 我手上没有详情，**所以不给一个点不动的链接**

    【原来把 ② 和 ③ 都印成「没有独立页」，错在哪】
    它把 ① 里最有用的那句「N 个专业通向它」丢掉了——
    那是**平台自己登记的数字**，不是我的推测。
    而且它把一条官方信息（②）降级成了缺口（③）。
    这个仓库的立场是「数据以官方源为准并逐条标注出处」，
    把官方登记过的东西说成「没有」，正好反着来。

    【为什么宽带要说出来】
    「公务员」有 117 个专业通向它。它在某一张牌下面出现，
    不代表这张牌通向公务员——**不代表它不出现，也不代表它是特征出口**。
    不说宽窄，用户会把通用出口当成「这个专业的方向」。
    """
    occ_by_name = occ_by_name or {}
    occ_alias = occ_alias or {}
    not_jobs = not_jobs or set()
    occ_nodetail = occ_nodetail or {}
    # 【两种查法都要支持，因为两个应用手里的东西不一样】
    #   对话版：`OCC_BY_NAME`（名字→记录）+ `OCC_ALIAS`（名字→id）
    #   牌局：  `OCC`（id→记录）+ `OCC_ALIAS`（名字→id）
    # 合并之前这一段长在牌局里，只认第二种。
    # 搬进共享模块时如果只认一种，另一个应用就会**静默查不到**——
    # 而静默查不到的表现是「出口那一行少了说明」，
    # 看起来像数据缺失，不像代码错。所以两条路都留着。
    _by_id = {}
    for _k, _r in occ_by_name.items():
        _id = _r.get("id") if isinstance(_r, dict) else None
        if _id:
            _by_id[_id] = _r
        elif isinstance(_r, dict):
            _by_id.setdefault(_k, _r)
    for _k, _r in (occ_by_id or {}).items():
        _by_id.setdefault(_k, _r)

    own_name = m.get("n")
    out = []
    seen = set()
    for nm in list(m.get("chsi_jyfx") or []) + list(m.get("car") or []):
        nm = str(nm or "").strip()
        if not nm or nm in seen:
            continue
        seen.add(nm)
        official = nm in (m.get("chsi_jyfx") or [])
        # 【「不是职业，是去向」的东西单列】比如「考研」「公务员」
        if nm in not_jobs:
            out.append({"name": nm, "kind": "direction",
                        "note": "**这不是职业，是去向**，所以单列。"})
            continue
        rec = occ_by_name.get(nm)
        if rec is None and occ_alias:
            # 【方向别搞反】`occ_alias` 是 **名字 → 职业 id**，不是 id → 名字。
            # 我第一版写成 `occ_by_name.get(occ_alias.get(nm))`，
            # 那是拿 id 去当名字查——**永远查不到，而且静默**。
            # 牌局那边是 `OCC.get(OCC_ALIAS.get(name))`，这里要等价。
            _oid = occ_alias.get(nm)
            rec = _by_id.get(_oid) if _oid else None
        if rec:
            n_maj = rec.get("n_majors")
            if isinstance(n_maj, int):
                if n_maj <= 5:
                    width = "**这是这个专业的特征出口**"
                elif n_maj >= 20:
                    width = f"{n_maj} 个专业都能走到这"
                else:
                    width = f"{n_maj} 个专业通向它"
            else:
                width = ""
            _prim = (rec.get("primary") or "").strip()
            note = f"（{width}）" if width else ""
            if _prim and _prim != nm:
                # 【族名和平台说法不一致时必须说】职业库是按**族**登记的。
                # 注意这里不再套一层 `<span class='dim'>`——
                # 调用方已经把整条 note 放进了 dim 标记里，
                # 再嵌一层会出现 `<span><span>` 的嵌套（实测印出来就是那样）。
                note += (f"　学职平台给这个专业登记的说法是「{nm}」，"
                         f"职业库把它归进「{_prim}」这一族")
            out.append({"name": nm, "kind": "official" if official
                        else "curated", "note": note, "detail": True})
            continue
        # ── 查不到详情：还要再分两种 ──
        _ma = occ_nodetail.get(nm) or []
        if _ma:
            _also = "，**你是其中之一**" if own_name in _ma else ""
            out.append({
                "name": nm, "kind": "official" if official else "curated",
                "detail": False,
                "note": (f"学职平台登记了这个职业，但还没做详情页。"
                         f"**{len(_ma)} 个专业都能走到这**{_also}——"
                         f"所以这是一条通用出口，不是这个专业的特征出口")})
        else:
            out.append({
                "name": nm, "kind": "official" if official else "curated",
                "detail": False,
                "note": ("这个方向没能和官方职业库对上——"
                         "**可能是名字口径不同，也可能它确实还没被收录。"
                         "我手上没有它的详情，所以不给你一个点不动的链接。**")})
    return out


def ai_row(m):
    """AI 面前的位置：不可替代四维 + 是增强还是压缩。

    返回 (markdown 文本, ) 或 None。
    """
    ir = m.get("ir")
    tilt = m.get("tilt")
    if not ir and tilt is None:
        return None
    bits = []
    if isinstance(ir, list) and len(ir) >= 4:
        for i, name in enumerate(IR_NAMES):
            bits.append(f"{name} `{ir[i]}`")
    if tilt is not None:
        if tilt < 0:
            _t = f"AI 更可能**压缩**这个方向（{tilt}）"
        elif tilt > 0:
            _t = f"AI 更可能**增强**这个方向（+{tilt}）"
        else:
            _t = "AI 对它的影响偏中性（0）"
        bits.append(_t)
    if not bits:
        return None
    return "**这个方向在 AI 面前的位置**\n\n" + "　".join(bits)


def card_data(m, dim_names, dim_plain, occ_by_name=None, occ_alias=None,
              not_jobs=None, occ_nodetail=None, occ_by_id=None):
    """把一张牌整理成**好渲染、也好核对**的结构。

    【为什么先整理成数据、再交给渲染】
    这样「卡片上该有什么」和「怎么画出来」是两件事：
    数据这一层可以直接断言（比如「模板值必须带标记」），
    不用去 AppTest 里翻 HTML。
    """
    occ_by_name = occ_by_name or {}
    occ_alias = occ_alias or {}
    not_jobs = not_jobs or set()

    d = {
        "name": m.get("n") or m.get("_name") or "",
        "gate": m.get("gate") or "",
        "gate_icon": m.get("gate_icon") or "",
        "cls": m.get("专业类") or "",
        "code": m.get("code") or "",
        "degree": m.get("degree") or m.get("学位") or "",
        "years": m.get("years") or m.get("学制"),
        "in_official": bool(m.get("in_official")),
        "hook": m.get("hook") or "",
        "sections": [],
    }

    # ① 七维画像
    r = dims_row(m, dim_names, dim_plain)
    if r:
        d["sections"].append(("dims", {"text": r[0], "n5": r[1]}))

    # ② 代价
    r = cost_row(m, dim_names)
    if r:
        d["sections"].append(("cost", {"text": r[0], "templated": r[1]}))

    # ③ 会让你想跑的情况（**排除理由的原料**）
    av = avoid_items(m)
    if av:
        d["sections"].append(("avoid", {"items": av}))

    # ④ AI 面前的位置
    r = ai_row(m)
    if r:
        d["sections"].append(("ai", {"text": r}))

    # ⑤ 出口：官方登记的 + 官方没登记的，分开。
    # **而且每个名字都要说清它是哪一种**（见 `exits_rows` 的注释）。
    exits = exits_rows(m, occ_by_name, occ_alias, not_jobs, occ_nodetail,
                       occ_by_id)
    if exits:
        d["sections"].append(("exits", {"items": exits}))

    # ⑥ 在校生规模 / 满意度（**学生自评，不是就业率**）
    sat = m.get("chsi_sat")
    if sat or m.get("chsi_xsgm"):
        row = {}
        if m.get("chsi_xsgm"):
            row["规模"] = f"在校生 {m['chsi_xsgm']} 人"
        if isinstance(sat, dict):
            dd = sat.get("dims") or {}
            for _k, v in list(dd.items())[:1]:
                if isinstance(v, dict) and v.get("rank") is not None:
                    row["综合满意度"] = (
                        f"{v['rank']} 分"
                        + (f"（{v['count']} 人投票）" if v.get("count")
                           else "（**没有票数**）"))
        if row:
            d["sections"].append(("chsi", {"row": row}))

    return d


def summary_data(m, dim_names, dim_plain):
    """**聊天流里用的紧凑视图。**

    【为什么不直接把 `card_data` 那六个块全画进聊天】
    聊天是往下滚的。一张牌塞六个块、四百多字，滚两屏就找不着刚才说的是
    哪一句了——这正是用户最早要的「就像在和你说话，纸牌是穿插的操作」：
    **纸牌是穿插的，不是把聊天变成读报告。**

    【但它必须补上原来缺的那两件】
    原来的简版卡 `card_html()` **完全不显示代价**——而代价是这个产品
    最值钱的信息之一（这条路要花多久、好不好回头）。
    它也不标「模板值」，那等于**拿估计冒充准数**。
    所以紧凑视图也带这两样，只是压成一行。
    """
    out = {
        "name": m.get("n") or m.get("_name") or "",
        "icon": m.get("gate_icon") or "",
        "gate": m.get("gate") or "",
        "cls": m.get("专业类") or "",
        "degree": m.get("degree") or m.get("学位") or "",
        "years": m.get("years") or m.get("学制"),
        "hook": m.get("hook") or "",
        "core": m.get("core_s") or "",
        "weary": m.get("weary") or "",
        "dims_hi": [],
        "dims_lo": [],
        "cost": "",
        "cost_templated": False,
        "cost_tier": "",
        "has_dims": bool(m.get("dims")),
        "exits": [],
        "act": m.get("act_s") or "",
        "suits": m.get("suits") or "",
    }
    d = m.get("dims")
    if d and len(d) == len(dim_names):
        hi = sorted(range(len(d)), key=lambda i: -d[i])[:2]
        lo = [i for i in sorted(range(len(d)), key=lambda i: d[i])
              if d[i] <= 3][:2]
        out["dims_hi"] = [(dim_names[i],
                           dim_plain.get(dim_names[i], dim_names[i]), d[i])
                          for i in hi]
        out["dims_lo"] = [(dim_names[i],
                           dim_plain.get(dim_names[i], dim_names[i]), d[i])
                          for i in lo]
    if m.get("cost_hours"):
        bits = [f"每周约 **{m['cost_hours']}** 小时"]
        if m.get("cost_years"):
            bits.append(f"上手约 **{m['cost_years']}** 年")
        if "cost_reversible" in m and m["cost_reversible"] is not None:
            bits.append("**可回头**" if m["cost_reversible"]
                        else "**不太好回头**")
        out["cost"] = "　·　".join(bits)
        # 【这两行是这次改动里最要紧的】
        # 88 个专业的代价是模板值，不标出来就是拿估计冒充准数；
        # 反过来那 6 条 C1 是核实过的，也不该被说成模板值。
        out["cost_templated"] = bool(m.get("cost_templated"))
        out["cost_tier"] = m.get("cost_tier") or ""
    out["exits"] = list((m.get("chsi_jyfx") or []))[:5]
    return out


def render_card(st, m, dim_names, dim_plain, occ_by_name=None,
                occ_alias=None, not_jobs=None, occ_nodetail=None,
                occ_by_id=None, sources=None):
    """把一张牌画进当前 streamlit 页面。

    `sources` 是已经算好的出处行（由调用方给，因为出处的算法两个应用共用
    `_tools_core.py` 那一份，这里不重写）。
    """
    d = card_data(m, dim_names, dim_plain, occ_by_name, occ_alias, not_jobs,
                  occ_nodetail, occ_by_id)
    _title = f"{d['gate_icon']} {d['name']}".strip()
    st.markdown(f"### {_esc(_title)}")
    _sub = []
    if d["gate"]:
        _sub.append(d["gate"])
    if d["cls"]:
        _sub.append(d["cls"])
    if d["code"]:
        _sub.append(f"代码 {d['code']}")
    if d["degree"]:
        _sub.append(d["degree"])
    if d["years"]:
        _sub.append(f"{d['years']} 年")
    if _sub:
        st.caption("　·　".join(_esc(x) for x in _sub))
    if d["hook"]:
        st.markdown(f"*{_esc(d['hook'])}*")

    for kind, body in d["sections"]:
        # 【这里必须是显式分派，不能有 `else: 当成 text 画`】
        # 我第一版就是那么写的，结果 avoid 块（body 是 {"items": [...]}）
        # 走到兜底分支，直接 KeyError: 'text'。
        # 更要命的是：**如果某个块恰好有个 text 键，这个兜底会静默画错**。
        # 所以未知块一律抛出来，让它在我测试时就炸，而不是在用户面前画歪。
        if kind == "exits":
            _off = [e for e in body["items"] if e["kind"] == "official"]
            _cur = [e for e in body["items"] if e["kind"] == "curated"]
            _dir = [e for e in body["items"] if e["kind"] == "direction"]
            st.markdown("**学完大多去干什么**")

            def _draw(group, official):
                for e in group:
                    _n = _esc(e["name"])
                    _t = f"`{_n}`" if official else _n
                    _note = e.get("note") or ""
                    if _note:
                        st.markdown(f"- {_t}　<span class='dim'>{_note}"
                                    f"</span>", unsafe_allow_html=True)
                    else:
                        st.markdown(f"- {_t}")
            if _off:
                _draw(_off, True)
                st.caption("上面这些是**学职平台登记的**方向。"
                           "**每一条后面都写着它有多宽**——"
                           "写着「117 个专业都能走到这」的，"
                           "不是这个专业的特征出口。")
            if _cur:
                _draw(_cur, False)
                st.caption("这一组是**整理过的**，不是官方登记。")
            if _dir:
                _draw(_dir, False)
        elif kind == "chsi":
            for k, v in body["row"].items():
                st.markdown(f"- {k}　{v}")
        elif kind == "avoid":
            st.markdown("**什么情况会让你想跑**")
            for a, b in body["items"]:
                st.markdown(f"- **{_esc(a)}**　<span class='dim'>"
                            f"{_esc(b)}</span>", unsafe_allow_html=True)
            st.caption("这几条说的是「这个专业的日常里有这些事」，"
                       "**不是「这个专业不好」**。你先看看自己受不受得了。")
        elif kind in ("dims", "cost", "ai"):
            st.markdown(body["text"])
        else:
            raise KeyError(f"_cards_core 不认识这个块：{kind!r}（"
                           f"加块的时候忘了写渲染，别让它静默画歪）")

    if sources:
        st.markdown("**这些数字分别是从哪来的**")
        for row in sources:
            st.markdown(f"- {row}")

    if not d["sections"]:
        st.caption("**这张牌我还没做出内容。**手上只有目录里那一行。")
    return d
