# -*- coding: utf-8 -*-
"""装配 志业镜.py —— 把数据、镜像核心、工具层、提示词拼进界面模板。

【为什么用拼接而不是字符串注入】
上一版我打算把内联代码塞进 `r\"\"\"...\"\"\"` 再 exec。这有两个坑：
  · 代码里要是有 `\"\"\"` 就直接炸
  · raw 字符串会把代码里的反斜杠原样保留，`\\n` 会变成两个字符
所以改成**直接把源码拼进去**（和 _assemble_majors.py 一样）。
数据仍然走 jsons，但先断言里面没有三引号。
"""
import ast
import io
import json

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
def strip_module_docstring(src, name):
    """把文件级 docstring 改成注释。

    【为什么必须做这一步】
    拼接进来之后，文件级 docstring 就是一条**裸表达式语句**（三引号字符串）。
    Streamlit 的裸表达式会被当 st.write 输出——于是用户会看到我的开发笔记：
    「【初心，抄在代码里免得忘】script.py 原文：……」**这是真发生过的 bug。**
    改成注释，内容还留着给读代码的人，但不会被渲染。
    """
    tree = ast.parse(src)
    if not tree.body:
        return src
    first = tree.body[0]
    if not (isinstance(first, ast.Expr)
            and isinstance(first.value, ast.Constant)
            and isinstance(first.value.value, str)):
        return src
    lines = src.split("\n")
    a, b = first.lineno - 1, first.end_lineno
    body = lines[a:b]
    # 首尾各去掉一行三引号
    if len(body) >= 2:
        body = body[1:-1]
    commented = ["# " + x if x.strip() else "#" for x in body]
    out = lines[:a] + ["# --- 以下原为 %s 的文件级说明，改成注释以免被渲染 ---"
                       % name] + commented + lines[b:]
    return "\n".join(out)


src = strip_module_docstring(
    open(f"{ROOT}/_agent2_src.py", encoding="utf-8").read(), "_agent2_src")
mirror = strip_module_docstring(
    open(f"{ROOT}/_mirror_core.py", encoding="utf-8").read(), "_mirror_core")
tools = strip_module_docstring(
    open(f"{ROOT}/_tools_core.py", encoding="utf-8").read(), "_tools_core")
prompt = open(f"{ROOT}/_prompt_core.py", encoding="utf-8").read()

# 卡片渲染：牌局和对话**共用同一份**（`_cards_core.py`）。
# 【为什么对话版也要注入它】
# 对话版原来那个只画名字和门类的简版卡 `card_html()`，
# **完全不显示代价，也不标「模板值」**。代价是用户最想知道的事之一；
# 不标模板值就是拿估计冒充准数。这两件事 `_cards_core.py` 里
# 已有实现和测试（161 张牌全过）。各写一份的话迟早对不上。
cards = strip_module_docstring(
    open(f"{ROOT}/_cards_core.py", encoding="utf-8").read(), "_cards_core")
assert "def summary_data" in cards, "卡片模块里没有 summary_data"
assert "def render_card" in cards, "卡片模块里没有 render_card"

# 访谈界面：同样是共享的一份。
# 【它为什么必须进对话版】
# 「不是你去问它，是它反过来问你」是用户最早定下的产品主张。
# 合并成一个应用的时候这一块一度丢了——**丢了它就等于丢了产品的一半。**
interview = strip_module_docstring(
    open(f"{ROOT}/_interview_core.py", encoding="utf-8").read(),
    "_interview_core")
assert "def interview_questions" in interview, "访谈模块里没有出题函数"
assert "def interview_submit" in interview, "访谈模块里没有交答案的入口"

# 皮肤：和牌局**共用同一份结构**（`_theme_core.py`），只换配色。
# 对话版用 "rose"——温润一点，它要像个肯听你说话的人。
_theme_src = open(f"{ROOT}/_theme_core.py", encoding="utf-8").read()
_theme_ns = {}
exec(compile(_theme_src, "_theme_core.py", "exec"), _theme_ns)  # noqa: S102
theme_css = _theme_ns["css"]

game = json.load(open(f"{ROOT}/_majors_game.json", encoding="utf-8"))
occ = json.load(open(f"{ROOT}/_occ_detail.json", encoding="utf-8"))
occ_idx = json.load(open(f"{ROOT}/_occ_index.json", encoding="utf-8"))

major_blob = json.dumps(game, ensure_ascii=False, separators=(",", ":"))
occ_blob = json.dumps(occ, ensure_ascii=False, separators=(",", ":"))
idx_blob = json.dumps(occ_idx, ensure_ascii=False, separators=(",", ":"))
# 【学职平台登记了、但没做详情页的职业】
# 不和 `_assemble_majors.py` 各写一份读取逻辑——这里从同一份 occ_idx 取。
_nid_blob = json.dumps(occ_idx.get("occ_no_id") or {},
                       ensure_ascii=False, separators=(",", ":"))
for nm, b in (("majors", major_blob), ("occ", occ_blob),
              ("idx", idx_blob), ("nodetail", _nid_blob)):
    assert '"""' not in b, f"{nm} 数据里有三引号，会破坏模板"

# ── 官方目录索引（883 个专业）──
# 【为什么对话版也要这个】
# 它原来只会说「我库里没有」。但「我库里没有」和「这个专业不存在」
# 是两件完全不同的事——用户问「世界语」，教育部目录里真有，
# 说成「没有」就是在给他错的信息。
# 索引只留四个字段（门类/专业类/代码/官方满意度），约 35KB；
# 内联的 _majors_game.json 本来就是 790KB，这点不构成负担。
_tree = json.load(open(f"{ROOT}/_official_2026_tree.json", encoding="utf-8"))
_cat, _cat_cls = {}, {}
for _gate, _g in _tree.items():
    for _cls, _c in _g["classes"].items():
        _cat_cls[_cls] = [_gate, len(_c["majors"])]
        for _mj in _c["majors"]:
            _cat[_mj["name"]] = [_gate, _cls, _mj.get("code") or "",
                                 _mj.get("zymyd")]
assert len(_cat) == 883, f"官方目录 {len(_cat)} 个专业，应为 883"

# ── 同一专业类里的官方就业方向，齐不齐？ ──
# 【为什么要有这一层，以及为什么门槛必须是算出来的】
# 没做牌的 722 个专业，对话版原来只能说四个字段，
# 而「以后能干什么」的材料其实在手边——只是它是**有牌的 161 个**的。
# 拿「工商管理类」的就业方向去答「市场营销」会得到 `会计/会计师`：
# **看着有出处，其实张冠李戴。**
#
# 所以先量：这个类里有官方就业方向的那些专业，**最大的那一撮占多少**。
#   机械类     5 个专业全一样（机械工程师/机械设计师/机械设备工程师）
#   工商管理类  6 个专业 6 种
# 门槛定在 **≥75% 且类内至少 3 个专业**：
#   只用 2 个专业就断言「这一类都是这样」，样本太小；
#   而 75% 以下就是各走各的，按类说等于编。
# 实测这条线放出 12 个类、覆盖 199 个没牌的专业，
# 而且它们的同源出口都是**特征出口**（法务/律师、机械工程师、
# 内科/外科医生、建筑设计师），不是「公务员/教师」那种通用去向凑出来的。
_chsi = json.load(open(f"{ROOT}/_chsi_detail.json", encoding="utf-8"))
_cls_exit = {}
for _cls, _c in ((c, cc) for g, gg in _tree.items()
                 for c, cc in gg["classes"].items()):
    _sig = {}
    for _mj in _c["majors"]:
        _d = _chsi.get(_mj["name"]) or {}
        _jf = _d.get("jyfx") or []
        if _jf:
            _sig.setdefault(tuple(_jf), []).append(_mj["name"])
    _n = sum(len(v) for v in _sig.values())
    if _n < 3 or not _sig:
        continue
    _top, _names = max(_sig.items(), key=lambda kv: len(kv[1]))
    if len(_names) / _n >= 0.75:
        _cls_exit[_cls] = {"方向": list(_top)[:6], "同类专业数": len(_names),
                           "该类有数据的专业数": _n}
_cls_blob = json.dumps(_cls_exit, ensure_ascii=False,
                       separators=(",", ":"))
assert '"""' not in _cls_blob, "类内出口数据里有三引号"
print(f"  类内同源出口 {len(_cls_exit)} 个专业类"
      f"（≥75% 且同类≥3 个专业，{len(_cls_blob):,} 字节）")

cat_blob = json.dumps({"_major": _cat, "_class": _cat_cls,
                       "_cls_exit": _cls_exit},
                      ensure_ascii=False, separators=(",", ":"))
assert '"""' not in cat_blob, "目录数据里有三引号"
print(f"  官方目录索引 {len(_cat)} 个专业 / {len(_cat_cls)} 个专业类"
      f"（{len(cat_blob):,} 字节）")

out = src
out = out.replace("__MAJOR_DATA__", major_blob)
out = out.replace("__OCC_DATA__", occ_blob)
out = out.replace("__OCC_INDEX__", idx_blob)
out = out.replace("__OCC_NODETAIL__", _nid_blob)
out = out.replace("__MIRROR_CODE__", mirror)
out = out.replace("__TOOLS_CODE__", tools)
out = out.replace("__PROMPT_CODE__", prompt)
out = out.replace("__CARDS_CODE__", cards)
out = out.replace("__INTERVIEW_CODE__", interview)
out = out.replace("__CATALOG__", cat_blob)
out = out.replace("__THEME__", theme_css("rose"))
for ph in ("__MAJOR_DATA__", "__OCC_DATA__", "__OCC_INDEX__",
           "__OCC_NODETAIL__",
           "__MIRROR_CODE__", "__TOOLS_CODE__", "__PROMPT_CODE__",
           "__CARDS_CODE__", "__INTERVIEW_CODE__", "__CATALOG__",
           "__THEME__"):
    assert ph not in out, f"占位符没换掉：{ph}"
# 配色占位符漏一个，页面上就会出现 `__C_INK__` 这种像正常文字的垃圾
assert "__C_" not in out, "配色占位符没替换干净"

# 语法检查：拼出来的必须能编译
try:
    ast.parse(out)
except SyntaxError as e:
    print(f"✗ 语法错误 第 {e.lineno} 行: {e.msg}")
    print("  附近：")
    for i, l in enumerate(out.split("\n")[max(0, (e.lineno or 1) - 4):
                                       (e.lineno or 1) + 3],
                           start=max(1, (e.lineno or 1) - 3)):
        print(f"   {i:5} {l[:120]}")
    raise SystemExit(1)

open(f"{ROOT}/志业镜.py", "wb").write(out.encode("utf-8"))

print("已生成 志业镜.py")
print(f"  行数   {out.count(chr(10)) + 1}")
print(f"  字节   {len(out.encode('utf-8')):,}")
print(f"  专业   {len(game['majors'])}")
print(f"  职业族 {len(occ)}")
print(f"  有需求画像 {sum(1 for m in game['majors'] if m.get('dims'))}")
print(f"  BOM    {'有 ✗' if out.startswith(chr(0xFEFF)) else '无 ✓'}")

# 自检：界面依赖的字段必须都在白名单里活下来
need = {"n", "gate", "gate_icon", "门类", "专业类", "学位", "years",
        "hook", "core_s", "weary", "suits", "act_s"}
got = set(game["majors"][0].keys())
print(f"  界面必需字段 {'✓' if not (need - got) else '✗ 缺 ' + str(need - got)}")

# 自检：内联的段落不能带自己的 import 副作用
for nm, code in (("mirror", mirror), ("tools", tools), ("prompt", prompt)):
    try:
        ast.parse(code)
    except SyntaxError as e:
        print(f"  ✗ {nm} 源码本身语法错：{e}")

# 【上一版这条自检是假的】我写了个恒真表达式，于是它永远打印「✓ 无」，
# 而实际上模块 docstring 正在被渲染成 markdown 给用户看。
# 现在真的扫一遍：顶层不许有裸字符串表达式。
_t = ast.parse(out)
_bare = [n.lineno for n in _t.body
         if isinstance(n, ast.Expr) and isinstance(n.value, ast.Constant)
         and isinstance(n.value.value, str)]
print(f"  顶层裸字符串（会被 Streamlit 当 markdown 渲染）"
      f"{'✓ 无' if not _bare else '✗ 第 ' + str(_bare) + ' 行'}")
