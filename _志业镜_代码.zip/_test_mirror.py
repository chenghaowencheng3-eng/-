# -*- coding: utf-8 -*-
"""测志业镜的分析核心：用真实库数据跑，检查它算得对不对、话说不说得通。"""
import io
import json

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(
    _os.path.abspath(__file__))))
sys.path.insert(0, ROOT)
from _mirror_core import (DIM_NAMES, REASON_DIM, REALITY_REASONS,  # noqa
                          mirror_lines, read_mirror)

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")
lib = json.load(open(os.path.join(ROOT, "_majors.json"),
                     encoding="utf-8"))
byname = {m["_name"]: m for m in lib["majors"]}
ok = bad = 0


def chk(cond, msg):
    global ok, bad
    if cond:
        ok += 1
        print(f"  ✓ {msg}")
    else:
        bad += 1
        print(f"  ✗ {msg}")


print("=== 1. 基础一致性 ===")
chk(len(DIM_NAMES) == 7, "7 个需求维度")
chk(len([r for r in REASON_DIM.values() if r]) == 7,
    "7 个理由都能映射到维度")
chk(len(REALITY_REASONS) == 4,
    f"4 个现实条件理由被排除在「对人的判断」之外：{REALITY_REASONS}")
for r in REALITY_REASONS:
    chk(REASON_DIM[r] is None, f"「{r}」不映射到任何需求维度")

print()
print("=== 2. 空输入不许崩，也不许编结论 ===")
r0 = read_mirror([], [])
chk(r0["enough"] is False, "没数据时 enough=False")
chk("dims" in r0.get("why", "") or "画像" in r0.get("why", ""),
    "没数据时说明了为什么")

print()
print("=== 3. 只用带画像的专业 ===")
with_dims = [m for m in lib["majors"] if m.get("dims")]
chk(len(with_dims) == 94, f"库里有 dims 的专业 {len(with_dims)} 个")

print()
print("=== 4. 真跑：收下 4 张理工科，翻过去时用「背不下来」 ===")
col = [byname[n] for n in ("计算机科学与技术", "数学与应用数学",
                           "电气工程及其自动化", "建筑学")]
rej = [(byname["临床医学"], ["背不下来"]),
       (byname["中医学"], ["背不下来"]) if byname.get("中医学") else
       (byname["哲学"], ["背不下来"]),
       (byname["金融学"], ["太卷/太累"]) if byname.get("金融学") else
       (byname["英语"], ["太卷/太累"])]
r = read_mirror(col, rej)
chk(r["enough"] is True, "够 3 张就算得出")
chk(len(r["profile"]) == 7, "算出 7 维画像")
chk(r["reject_hits"].get("记忆量") == 2,
    f"「背不下来」被数到记忆量 2 次（实际 {r['reject_hits']}）")
chk("太卷/太累" in r["reality_reasons"],
    "「太卷/太累」被放进现实条件，没进对人的判断")
chk(all(d != "太卷/太累" for d in r["reject_hits"]),
    "现实条件没污染需求维度")
chk(r["cost"]["hours_avg"] is not None, "算出了周均小时")
chk(r["cost"]["n_irreversible"] >= 1, "数出了「很难回头」的卡")
chk(len(r["hypotheses"]) >= 1, f"给出 {len(r['hypotheses'])} 条假设")
for h in r["hypotheses"]:
    chk("test" in h and h["test"], "每条假设都带一个能马上做的小实验")
    chk("推荐" not in h["t"], "假设里不出现「推荐」")

print()
print("=== 5. 镜像文字 ===")
for ln in mirror_lines(r):
    print("   ", ln)
print()
print("=== 6. 假设全文 ===")
for h in r["hypotheses"]:
    print(f"   【{h['t']}】")
    print(f"     {h['why']}")
    print(f"     试：{h['test']}")

print()
print("=== 7. 只收 1 张时不许下结论 ===")
r1 = read_mirror([byname["哲学"]], [])
chk(r1["enough"] is False, "1 张时 enough=False")
chk(not r1.get("hypotheses"), "1 张时不给假设")

print()
print(f"结果：{ok}/{ok+bad} 通过" + ("" if bad == 0 else f"　失败 {bad}"))
