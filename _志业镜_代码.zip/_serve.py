# -*- coding: utf-8 -*-
"""把「志业镜」起成一个**真正脱离当前 job 对象**的独立进程。

【为什么需要这个文件】
我前面试过两种起法，两种都会「又打不开」：

  ① 后台 job 跑 `streamlit run`
     → 每次检查点 / job runner 退出，进程被**连带杀掉**。

  ② `Start-Process -PassThru`（Windows 下的「分离进程」）
     → 实测**照样被连带杀掉**。因为 DSH 把整棵进程树放进一个
       Windows Job 对象，`Start-Process` 起的孩子**还在这个 job 里**，
       job 一关，孩子跟着走。

真正能脱离 job 的只有一个办法：`CreateProcess` 时带上
`CREATE_BREAKAWAY_FROM_JOB`。Job 必须允许 breakaway，
但用 `DETACHED_PROCESS` + `CREATE_NEW_PROCESS_GROUP` 一起试，
成功就说明脱离了。

【为什么这么在意「脱离」】
用户看到的现象只是「又打不开了」——而它会**看起来像代码有问题**。
实际上代码一直是好的，是**起法**的问题。
一个反复被杀的进程不该被当成 bug 去查代码。
"""
import os
import shutil
import subprocess
import sys
import time

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
ROOT = ROOT
PY = r"C:\Users\Lenovo\AppData\Local\Python\pythoncore-3.14-64\python.exe"
PORT = 8503
OUT = os.path.join(ROOT, "_out")

# 【两个环境分工不同】service 要用有 streamlit 的那个（主环境）。
# 这个脚本自己可能跑在任何一个里，所以路径写死，不靠 sys.executable。
ARGS = [PY, "-m", "streamlit", "run", "志业镜.py",
        "--server.port", str(PORT),
        "--server.address", "127.0.0.1",
        "--server.headless", "true",
        "--browser.gatherUsageStats", "false"]

DETACHED_PROCESS = 0x00000008
CREATE_NEW_PROCESS_GROUP = 0x00000200
CREATE_BREAKAWAY_FROM_JOB = 0x01000000


def listening():
    """端口上有没有人在听。

    【为什么用它而不是 HTTP 200】
    Streamlit 在任何端口、哪怕 Python 已经死了，也会返回一个
    7,459 字节的静态外壳——**它是 200**。我拿它误报过一次
    「三个服务都活着」，而当时三个全死。
    """
    r = subprocess.run(["powershell", "-NoProfile", "-Command",
                        f"(Get-NetTCPConnection -LocalPort {PORT} "
                        f"-State Listen -ErrorAction SilentlyContinue | "
                        f"Measure-Object).Count"],
                       capture_output=True, text=True, timeout=60)
    return (r.stdout or "").strip().isdigit() and int(r.stdout.strip()) > 0


def stop_old():
    subprocess.run(["powershell", "-NoProfile", "-Command",
                    f"Get-NetTCPConnection -LocalPort {PORT} -State Listen "
                    f"-ErrorAction SilentlyContinue | ForEach-Object "
                    f"{{ Stop-Process -Id $_.OwningProcess -Force "
                    f"-ErrorAction SilentlyContinue }}"],
                   capture_output=True, text=True, timeout=60)
    time.sleep(2)


def main():
    os.makedirs(OUT, exist_ok=True)
    log = os.path.join(OUT, f"serve-{PORT}.log")
    err = os.path.join(OUT, f"serve-{PORT}.err.log")

    stop_old()
    if "--stop" in sys.argv:
        print("  已停。")
        return 0
    if not os.path.exists(PY):
        print(f"  ✗ 找不到 Python：{PY}")
        return 1
    if not os.path.exists(os.path.join(ROOT, "志业镜.py")):
        print("  ✗ 找不到 志业镜.py —— 先跑 _assemble_agent2.py")
        return 1

    fo = open(log, "ab", buffering=0)
    fe = open(err, "ab", buffering=0)
    # 【逐个 flag 降级试】breakaway 需要 job 允许；不允许时去掉它再试，
    # 至少比不试强。哪一档成功要打出来——**这是事实，不是猜测。**
    tried = [
        ("DETACHED+NEWGROUP+BREAKAWAY",
         DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
         | CREATE_BREAKAWAY_FROM_JOB),
        ("DETACHED+NEWGROUP",
         DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP),
        ("NEWGROUP", CREATE_NEW_PROCESS_GROUP),
    ]
    for name, flags in tried:
        try:
            p = subprocess.Popen(ARGS, cwd=ROOT, stdout=fo, stderr=fe,
                                 stdin=subprocess.DEVNULL,
                                 creationflags=flags, close_fds=True)
        except OSError as e:
            print(f"  {name}：起不来（{e}），试下一档")
            continue
        pid_file = os.path.join(OUT, f"serve-{PORT}.pid")
        open(pid_file, "w", encoding="ascii").write(str(p.pid))
        for _ in range(20):
            time.sleep(1)
            if listening() and p.poll() is None:
                print(f"  ✓ 起来了　{name}　PID {p.pid}")
                print(f"  ✓ {PORT} 在听，进程还活着")
                print()
                print(f"  🪞 http://127.0.0.1:{PORT}")
                return 0
            if p.poll() is not None:
                break
        print(f"  {name}：起了但没起来（退出码 {p.poll()}），试下一档")
    print("  ✗ 三档都没起来。错误日志尾巴：")
    try:
        with open(err, encoding="utf-8", errors="replace") as f:
            for l in f.readlines()[-20:]:
                print("      " + l.rstrip())
    except OSError:
        pass
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
