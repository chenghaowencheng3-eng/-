# -*- coding: utf-8 -*-
"""把专业库变成「游戏卡片」。

【钩子从哪来——这次想清楚了】
职业库的钩子来自 `hardest`（最难的那点，往往最抓人）。
专业库没有 hardest，但有三个可用素材：
  core  核心课程   → 「你四年要啃的东西」本身就是钩子
  dark  最大的坑   → 和 hardest 同理，最真实的那句最抓人
  val   这个专业管什么（旧版字段）→ 「它处理的是哪一类问题」

所以钩子的优先顺序：
  1) dark 里带转折/两难的那句（最真实、最像内行说的话）
  2) val ——「这个专业处理的是 XX、YY、ZZ」这类问题
  3) core ——「四年主要在啃 A、B、C」

【「有意思在哪」怎么讲】
不能写「很有趣」「很充实」这种空话。我的做法：
  **从这个专业「管什么问题」出发，说清它为什么值得花四年。**
  val 字段正好是这个——旧版把它当标签用，其实它是「意义」。
"""
import io, json, os, re, sys
from collections import Counter

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
md = json.load(open(os.path.join(ROOT, "_majors.json"), encoding="utf-8"))
majors = md["majors"]
GATE_ICON = md["gate_icon"]
GATES = md["gates"]

# ==================================================================
# 把访谈工作台收来的七维画像并进来
# ==================================================================
# 【为什么这一步是覆盖率唯一能长起来的地方】
# 94 个专业的画像是一路手写进去的，一次改一个。
# 161 里还有 67 个没有画像，农学那 5 个全是空的；
# 而官方目录有 883 个专业——**手写覆盖不完。**
# 所以把「找人问七个问题」变成产线：工作台落盘 → 这里并进来。
#
# 【只填空缺，绝不覆盖】
# 已经有 dims 的 94 个是人工写的，其中 6 个是访谈核实过的（C1）。
# 机器推的、来源不明的记录**不许悄悄改掉它们**。
# 两边都有的时候不合并、不打架：**只记一条冲突**，
# 让人自己看要不要处理。
_IV_STORE = os.path.join(ROOT, "_major_interviews.json")
_iv_conflicts, _iv_filled, _iv_skipped, _iv_rejected = [], [], [], []
try:
    _ivd = json.load(open(_IV_STORE, encoding="utf-8"))
    _ivrecs = _ivd.get("records") or []
except FileNotFoundError:
    _ivrecs = []
# 【这里必须自己校验一遍，不能信任「工作台已经验过了」】
# 第一版就是信任的。结果：一份被工作台拒收、但仍然躺在文件里的坏记录
# （越界的 9、只有 3 个数的、连署名都没有的）**被直接并进了牌堆**，
# 有画像的从 94 变成 98。
# 同一个数据文件有两个写入方、两套规则，就一定有一边是漏的。
# 所以校验规则只有一份（`_mirror_core.check_interview_record`），
# **两边都调它。**
import sys as _sys
_sys.path.insert(0, ROOT)
from _mirror_core import check_interview_record   # noqa: E402
_names = {(m.get("_name") or m.get("n")) for m in majors}
_by_major = {}
for _r in _ivrecs:
    _errs = check_interview_record(_r, _names)
    if _errs:
        _iv_rejected.append((_r.get("major") or "（没写专业名）", _errs))
        continue
    _by_major[_r["major"]] = _r
for _m in majors:
    _nm = _m.get("_name") or _m.get("n")
    _r = _by_major.get(_nm)
    if not _r:
        continue
    _v = _r.get("dims")
    if not _v or not any(x is not None for x in _v):
        _iv_skipped.append((_nm, "记录里七项全是「不知道」，没有可用的数"))
        continue
    if _m.get("dims"):
        _iv_conflicts.append((_nm, _m["dims"], _v))
        continue
    # 全 None 的项没意义；只要有一项有值就收下，
    # 缺的那几项留 None——**留白比填一个猜的数诚实。**
    _m["dims"] = _v
    _m["dims_tier"] = _r.get("tier") or "C2"
    _m["dims_src"] = ("访谈工作台：" + str(_r.get("who") or "未署名")
                      + "　" + str(_r.get("on") or ""))
    _iv_filled.append((_nm, _v, _m["dims_tier"]))

# 「空话词」——看见这些词就说明这句没信息量。
#
# 【为什么必须有这张表】
# 旧版专业库的 val（这个专业管什么）里，大约 **31% 是纯空话**：
#   「理解社会、关怀弱者、推动改变」「追问根本、反思时代、追求智慧」
#   「传承文化、表达思想、审美」
# 这些句子**听着好，但没有信息**——它套在任何文科专业上都成立。
# 而另一部分是具体的：「半导体、传感器」「污水处理、城市水循环」
#   「防洪减灾」「精密测量」——这些一看就知道这个专业在干嘛。
#
# 所以判据不是「有没有 val」，而是 **val 够不够具体**。
# 具体 → 当钩子；空话 → 退到 core（课程名至少是实的）。
HYPE = ["追求", "传承", "理解", "关怀", "推动", "精神", "之美", "反思",
        "根本", "智慧", "表达", "审美", "素养", "意识", "人文", "情怀",
        "价值", "意义", "探索", "视野", "能力", "创新", "思想", "文化",
        "可持续", "和谐", "美好"]


def concrete_enough(s):
    """这句 val 够不够具体？含空话词或太短就不够。"""
    if not s:
        return False
    parts = [p for p in re.split(r"[、,，]", s) if p.strip()]
    if not parts:
        return False
    # 只要有空话词，就认为这句偏虚（宁可保守，退到课程名）
    if any(w in s for w in HYPE):
        return False
    # 至少要有两个具体名词
    return len(parts) >= 2


def clauses(t):
    if not t:
        return []
    return [p.strip(" ，、。；") for p in re.split(r"[。；;，,]", t)
            if len(p.strip(" ，、。；")) > 3]


def pick_hook(m):
    """挑最有戏的一句当钩子。

    【第三版：加了「具体度」判据】
    第二版改成「专业真正抓人的是它管什么问题（val）」——方向对了，
    但跑出来一堆空话钩子：
      「它管的是 真理、抽象之美、科学基础 这类事」
      「它管的是 理解社会、关怀弱者、推动改变 这类事」
    这不是钩子，这是招生宣传册。

    查了才发现：旧版 val 里**约 31% 是纯空话**
    （含「追求/传承/理解/关怀/人文/价值」这类词），
    而另一部分是具体的（「半导体、传感器」「污水处理、城市水循环」）。

    所以判据不是「有没有 val」，而是 **val 够不够具体**：
      · 具体 → 当钩子（它管的是 半导体、传感器 这类事）
      · 空话 → 退到 core（四年主要在啃：数据结构、操作系统、计算机网络）
        —— 课程名至少是实的，宁可平淡也不吹
    """
    # 「这个专业的坑里真有戏」的少数情况：行业正在发生变化
    CHANGING = ["AI", "人工智能", "冲击", "萎缩", "在缩", "被吞", "消失",
                "产业", "转型"]
    d = (m.get("dark") or "").strip()
    if d and any(w in d for w in CHANGING):
        cs = clauses(d)
        if cs:
            return cs[0]

    v = (m.get("val") or "").strip()
    core = m.get("core") or []
    if concrete_enough(v):
        return f"它管的是 {v} 这类事"
    if core:
        return "四年主要在啃：" + "、".join(core[:3])
    if v:
        return f"它管的是 {v} 这类事"
    if d:
        return clauses(d)[0] if clauses(d) else d
    return ""


def pick_fun(m):
    """「有意思在哪」——说清这个专业处理什么问题、为什么值得。

    **这是最容易被写成空话的字段**，所以给三条硬规则：
      · 必须落在具体的「问题/对象」上，不能是「很有趣」
      · 有 val 就用 val 展开（它是意义），没 val 就用 core（至少具体）
      · 宁可平淡地说「四年建的是这几门课」，也不吹
    """
    v = (m.get("val") or "").strip()
    core = m.get("core") or []
    if v and core:
        return (f"它处理的是 {v} 这一类问题，"
                f"底子是 {'、'.join(core[:3])} 这几门")
    if v:
        return f"它处理的是 {v} 这一类问题"
    if core:
        return "四年建的是 " + "、".join(core[:4]) + " 这套底子"
    return ""


def pick_weary(m, hook=""):
    """会烦到你——优先用 dark（那是我们标过的坑）。

    【为什么要传 hook 进来】
    「日语被 AI 翻译冲击大」这句话**同时是最好的钩子和最大的坑**——
    它对专业是真的、也真的抓人，所以当钩子是对的。
    但同一张卡上讲两遍就废了。
    处理办法：**让钩子用它，然后把它从「会烦你」里摘掉**，
    剩下的部分（就业面窄、需要复合技能）继续留在「会烦你」。
    """
    d = (m.get("dark") or "").strip()
    if not d:
        return "公开资料里没有写清这个专业的坑，**这是数据缺口**"
    if hook and hook in d:
        rest = [c for c in clauses(d) if c != hook]
        if rest:
            return "、".join(rest)
        # 整条 dark 都等同于钩子：说明这个专业的「坑」就是一句话。
        # 与其写「见上面的钩子」（绕），不如把剩下的分句交给「会烦你」，
        # 钩子只取第一句。这样两个字段各说各的，都不重复。
        cs = clauses(d)
        if len(cs) > 1:
            return "、".join(cs[1:])
        # 真的只有一句：那就直说这句是它的全部问题
        return d
    return d


def pick_suits(m):
    fit = m.get("fit") or []
    if not fit:
        return "公开资料里没有写清适合谁，**这是数据缺口**"
    return "、".join(fit[:3]) + " 的人"


def build(m):
    name = m.get("_name")
    o = dict(m)
    o["n"] = name
    o["gate"] = m.get("门类", "待定")
    o["gate_icon"] = GATE_ICON.get(o["gate"], "•")
    o["hook"] = pick_hook(m)
    o["fun"] = pick_fun(m)
    o["weary"] = pick_weary(m, o["hook"])
    o["suits"] = pick_suits(m)
    # 评级**原样带过去**，不在这里做任何转换——
    # 它是判断不是描述，派生逻辑一碰就会变成我在编数据。
    # 用「白名单搬字段」而不是逐个赋值：**漏一个字段就是静默丢数据**，
    # 前面已经因为漏 `gate_icon` 崩过一次。
    for k in ("rating", "rec_index", "enroll", "note845",
              "cls_desc", "gate_desc",
              "chsi_sat", "chsi_xsgm", "chsi_jyfx", "chsi_kyfx",
              "chsi_ratio", "chsi_desc", "chsi_specid",
              # 需求画像：这是「手感」和志业镜的原料，
              # **漏了这三个字段，卡片和对话智能体就都没得读**
              "dims", "dims_tier", "cost_hours", "cost_years",
              "cost_feedback_months", "cost_reversible", "cost_note",
              "cost_tier", "cost_templated", "ir", "tilt", "land", "avoid", "cap",
              "daily", "bottleneck", "ai_note", "mean", "manifest",
              "path"):
        if m.get(k) is not None:
            o[k] = m[k]
    o["core_s"] = "、".join((m.get("core") or [])[:5])
    o["car_s"] = "、".join((m.get("car") or [])[:4])
    o["act_s"] = "、".join((m.get("act") or [])[:3])
    o["years"] = m.get("学制", 4)
    o["degree"] = m.get("学位", "")
    # 兴趣类型：从核心课程推断（专业没有 caps 字段，只能从课名推断）
    return o


out = [build(m) for m in majors]
md["majors"] = out

L = []
L.append(f"=== 抽查 8 张专业卡（用户第一眼看到的）===")
import random
random.seed(3)
for m in random.sample(out, 8):
    L.append(f"\n┌─ {m['gate_icon']} {m['n']}　[{m['gate']}·{m['专业类']}]")
    L.append(f"│ {m['degree']}　{m['years']} 年")
    L.append(f"│ 钩子   {m['hook']}")
    L.append(f"│ 有意思 {m['fun']}")
    L.append(f"│ 会烦你 {m['weary']}")
    L.append(f"│ 适合   {m['suits']}")
    L.append(f"│ 核心课 {m['core_s']}")
    L.append(f"│ 通向   {m['car_s']}")
    L.append(f"│ 试试   {m['act_s']}")
    L.append(f"└─ 来源   {m['lvl']}｜{m['src']}")

L.append("")
L.append("=== 质量检查 ===")
L.append(f"  钩子为空    ：{sum(1 for m in out if not m['hook'])}")
L.append(f"  有意思为空  ：{sum(1 for m in out if not m['fun'])}")
L.append(f"  会烦你为空  ：{sum(1 for m in out if not m['weary'])}")
L.append(f"  适合为空    ：{sum(1 for m in out if not m['suits'])}")
dup_hw = sum(1 for m in out if m["hook"] == m["weary"])
L.append(f"  钩子==会烦你：{dup_hw}  ← 这两个字段讲同一件事就废了")
L.append(f"  钩子==有意思：{sum(1 for m in out if m['hook'] == m['fun'])}")
_contained = sum(1 for m in out
                 if m["hook"] and m["hook"] in m["weary"])
L.append(f"  钩子被会烦你包含：{_contained}  ← 同一类病")
L.append(f"  钩子平均长度：{sum(len(m['hook']) for m in out)/len(out):.0f} 字")
L.append(f"  有意思平均  ：{sum(len(m['fun']) for m in out)/len(out):.0f} 字")
L.append(f"  有动手试试  ：{sum(1 for m in out if m['act_s'])}/{len(out)}")
L.append(f"  有通向职业  ：{sum(1 for m in out if m['car_s'])}/{len(out)}")
L.append("")
L.append("=== 各门类抽查一个钩子 ===")
seen = set()
for m in out:
    if m["gate"] not in seen:
        seen.add(m["gate"])
        L.append(f"  {m['gate_icon']} {m['gate']:<4} {m['n']:<16} {m['hook'][:44]}")

L.append("")
L.append("=== 访谈工作台并进来的七维画像 ===")
L.append(f"  新填上画像的：{len(_iv_filled)} 个"
         f"　← 这些原本一个数都没有")
for _nm, _v, _t in _iv_filled:
    L.append(f"     {_nm:<14} {_v}　{_t}")
L.append(f"  和已有画像冲突、没动的：{len(_iv_conflicts)} 个"
         f"　← **有人工画像的以人工为准**")
for _nm, _a, _b in _iv_conflicts:
    L.append(f"     {_nm:<14} 人工 {_a}　访谈 {_b}")
L.append(f"  记录读到了但没用上的：{len(_iv_skipped)} 个")
for _nm, _why in _iv_skipped:
    L.append(f"     {_nm:<14} {_why}")
L.append(f"  校验没过、**挡在门外**的：{len(_iv_rejected)} 条")
for _nm, _errs in _iv_rejected:
    L.append(f"     {_nm:<14} {'；'.join(_errs)[:80]}")
L.append(f"  并完之后有画像的："
         f"{sum(1 for m in majors if m.get('dims'))}/{len(majors)}")

json.dump(md, open(os.path.join(ROOT, "_majors_game.json"), "w",
                   encoding="utf-8"), ensure_ascii=False, indent=1)
open(os.path.join(ROOT, "_majors_preview.txt"), "w",
     encoding="utf-8").write("\n".join(L))
