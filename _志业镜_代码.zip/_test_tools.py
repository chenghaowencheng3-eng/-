# -*- coding: utf-8 -*-
"""测对话智能体的工具层：用真实数据跑一遍，重点验底线。"""
import io
import json

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(
    _os.path.abspath(__file__))))
sys.path.insert(0, ROOT)
from _mirror_core import read_mirror                       # noqa: E402
from _tools_core import (DIM_KEYS, REALITY_TAGS,           # noqa: E402
                         SELF_TAGS, run_tool, tool_specs)

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")
# 工具层读的是**派生后**的 _majors_game.json（core_s/act_s/weary/suits
# 这些字符串是 _build_major_game.py 算出来的），不是原始的 _majors.json。
# 上一版我拿原始库去喂，于是读不到那些字段——**又是绕过装配**。
game = json.load(open(f"{ROOT}/_majors_game.json", encoding="utf-8"))
occ = json.load(open(f"{ROOT}/_occ_detail.json", encoding="utf-8"))
idx = json.load(open(f"{ROOT}/_occ_index.json", encoding="utf-8"))

by_name = {}
for m in game["majors"]:
    d = dict(m)
    d["n"] = m.get("n") or m.get("_name")
    if d["n"]:
        by_name[d["n"]] = d
occ_majors_stat = {r["primary"]: {"n_majors": r.get("n_majors")}
                   for r in occ.values()}
# 职业名可能有多种写法，都要能查到
occ_by_name = {}
for r in occ.values():
    for nm in set([r.get("primary")] + (r.get("names") or [])
                  + [r.get("name")]):
        if nm:
            occ_by_name[nm] = r

ctx = {"majors": list(by_name.values()), "by_name": by_name,
       "occ_by_name": occ_by_name, "occ_majors_stat": occ_majors_stat,
       "trace": []}

# ── 官方目录（883 个）──
# 【为什么测试里也要给】
# 目录是界面层内联进来的，工具层自己不持有。
# 不给它，`lookup_unavailable` 会走「我手上没有官方目录，核不了」那条路，
# 于是**测试跑的不是生产条件**——它会通过，但通过的是别的东西。
# 拿真目录喂进去，测的才是用户会遇到的那条路。
_tree = json.load(open(f"{ROOT}/_official_2026_tree.json", encoding="utf-8"))
_cat, _cat_cls = {}, {}
for _g, _gd in _tree.items():
    for _cls, _cd in _gd["classes"].items():
        _cat_cls[_cls] = [_g, len(_cd["majors"])]
        for _mj in _cd["majors"]:
            _cat[_mj["name"]] = [_g, _cls, _mj.get("code") or "",
                                 _mj.get("zymyd")]
assert len(_cat) == 883, f"官方目录 {len(_cat)} 个，应为 883"
ctx["cat_major"], ctx["cat_class"] = _cat, _cat_cls


def mirror_fn():
    col = [by_name[x] for x in ctx.get("mirror_col", []) if x in by_name]
    rej = [(by_name[x], rs) for x, rs in ctx.get("mirror_rej", [])
           if x in by_name]
    return read_mirror(col, rej)


ctx["mirror_fn"] = mirror_fn

ok = bad = 0


def chk(c, m):
    global ok, bad
    if c:
        ok += 1
        print(f"  ✓ {m}")
    else:
        bad += 1
        print(f"  ✗ {m}")


def T(name, args=None):
    return run_tool(name, args or {}, ctx)


print("=== 1. 工具声明本身 ===")
sp = tool_specs()
names = [s["function"]["name"] for s in sp]
chk(len(names) == len(set(names)), f"{len(names)} 个工具名不重复")
for banned in ("recommend", "suggest", "pick_for_me", "decide"):
    chk(not any(banned in n for n in names),
        f"没有「替用户决定」的工具（{banned}）")
# 现实条件和「你这个人」必须分开记
chk("remember_about_person" in names and "remember_reality" in names,
    "「关于你」和「现实条件」是两个不同的工具")

print()
print("=== 2. 查专业 ===")
r = T("search_majors", {"gate": "工学", "limit": 5})
chk(r["count"] > 0, f"工学查到 {r['count']} 个")
r = T("show_major", {"name": "软件工程"})
chk(r["found"], "软件工程能拿到卡")
chk(r["card"]["what_you_study"], "卡里有「学什么」")
chk(r["card"]["one_thing_to_try_this_afternoon"],
    "卡里有「这个下午就能试」")

print()
print("=== 3. 需求画像 + 代价硬数据 ===")
r = T("requirements", {"name": "计算机科学与技术"})
chk(r["has_profile"], "计算机有需求画像")
chk(len(r["dims"]) == 7, "7 项要求")
chk(r["dims"]["细节分辨"] == 1, "计算机的「细节分辨」是 1（真实的）")
chk(r["dims"]["自驱要求"] == 5, "计算机的「自驱要求」是 5（真实的）")
chk(r["dims_plain"]["自驱要求"].startswith("没人给你划重点"),
    "有给人看的说法，不只是数字")
chk(r["cost"]["hours_per_week"] is not None, "有周均小时")
# 模板值必须被标出来，不能当硬数据说
r_t = T("requirements", {"name": "软件工程"})
chk(r_t["cost"].get("is_templated") is True,
    "软件工程的代价被标成模板值（88 个里它是模板）")
chk("模板推的" in r_t["cost"]["reliability"], "说明了为什么不可信")
r_c = T("requirements", {"name": "临床医学"})
chk(r_c["cost"].get("is_templated") is False,
    "临床医学的代价是逐个访谈核实的")
chk("访谈核实" in r_c["cost"]["reliability"], "标成核实过的")
chk(r["tier"] in ("C1", "C2"), f"标了来源等级 {r['tier']}")
chk("没有逐一核实" in r["tier_note"] or "访谈核实" in r["tier_note"],
    "说清了这份画像有多硬")

r = T("requirements", {"name": "逻辑学"})
chk(r["found"] and not r["has_profile"],
    "逻辑学没有画像时如实返回 has_profile=False")
chk("不要推测" in r["note"] or "如实说" in r["note"],
    "明确要求不许推测")

print()
print("=== 4. 对照实验（比空谈适合有用）===")
r = T("similar_majors", {"name": "数学与应用数学", "most": False})
chk(r["major"] == "数学与应用数学", "拿到基准专业")
chk(len(r["matches"]) == 5, "给了 5 个对照")
chk(r["matches"][0]["distance"] >= r["matches"][-1]["distance"],
    "最不像的排前面（距离降序）")
chk("像不等于好" in r["how_to_read"].replace("*", ""),
    "说明了「像 ≠ 好」")

r = T("majors_by_dimension", {"dimension": "记忆量", "high": False,
                              "limit": 6})
chk(r["dimension"] == "记忆量" and r["high"] is False,
    "能找「不要求背书」的专业")
vals = [x["value"] for x in r["majors"]]
chk(vals == sorted(vals), f"确实按记忆量升序 {vals}")
chk("要背的东西多" in r["meaning"], "给了这一维的人话说法")

print()
print("=== 5. 职业（出口那一侧）===")
r = T("occupations_of", {"name": "软件工程"})
chk(r["found"] and r["list"], f"软件工程有 {len(r['list'])} 个出口")
r = T("occupation_info", {"name": "软件工程师"})
chk(r.get("found"), "软件工程师查得到")
chk(r.get("education"), f"学历要求：{r.get('education')}")
chk(r.get("important_courses"), "有「重要的大学课程」")
chk("不是钱数" in str(r.get("pay", {}).get("note", "")),
    "明确说明薪酬是满意度、不是钱数")
chk("学职平台" in r.get("source", ""), "标了出处")
r = T("occupation_info", {"name": "软件工程师", "want": "majors"})
chk(r.get("majors"), f"反向查到 {len(r.get('majors') or [])} 个专业通向它")

print()
print("=== 6. 官方满意度：票数必须一起给 ===")
r = T("student_ratings", {"name": "土木工程"})
chk(r.get("satisfaction"), "土木工程有满意度")
chk(r.get("total_votes", 0) > 10000, f"总票数 {r.get('total_votes')}")
chk("票数必须一起说" in r["how_to_read"].replace("*", ""),
    "明确要求连票数一起说")
chk("不等于就业率" in r["how_to_read"], "说明不是在读就业率")
r = T("student_ratings", {"name": "计算金融"})
chk(r.get("satisfaction") is None, "计算金融没有满意度")
chk("还没被验证过" in r["why_missing"], "说成「还没被验证过」")
chk("不要说成「差」" in r["why_missing"], "明确禁止说成「差」")

print()
print("=== 7. 评级不许合成 ===")
r = T("external_ratings", {"name": "汉语言文学"})
chk(r["ratings"], "汉语言文学有两套评级")
chk(len(r["ratings"]) == 2, "两套**分开列**，不是一个数")
chk("绝对不许合成一个总分" in r["warning"].replace("*", ""),
    "明确禁止合成")
r = T("external_ratings", {"name": "逻辑学"})
chk(not r["ratings"], "没评级时返回空")
chk("不许自己补一套" in r["note"], "禁止自己补")

print()
print("=== 8. 查不到就说查不到（最重要的一条）===")
r = T("lookup_unavailable", {"name": "星际飞船驾驶"})
chk(not r["is_major"] and not r["is_occupation"], "库里确实没有")
chk("没有就说没有" in r["rule"].replace("*", ""), "规矩写死在返回值里")

# 「我库里没有」和「官方目录里没有」必须分开答——
# 说成一样，就是在给用户错的信息。
r = T("lookup_unavailable", {"name": "世界语"})
chk(not r["is_major"] and r.get("in_official_catalog") is True,
    "世界语：我库里没有，但官方目录里有")
chk((r.get("official") or {}).get("门类") == "文学", "世界语的官方门类对")
chk((r.get("official") or {}).get("专业代码") == "050241",
    "世界语的官方专业代码对")
chk("没把它做成牌" in r["rule"], "明说「有目录条目但我没做成牌」")
r = T("lookup_unavailable", {"name": "星际飞船驾驶"})
chk(r.get("in_official_catalog") is False, "不存在的名字：官方目录里也没有")
# 【为什么不用「农学」当反例】
# 我第一版拿它当「不存在」的例子——而农学是**门类**，
# 本来就不在那 883 个**专业名**里，所以它被判 False 是对的判定、
# 错的期望。挑反例要挑**真的什么都没有**的。
r = T("lookup_unavailable", {"name": "临床医学类"})
chk(r.get("is_official_class") is True
    and (r.get("official") or {}).get("下面有专业数") == 7,
    "专业类名也认（临床医学类 → 7 个专业）")
r = T("lookup_unavailable", {"name": "软件工程"})
chk(r["is_major"] and r.get("in_official_catalog"),
    "有牌的：两边都认")
chk("有这张牌" in r["rule"], "有牌时让他直接看牌，不说「我没做成牌」")

r = T("show_major", {"name": "星际飞船驾驶"})
chk(not r["found"], "show_major 也不装懂")
chk("不要编" in r["note"], "明确禁止编")
r = T("lookup_unavailable", {"name": "大数据"})
chk(r["maybe_meant"], f"近似建议：{r['maybe_meant']}")

print()
print("=== 9. ★ 现实条件不许污染「你这个人」 ===")
chk(not (set(SELF_TAGS) & set(REALITY_TAGS)), "两张表的标签零交集")
r = T("remember_about_person", {"tag": "坐得住",
                                "quote": "我能一个人在实验室待一下午"})
chk(r["ok"] and r["n_self"] == 1, "记下关于他自己的事")
r = T("remember_reality", {"tag": "家里希望我学某个",
                           "quote": "我妈非要我学医"})
chk(r["ok"], "记下现实条件")
chk("不能用来判断他适合什么" in r["limit"].replace("*", ""),
    "现实条件的返回值里写死了限制")
chk("别把它写进任何「你这个人」的结论里" in r["limit"].replace("*", ""),
    "明确禁止写进对人的结论")
# 交叉污染测试：不许把一个标签记到另一张表
r = T("remember_about_person", {"tag": "家里希望我学某个", "quote": "x"})
chk("error" in r, "现实条件标签不许记进「关于你」")
r = T("remember_reality", {"tag": "坐得住", "quote": "x"})
chk("error" in r, "人格标签不许记进「现实条件」")

print()
print("=== 10. 记第一反应（排除理由信号更强）===")
r = T("note_impression", {"major": "临床医学", "feel": "不要",
                          "why": "背不下来"})
chk(r["ok"], "记下「不要」")
r = T("note_impression", {"major": "不存在专业", "feel": "想要"})
chk("error" in r, "不许记不存在的专业")

print()
print("=== 11. 镜像：样本不够不许开口 ===")
ctx["mirror_col"] = ["哲学"]
ctx["mirror_rej"] = []
r = T("read_mirror")
chk(r.get("enough") is False, "1 张卡时拒绝开口")
ctx["mirror_col"] = ["计算机科学与技术", "数学与应用数学", "电气工程及其自动化"]
ctx["mirror_rej"] = [("临床医学", ["背不下来"])]
r = T("read_mirror")
chk(r.get("enough") is True, "3 张卡后开口")
chk(r.get("hypotheses"), f"给了 {len(r.get('hypotheses') or [])} 条假设")
chk(all("推荐" not in h["t"] for h in r["hypotheses"]),
    "假设里不出现「推荐」")

print()
print("=== 12. 工具没有副作用泄漏 ===")
chk(all(t[0] for t in ctx["trace"]), f"留下了 {len(ctx['trace'])} 条调用轨迹")
print("   最后 6 条：", ctx["trace"][-6:])

print()
print(f"结果：{ok}/{ok+bad} 通过" + ("" if bad == 0 else f"　失败 {bad}"))
