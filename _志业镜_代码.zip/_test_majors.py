# -*- coding: utf-8 -*-
"""专业游乐场 界面验收。输出写文件（AppTest 会关掉 stdout）。"""
import ast, io, json, os, sys
import re as _re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8",
                              errors="replace")

from streamlit.testing.v1 import AppTest

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
L, R = [], []
def chk(b, m):
    b = bool(b)
    L.append(f"  {'✓' if b else '✗'} {m}")
    R.append(b)


def step_on(at_x, label_word):
    """点一下某个按钮，并**走过它后面那一轮**（如果它开了一轮）。

    【为什么要这个辅助函数】
    流程改过两次：
      第一版  点「收下/翻过去」→ 直接换下一张
      第二版  点「收下/翻过去」→ 先进「它问一句」那一轮
      第三版  它先开口 → 答一句 → 发牌 → 选 → （翻过去要先说为什么）
    **测试要跟着流程一起改，不然测的是上一个版本。**
    这个函数的作用就是「点一下，然后把挡在路上的对话步骤走完」。

    【它必须在文件最前面】第 3 节就要用。我第一版把它写在 _ns 那一段旁边
    （第 620 多行），于是第 3 节调用时报 NameError——编辑替换的是原文位置，
    **我以为它在移动，其实它纹丝没动。**
    """
    for b in at_x.button:
        if label_word in (b.label or ""):
            b.click()
            at_x.run()
            break
    else:
        return False
    # 把后面挡路的对话步骤走完：可能是「说完了，给我看张牌」，
    # 也可能是「记下，然后接着聊」
    for _ in range(3):
        _nxt = [b for b in at_x.button
                if any(w in (b.label or "") for w in
                       ("给我看张牌", "接着聊", "下一张", "跳过"))]
        if not _nxt:
            break
        _nxt[0].click()
        at_x.run()
    return True



# 【为什么第一步就查异常】
# 上一轮 dims_block 用了 DIM_PLAIN，但装配时忘了把 _mirror_core 内联进来。
# 结果运行时 NameError——**而 AppTest 只是把页面渲染成空白，
# 测试照样报 43/43 通过**。异常没人看，就等于没测。
# 所以现在开局先把异常数按住，为 0 才继续。
#
# 【注意：一个进程只能建一个 AppTest】
# AppTest 背后是 Streamlit 的 DeltaGeneratorSingleton，**全局唯一，
# del + gc 都放不掉**（实测）。所以这里建一个，从头用到尾——
# 换文件只能用 `.from_string` 之外的办法，或者干脆复用它。
# 【测哪个文件：从「专业游乐场.py」改成校验产物】
# `专业游乐场.py` 早就删了（产品只剩 `志业镜.py`）。
# 但牌局那套界面还在被 `_assemble_majors.py` 拼成
# `_专业游乐场.build-check.py` 用于校验——**那才是现在能测的那个**。
# 原来这里还写着 `AppTest.from_file("专业游乐场.py")`，
# 于是这条测试在**任何**目录下都跑不起来（FileNotFoundError）。
# 也就是说：它已经死了很久，只是没人跑它。
#
# 【路径必须绝对】
# AppTest 的相对路径是相对**调用它的那个文件**解析的，
# 不是相对当前工作目录——所以不能只写个文件名。
_APP_PATH = os.path.join(ROOT, "_专业游乐场.build-check.py")

# 【为什么必须只建一次】
# AppTest 背后是 Streamlit 的 DeltaGeneratorSingleton，**全局唯一**。
# 这个文件里原本有 **四处** `AppTest.from_file("专业游乐场.py")`
# （164 / 360 / 1821 / 1880 行），各建各的。
# 就算那个文件还在，第二处开始拿到的也是同一个单例——
# **看起来在测「新开一局」，实际测的还是上一局的状态。**
# 所以这里收成一个工厂：第一次真建，后面复用同一个实例并重跑。
_at_main = AppTest.from_file(_APP_PATH, default_timeout=300)
_at_main.run()


def mk_app(_timeout=300):
    """拿那个**唯一**的 AppTest，重跑一次，返回它。

    【为什么重跑】
    调用点想表达的是「新开一局」。单例没得换，
    但 `.run()` 会把脚本从头执行一遍、`session_state` 也重置，
    所以「重跑」和「新开」在效果上等价。
    """
    _at_main.run()
    return _at_main


_n_exc = len(_at_main.exception)
_first_exc = str(_at_main.exception[0].value)[:160] if _at_main.exception else ""
chk(_n_exc == 0,
    f"开局零异常（实际 {_n_exc}）" + (f"：{_first_exc}" if _n_exc else ""))


def blob_main(at):
    """只取**主区**的显示文字。

    【为什么要单独一个】
    我原来用 `blob(at).replace(侧栏文字, "")` 来排除侧栏。
    但侧栏默认展开时，它的每一行也在 blob 里；一旦某行文字重复出现在
    主区，replace 会把主区那处也一起删掉——**量出来的克制度是假的**。
    所以按元素来源分，不按字符串减。
    """
    parts = []
    for kind in ("markdown", "caption", "success", "error", "warning",
                 "info", "text", "subheader", "header", "title"):
        try:
            els = getattr(at, kind)
        except Exception:
            continue
        for e in els:
            v = getattr(e, "value", None)
            if v:
                parts.append(str(v))
    return "\n".join(parts)


def _strip_css(s):
    """把内联 <style> 整块剔掉。

    【为什么这一条必须加，而且加在这里】
    `blob()` 是全量拼接，它会把 `unsafe_allow_html=True` 发出去的
    `<style>` 也当成「显示文字」。牌局这一版新加了皮肤之后，
    「开局正文」从 1,500 多字一下跳到 **5,839 字**，
    而用户一个字都没多看到——**多出来的全是 CSS。**
    `_审计/_check_verbosity.py` 里早记过同一件事：
    「822 字是内联 CSS，一次都不出现在屏幕上」，
    我当时的量法就是没剔掉它，于是得出了「对话主区 1,360 字，很啰嗦」
    这个错结论。**同一个坑在另一个脚本里又踩了一次。**
    """
    out = _re.sub(r"<style[^>]*>.*?</style>", "", s, flags=_re.S)
    out = _re.sub(r"<[^>]+>", "", out)
    return out


def blob(at):
    """把**所有**显示文字的元素拼起来（含 button / selectbox 选项）。

    内联 CSS 不算「显示文字」——剔掉，理由见 `_strip_css`。
    """
    parts = []
    for kind in ("markdown", "caption", "success", "error", "warning",
                 "info", "text", "subheader", "header", "title"):
        try:
            els = getattr(at, kind)
        except Exception:
            continue
        for e in els:
            v = getattr(e, "value", None)
            if v:
                parts.append(_strip_css(str(v)))
    for e in at.button:
        if e.label:
            parts.append(str(e.label))
    for kind in ("selectbox", "multiselect", "radio"):
        try:
            els = getattr(at, kind)
        except Exception:
            continue
        for e in els:
            if getattr(e, "label", None):
                parts.append(str(e.label))
            try:
                parts.extend(str(o) for o in e.options)
            except Exception:
                pass
    return "\n".join(parts)


at = mk_app(300)
at.run()

L.append("=== 1. 开局 ===")
chk(not at.exception, f"无异常（{len(at.exception)}）")
for e in at.exception:
    L.append("EXC: " + e.value[:600])
b = blob(at)
chk("志业镜 · 牌局" in b, "开局是给牌")
chk("坐下聊" in b, "有「坐下聊，它先问你一句」")
chk("直接给我一张" in b, "有「直接给我一张」")
L.append(f"  开局正文 {len(b)} 字")
chk(len(b) < 2600, f"开局正文 < 2600 字（实际 {len(b)}）")

# 门类都在。
# 【数字不能写死】官方目录加门类的时候，这条断言就变成了「测我的记忆」。
# 这里还不能用 _ns（它在第 5 节才定义），所以直接从数据文件读。
_GJ = json.load(open("_majors_game.json", encoding="utf-8"))
_N_GATES = len(_GJ["gates"])
sb = [x for x in at.selectbox if x.label == "门类"]
chk(bool(sb), "有门类下拉")
if sb:
    opts = list(sb[0].options)
    chk(len(opts) == _N_GATES + 1,
        f"门类选项 = {_N_GATES} 个门类 + 全部（实际 {len(opts)}）")
    chk("交叉学科" in opts, "门类下拉里有官方新增的「交叉学科」")
    L.append(f"    选项：{opts}")

L.append("")
L.append("=== 2. 它先开口，牌才出现 ===")
# 【顺序是这一版的重点】
# 用户：「形式就是我和你如今对话的形式，然后穿插纸牌这一操作」。
# 所以点「坐下聊」之后**第一屏不该有卡，该有一句话和一个问题**。
btns = [x for x in at.button if "坐下聊" in (x.label or "")]
chk(bool(btns), "找到「坐下聊」按钮")
if btns:
    btns[0].click()
    at.run()
    chk(not at.exception, f"先开口这一页无异常（{len(at.exception)}）")
    for e in at.exception:
        L.append("EXC: " + e.value[:400])
    b_meet = blob(at)
    chk("志业镜" in b_meet, "它先报自己是谁")
    chk("先把牌放下" in b_meet, "明说先聊、牌放后面")
    chk("？" in b_meet or "?" in b_meet, "它问了一个问题")
    chk("学什么" not in b_meet,
        "**这一屏还没有卡片**（牌是回应，不是开场）")
    chk("给我看张牌" in b_meet, "有「说完了，给我看张牌」")
    chk("再问我一句" in b_meet, "可以不让它发牌、继续聊")
    chk("换门类" in b_meet, "对话里也有路回选牌页")

    # 答一句之后，牌才作为回应出现
    _ta = [x for x in at.text_area]
    if _ta:
        _ta[0].set_value("高一暑假自己装过一台电脑，装到半夜")
    else:
        chk(False, "有可以写字的地方")
    btns2 = [x for x in at.button if "给我看张牌" in (x.label or "")]
    chk(bool(btns2), "能往前走去看牌")
    if btns2:
        btns2[0].click()
        at.run()
        chk(not at.exception, f"发牌页无异常（{len(at.exception)}）")
        b2 = blob(at)
        chk("这一张" in b2, "牌是作为回应出现的（「这一张，你看一下」）")
        for f in ("学什么", "代价", "为什么值得", "谁适合", "出来能干什么"):
            chk(f in b2, f"卡片有「{f}」")
        chk("这个下午就能试" in b2, "卡片有「动手试试」（最能帮人判断的东西）")
        _hook = any(m.value.startswith("> **") for m in at.markdown if m.value)
        chk(_hook, "主视觉是钩子（引用块）")
        chk("学士" in b2, "显示授予学位")
        chk("年" in b2, "显示学制")
        # 【看牌的时候随时能把它变成对话】这是最贴用户那句话的地方
        chk("先聊两句" in b2, "看牌时还能「先聊两句」——牌局本身就是对话")

        L.append("")
        L.append("=== 3. 收下 / 翻过去 ===")
        keep = [x for x in at.button if "收下" in (x.label or "")]
        chk(bool(keep), "有「收下」")
        if keep:
            keep[0].click()
            at.run()
            _blob3 = blob(at)
            chk("我挑中的" in _blob3, "收下后侧栏出现「我挑中的」")
            chk("？" in _blob3 or "?" in _blob3,
                "收下之后它接着问下一句，而不是直接换牌")
            chk(len(at.exception) == 0, "收下之后零异常")
            # 回到选牌页，再测「翻过去」那条路
            step_on(at, "换门类")
            if not [x for x in at.selectbox if x.label == "排序"]:
                step_on(at, "换门类")
            b4 = [x for x in at.button if "坐下聊" in (x.label or "")]
            if b4:
                b4[0].click()
                at.run()
                step_on(at, "给我看张牌")
                _p = [x for x in at.button if "翻过去" in (x.label or "")]
                chk(bool(_p), "有「翻过去」")
                if _p:
                    _p[0].click()
                    at.run()
                    _bn2 = blob(at)
                    chk("为什么" in _bn2,
                        "翻过去之前先问为什么（排除理由是主机制）")
                    chk("不想要的原因" in _bn2, "有「不想要的原因」多选")
                    chk("记下，然后接着聊" in _bn2, "能记下原因再接着聊")
                    _adv = [x for x in at.button
                            if "接着聊" in (x.label or "")]
                    if _adv:
                        _adv[0].click()
                        at.run()
                        chk(len(at.exception) == 0,
                            "记下原因之后零异常")
                        # 【它必须接着回应你刚说的那句】
                        # 我们上面什么原因都没勾，所以 heard 是空的，
                        # 它该老老实实说「你没说为什么」；勾了才会有维度回应。
                        # 所以这里查的是「它接话了」，不是「它猜到了」。
                        _after = blob(at)
                        chk("志业镜" in _after, "记下之后回到对话")
                        chk("没说" in _after or "不猜" in _after
                            or "你说的" in _after or "我记得的" in _after,
                            "它接着就回应了你说不要的那一点")

    L.append("")
    L.append("=== 4. 界面克制度（用户抱怨过啰嗦）===")
    b3 = blob(at)
    # 侧栏默认显示课堂展示局的讲解词，那是**给台上念的**，不是给用户读的
    # 界面文字。但侧栏元素和主区元素在 AppTest 里都算 markdown，
    # 没法按来源分开——**所以这里只量整页，并单独记录讲解词那一份**。
    _sb3 = "\n".join(str(getattr(e, "value", "") or "")
                     for e in at.sidebar.markdown)
    for w in ("为什么要有这个东西", "设计上", "纪律"):
        c = b3.count(w)
        L.append(f"    「{w}」出现 {c} 次")
    chk("为什么要有这个东西" not in b3, "没有说教块")
    L.append(f"    「我们」全页 {b3.count('我们')} 次"
             f"（侧栏讲解词 {_sb3.count('我们')} 次）")
    chk(_sb3.count("我们") == 0,
        f"侧栏讲解词里「我们」0 次（实际 {_sb3.count('我们')}）")

    L.append("")
    L.append("=== 4b. 评级：两套必须并列、不许合成 ===")
    # 【回选牌页的路有两条】
    # 选牌页那张牌上写「↩ 换个门类」；进了对话那一轮之后，
    # 按钮写「↩ 换门类」（问句页上没地方放那么长的字）。
    # 我第一版只匹配前者，收下之后停在哪就找不到了——
    # **一次按钮文案不一致，后面五条断言全级联失败。**
    back0 = [x for x in at.button if "换门类" in (x.label or "")
             or "换个门类" in (x.label or "")]
    if back0:
        back0[0].click()
        at.run()
    chk(bool(back0), "对话那一轮有路可以回到选牌页")
    chk(bool([x for x in at.selectbox if x.label == "排序"]),
        "点回去之后真的到了选牌页（出现「排序」下拉）")
    sb2 = [x for x in at.selectbox if x.label == "排序"]
    chk(bool(sb2), "有「排序」下拉")
    if sb2:
        opts2 = list(sb2[0].options)
        for want in ("好找工作排前面", "推荐指数排前面", "招生规模排前面"):
            chk(want in opts2, f"能按「{want}」排序")
    if sb2:
        sb2[0].select("推荐指数排前面")
        at.run()
        _b = blob(at)
        chk("★" in _b or "☆" in _b, "选牌页出现星级")
        start2 = [x for x in at.button if "坐下聊" in (x.label or "")]
        if start2:
            start2[0].click()
            at.run()
            # 【它先开口，牌在后面】所以要先答一句才看得到卡
            step_on(at, "给我看张牌")
            # 【上一版这里是测试自己的错】
            # 我断言「第一张卡就有星级」，但 176 个专业里只有 104 个有推荐指数，
            # 排在第一张的可能没评级。**不该假设，应该去找一张有的。**
            found = None
            for _ in range(12):
                b = blob(at)
                if "★" in b and "材料" in b:
                    found = b
                    break
                if not step_on(at, "翻过去"):
                    break
            chk(found is not None, "翻 12 张内找到有评级的卡")
            b4 = found or blob(at)
            chk("材料①" in b4, "卡片标出材料①的评级")
            chk("出处" in b4, "卡片标了评级出处")
            chk("★" in b4, "卡片有星级")
            chk("规模" in b4 or "●" in b4, "卡片区分了招生规模")
            bad = [w for w in ("综合评分", "总评分", "总分", "综合得分")
                   if w in b4]
            chk(not bad, f"没有把两套评级合成总分（{bad}）")

    L.append("")
    L.append("=== 4c. 官方数据（学信网）===")
    # 找一张有官方满意度的卡
    at2 = mk_app(300)
    at2.run()
    for b in at2.button:
        if "坐下聊" in (b.label or ""):
            b.click()
            break
    at2.run()
    step_on(at2, "给我看张牌")
    got_official = False
    for _ in range(10):
        bb = blob(at2)
        if "四维满意度" in bb or "满意度" in bb:
            got_official = True
            break
        if not step_on(at2, "翻过去"):
            break
    chk(got_official, "翻 10 张内找到带官方满意度的卡")
    bo = blob(at2)
    if got_official:
        chk("票" in bo, "满意度带了票数（票数必须一起给）")
        chk("学信网" in bo or "教育部" in bo, "标了官方出处")
        chk("实名投票" in bo or "学生" in bo,
            "说明这是学生自评（不是就业率）")
        chk(len(at2.tabs) >= 2, f"官方数据在 tab 里（{len(at2.tabs)} 个 tab）")
        chk("就业方向" in bo or "在校生规模" in bo, "有官方规模或去向")

    L.append("")
    L.append("=== 5. 走到结尾 ===")
    # 【这一段两次都栽在「上游状态不确定」上】
    # 它原来靠上一节留下的页面状态往回点，而上一节怎么结束是不确定的。
    # 所以这里**直接把状态整个换成「停在选牌页」**——测的是
    # 「一张牌走完会不会到结尾页」，不是「上一节结束在哪」。
    # **测试之间不该有隐含依赖。**
    #
    # 【注意 filtered_state 是拷贝】改它里面的字典没用（我试过一次，
    # 状态纹丝不动）。要**整个对象替换**。
    at.session_state["s"] = {
        "pool": ["临床医学"], "idx": 0, "deck": [], "passed": [],
        "nays": [], "notes": {}, "mode": "roster", "step": 0,
        "asked": {}, "ask": None, "heard": "", "last_major": None}
    at.run()
    L.append(f"    [拨回选牌页: mode="
             f"{(at.session_state.filtered_state.get('s') or {}).get('mode')!r}]")
    rnd = [x for x in at.button if "直接给我一张" in (x.label or "")]
    chk(bool(rnd), "回到选牌页后能拿到「直接给我一张」")
    if rnd:
        rnd[0].click()
        at.run()
        # 【这条是「不走对话、直接要一张」的快捷路】它进的是 deal，
        # 所以牌会立刻出来。这也是一条该保留的路：
        # 有人就是想先看牌。
        chk("收下" in blob(at), "「直接给我一张」确实直接给牌")
    keep2 = [x for x in at.button if "收下" in (x.label or "")]
    if keep2:
        keep2[0].click()
        at.run()
    be = blob(at)
    chk("底细" in be or "挑中的专业" in be, "牌走完之后会到结尾页")
    if "底细" not in be and "挑中的专业" not in be:
        L.append("    结尾页没到，当前页面片段：" + be[:220].replace("\n", " / "))
        L.append("    当前状态：" + str(
            {k: v for k, v in (at.session_state.filtered_state.get("s") or {}).items()
             if k in ("mode", "idx", "pool", "deck", "passed")}))
    if "底细" in be:
        chk("没有选科要求数据" in be, "如实说明没有选科数据")
        chk("联网查证" in be, "如实说明没有联网查证")
        # 【别写死文案】
        # 原来这里查的是「教育部」三个字。官方目录更新到 2026 版
        # （13 门类 / 93 专业类 / 883 专业）之后，我把那段话重写了，
        # 断言就失败了——**它测的是我当时的措辞，不是事实。**
        # 现在只查事实，具体数字留到第 12 节用 CATALOG 核。
        chk("本科专业目录" in be, "说明分类来自教育部本科专业目录")

L.append("")
L.append("=== 5. 装配后的文件本身 ===")
# （a）顶层不许有裸字符串，否则 Streamlit 会把开发笔记渲染给用户
_asm = open(os.path.join(ROOT, "_专业游乐场.build-check.py"),
            encoding="utf-8").read()
_t = ast.parse(_asm)
_bare = [n.lineno for n in _t.body
         if isinstance(n, ast.Expr) and isinstance(n.value, ast.Constant)
         and isinstance(n.value.value, str)]
chk(not _bare, f"顶层没有裸字符串（会被渲染成 markdown）{_bare}")

# （b）在真命名空间里跑一遍。
# **AppTest 会把异常吞成空白页，所以它测不出 NameError。**
# 这里用一个假 streamlit 直接 exec，NameError 就无处可逃。
class _Fake:
    def __init__(self):
        # 【这两个列表必须都初始化】marked 有了但 captions 没有，
        # __getattr__ 就会给 captions 返回一个函数，
        # 于是 `_f.captions.clear()` 报 'function' object has no attribute 'clear'。
        # 又是一个我自己制造的、看起来像代码 bug 的脚手架问题。
        self.marked, self.captions, self.session_state = [], [], {}
        # 【err / warn / ok 也要初始化】
        # 第七次同类错误：我的断言里写了 `_q.err + _q.warn`，
        # 而 `_Fake` 从没初始化过这两个名字，`__getattr__` 就返回一个函数，
        # 于是报 `can only concatenate list (not "function") to list`。
        # **报错信息指向那个 `+`，真凶却是缺属性。**
        self.err, self.warn, self.ok = [], [], []
        # 【progress 必须返回自身】
        # 真 `st.progress(...)` 返回一个对象，应用会接着 `.progress(...)`
        # 或把它当上下文用；`__getattr__` 默认返回 None，
        # 于是 `interview_turn` 报
        # `'NoneType' object has no attribute 'progress'`——
        # 那是我的假对象缺方法，不是应用的问题。
        self._progress = []

    def progress(self, *a, **k):
        self._progress.append(a[0] if a else None)
        return self

    def radio(self, *a, **k):
        # 真 radio 永远有值（默认第一项）。返回 None 会让
        # `_d.startswith(...)` 崩——同样是我的假对象不对。
        opts = a[1] if len(a) > 1 else k.get("options")
        if isinstance(opts, (list, tuple)) and opts:
            return opts[0]
        return None

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    @property
    def sidebar(self):
        return self

    # 真代码里有 `a, b, c = st.columns(3)` 这种解包，
    # 假对象不实现 columns 就会 TypeError。**假得太糙，测出来的错是我自己的。**
    def columns(self, spec):
        n = spec if isinstance(spec, int) else len(spec)
        return [self] * n

    def tabs(self, names):
        return [self] * len(names)

    def expander(self, *a, **k):
        # **expander 的标题也要收！**
        # 学历要求、薪酬满意度、n_majors 这些都写在 expander 的 label 里，
        # 我原来只收 markdown/caption，于是断言全误报。
        # 注意：这里必须记在 _f 自己的账本上——装配后的 ns["st"] 就是它。
        if a:
            self.captions.append(f"[expander] {a[0]}")
        return self

    def spinner(self, *a, **k):
        return self

    def __getattr__(self, name):
        def f(*a, **k):
            if name == "markdown":
                self.marked.append(str(a[0]) if a else "")
            # 【这个分支缺了很久】原来只处理 markdown，于是所有 st.caption
            # 都被静默丢掉：薪酬说明、出处、n_majors 的说明全在 caption 里。
            # 表现是「captions 只有 expander 标题」，我却在 code 里找了半天——
            # 又是脚手架和被测代码不一致，测出来的错是我自己的。
            if name == "caption":
                self.captions.append(str(a[0]) if a else "")
            # 【info 这次也漏了——第五次同类错误】
            # 应用里 st.info 有三处：需求画像那句、它回应你的那句话、
            # 还有收牌后的偏好推断。**这三处一直没被测到**，
            # 因为它写进了一个假对象不记的地方。
            # 表现是「明明运行过、代码也对，断言就是找不到那句话」——
            # 我该在第一次出现这种症状时就来查脚手架，而不是去改代码。
            if name in ("info", "warning", "error", "success"):
                self.marked.append(str(a[0]) if a else "")
            # 【按钮文案也要收——第六次同类错误了】
            # 用户看得见按钮上的字，所以它属于「界面上写了什么」。
            # capture() 原来只收 markdown/caption/info，于是
            # 「有收下/翻过去」「有先聊两句」这种断言永远找不到——
            # 而真正的原因是我的假对象只记了一部分渲染调用。
            # **规律很清楚：每次「代码明明跑了、断言就是找不到」，
            # 先查脚手架记不记这一类调用，别去改代码。**
            if name == "button":
                self.marked.append(str(a[0]) if a else "")
                return False
            if name in ("selectbox", "radio", "multiselect"):
                # 【控件自己的标签也要收】
                # 「不想要的原因（可多选）」「门类」「排序」这些字是
                # 写在控件标签上的，用户看得见。原来这个分支只返回值、
                # 不记标签，于是「有『不想要的原因』多选」这种断言找不到。
                # **第七次同类错误——全是假对象只记了一部分渲染调用。**
                if a:
                    self.marked.append(str(a[0]))
                return (a[1][0] if len(a) > 1 and a[1] else None)
            if name == "text_area":
                return ""
            return None
        return f


_f = _Fake()
# 【必须先把真 streamlit 存起来，测完还回去】
# 我原来只 `sys.modules.pop("streamlit")`，等于把真模块从缓存里丢了。
# 后面 AppTest 再 `import streamlit` 就会重新执行模块级代码，
# 撞上 DeltaGeneratorSingleton —— RuntimeError。
# 而报错信息完全不提「你刚才把 streamlit 换成假的」，
# 是我自己制造的故障，看起来却像 Streamlit 的 bug。
_saved_st = sys.modules.get("streamlit")
sys.modules["streamlit"] = _f
_ns = {"__name__": "playground_check"}
_exc = None
try:
    exec(compile(_asm, "_专业游乐场.build-check.py", "exec"), _ns)
except Exception as e:
    _exc = e
if _exc is None:
    chk(True, "装配后的文件能在命名空间里执行完")
else:
    # **把出错的行号也打出来**，不然只知道类型等于没说
    import traceback
    tb = traceback.extract_tb(_exc.__traceback__)
    last = tb[-1] if tb else None
    chk(False, f"执行报错 {type(_exc).__name__}: {str(_exc)[:110]}"
               + (f"　（第 {last.lineno} 行：{(last.line or '')[:70]}）"
                  if last else ""))

# 关键：**把每个顶层函数单独跑一遍**。
# 整体 exec 成功不代表函数体没问题——NameError 只在函数被调用时才炸，
# 而 dims_block 就是死在函数体里的。
if _ns.get("BY_NAME"):
    _probe_ok, _probe_bad = [], []
    for _fn, _args in (("dims_block", (next(iter(_ns["BY_NAME"].values())),)),
                       ("card", (next(iter(_ns["BY_NAME"].values())),)),
                       ("sources_rows",
                        (next(iter(_ns["BY_NAME"].values())),)),
                       ("demand_line",
                        (next(iter(_ns["BY_NAME"].values())),)),
                       ("ratings_block",
                        (next(iter(_ns["BY_NAME"].values())),))):
        _f_ = _ns.get(_fn)
        if not callable(_f_):
            _probe_bad.append(f"{_fn} 不存在")
            continue
        try:
            _f_(*_args)
            _probe_ok.append(_fn)
        except Exception as e:
            _probe_bad.append(f"{_fn}: {type(e).__name__}: {str(e)[:80]}")
    chk(not _probe_bad,
        f"{len(_probe_ok)} 个渲染函数能真跑（失败：{_probe_bad[:2]}）")
# 把真的 streamlit 还回去，不然后面的 AppTest 会炸
if _saved_st is not None:
    sys.modules["streamlit"] = _saved_st

# （c）维度说人话的依赖必须在
for _n in ("DIM_NAMES", "DIM_PLAIN", "DIM_WEIGHT"):
    chk(_n in _ns, f"{_n} 已内联（卡片说人话要用它）")
chk(len(_ns.get("DIM_PLAIN") or {}) == 7,
    f"DIM_PLAIN 有 7 条（{len(_ns.get('DIM_PLAIN') or {})}）")

# （d）出处逐条能出
if "sources_rows" in _ns:
    _bn = _ns["BY_NAME"]
    _f.marked.clear()
    _ns["sources_rows"](_bn["软件工程"])
    _txt = "\n".join(_f.marked)
    chk("教育部" in _txt, "出处里有教育部目录")
    chk("学职平台" in _txt, "出处里有学职平台")
    chk("学信网" in _txt, "出处里有学信网")
    chk("个人判断" in _txt, "把别人的判断单独标出来")
else:
    chk(False, "sources_rows 不存在")

L.append("")
L.append("=== 6. 课堂展示局（7 步）===")
# 【为什么这一节要单独测】
# 目标是「可用于 10月12日课堂展示」。展示局里任何一处引用的数字写错，
# 台下不会有人纠正你，但你会当场说错话。所以**讲解里引用的数必须回查库**。
_wt = _ns.get("WALKTHROUGH")
chk(bool(_wt), "WALKTHROUGH 存在")
if _wt:
    chk(len(_wt) == 7, f"{len(_wt)} 步")
    _bn = _ns["BY_NAME"]
    for _i, _st in enumerate(_wt, 1):
        _m = _bn.get(_st["major"])
        chk(_m is not None, f"第 {_i} 步「{_st['major']}」在库里")
        chk(bool(_st.get("say")) and bool(_st.get("point")),
            f"第 {_i} 步有讲解词和要点")
        chk(len(_st.get("point") or "") >= 30,
            f"第 {_i} 步的要点够具体（{len(_st.get('point') or '')} 字）")

    # 逐条核对讲解里引用的关键数字 —— 说错一个就是当场翻车
    _d = _bn["计算机科学与技术"]["dims"]
    chk(_d[2] == 1, f"计算机「细节分辨」确实是 1（实际 {_d[2]}）")
    chk(_d[4] == 5, f"计算机「自驱」确实是 5（实际 {_d[4]}）")

    _ma, _cs = _bn["数学与应用数学"], _bn["计算机科学与技术"]
    chk(_ma["cost_feedback_months"] == 18,
        f"数学反馈确实是 18 个月（实际 {_ma['cost_feedback_months']}）")
    chk(_cs["cost_feedback_months"] == 1,
        f"计算机反馈确实是 1 个月（实际 {_cs['cost_feedback_months']}）")
    chk(sum(1 for x in _ma["dims"] if x == 5) == 4,
        f"数学七项里四项是 5（实际 {sum(1 for x in _ma['dims'] if x == 5)}）")
    # 【这一条是我写错过的地方】讲解稿原来写「五项都是 5」，
    # 实际是四项。**上台说错数字，台下不会有人纠正你。**
    # 所以讲解里出现的每个数都要在这里回查一次。
    chk("四项都是 5" in _wt[1]["point"], "讲解稿说的是「四项」，与数据一致")

    _ar = _bn["建筑学"]
    chk(_ar["cost_hours"] == 55 and _ar["cost_feedback_months"] == 36
        and _ar["cost_reversible"] is False,
        f"建筑学 55h/36月/不能回头（实际 {_ar['cost_hours']}h/"
        f"{_ar['cost_feedback_months']}月/{_ar['cost_reversible']}）")
    chk(not _ar.get("cost_templated"), "建筑学的代价是访谈核实的，不是模板")

    _cl = _bn["临床医学"]
    chk(_cl["cost_years"] == 10 and _cl["cost_feedback_months"] == 84
        and _cl["cost_reversible"] is False,
        f"临床医学 10年/84月/不能回头（实际 {_cl['cost_years']}年/"
        f"{_cl['cost_feedback_months']}月）")

    _hy = _bn["汉语言文学"]
    _hs = _hy.get("chsi_sat") or {}
    _jt = [v for v in _hs.get("dims", {}).values() if v["name"] == "就业"]
    chk(_hy["rating"]["stars"]["find_job"] == 1,
        "汉语言文学材料①找工作确实是 1 星")
    chk(_jt and _jt[0]["count"] >= 100000,
        f"官方就业满意度票数 ≥10 万（实际 {_jt[0]['count'] if _jt else 0:,}）")
    chk(_jt and _jt[0]["rank"] == 4.0,
        f"官方就业满意度确实是 4.0（实际 {_jt[0]['rank'] if _jt else 0}）")

    _se = _bn["软件工程"]
    chk(_se["rec_index"]["v"] == 3, "软件工程推荐指数确实是 3 星")
    chk(_se["rating"]["stars"]["find_job"] == 5,
        "软件工程找工作确实是 5 星")

    _zn = _bn["智能医学工程"]
    _zs = _zn.get("chsi_sat") or {}
    chk(_zs.get("total") == 79, f"智能医学工程确实 79 票（实际 {_zs.get('total')}）")
    chk(sum(1 for x in _zs.get("dims", {}).values()
            if x["rank"] == 4.2) >= 1, "它确实有一项 4.2")

    # ── 通用回查：讲解稿里每个「数字+单位」都必须能在数据里找到 ──
    # 【为什么要自动做这件事】
    # 我手写讲解稿时把数学的「四项都是 5」写成了「五项」。
    # 一个个手工核对迟早会漏，而且**上台说错数字没人纠正你**。
    #
    # 【第一版这个检查太笨】它只拿本步主角去对。但第 2 步的
    # 「（计算机是 1 个月）」说的是**另一个专业**的数，于是误报。
    # 所以现在：把整段文字里点名的**所有专业**都算进来，数对得上任何一个就算过。
    import re as _re
    _trouble = []
    for _i, _st in enumerate(_wt, 1):
        _txt = _st["say"] + " " + _st["point"]
        # 文字里提到了哪些专业？含本步主角。
        # 【还得认简称】第 2 步写的是「（计算机是 1 个月）」，
        # 不是「计算机科学与技术」——按全名找会漏掉它。
        _scope = [bn_n for bn_n in _bn
                  if bn_n and (bn_n in _txt or bn_n[:3] in _txt)]
        _shot = {**{n: _bn[n] for n in _scope}, _st["major"]: _bn.get(_st["major"])}
        _shot = {k: v for k, v in _shot.items() if v}
        for _num, _unit in _re.findall(
                r"(\d+(?:\.\d+)?)\s*(个月|小时|年|分|星|人|万)", _txt):
            _v = float(_num)
            _ok = False
            for _m in _shot.values():
                if _unit == "个月" and _m.get("cost_feedback_months") == _v:
                    _ok = True
                elif _unit == "小时" and _m.get("cost_hours") == _v:
                    _ok = True
                elif _unit == "年" and _m.get("cost_years") == _v:
                    _ok = True
                elif _unit == "分":
                    if str(int(_v)) in str(_m.get("dims") or []):
                        _ok = True
                    if any(x["rank"] == _v for x in
                           (_m.get("chsi_sat") or {}).get("dims", {}).values()):
                        _ok = True
                elif _unit == "星":
                    if any(x == _v for x in ((_m.get("rating") or {})
                                            .get("stars", {}) or {}).values()):
                        _ok = True
                    if _v == ((_m.get("rec_index") or {}).get("v")):
                        _ok = True
                elif _unit == "人":
                    if _v == ((_m.get("chsi_sat") or {}).get("total")):
                        _ok = True
                elif _unit == "万":
                    if _v * 10000 <= ((_m.get("chsi_sat") or {})
                                      .get("total") or 0):
                        _ok = True
                if _ok:
                    break
            if not _ok:
                _trouble.append(f"第{_i}步「{_num}{_unit}」对不上"
                                f"（已查 {list(_shot)}）")
    chk(not _trouble,
        f"讲解稿里每个数字都能回查（{len(_trouble)} 处对不上：{_trouble[:3]}）")

L.append("")
L.append("=== 7. 展示局真走一遍 ===")
# 【为什么这一步不能只看数据】
# 上一节的校验证明**数字对**，但证明不了**点得动**。
# 按钮错位、rerun 丢状态、侧栏和主区打架，都只有真走一遍才知道。
_w = _at_main
_w.run()
_radios = [r for r in _w.radio if r.key == "mode_switch"]
chk(len(_radios) == 1, f"有模式开关（按 key 找到 {len(_radios)} 个）")
if _radios and "课堂展示（7 步）" in (_radios[0].options or []):
    _radios[0].set_value("课堂展示（7 步）").run()
    chk(len(_w.exception) == 0,
        f"切到展示模式零异常"
        + (f"：{str(_w.exception[0].value)[:140]}" if _w.exception else ""))
    _b = blob(_w)
    chk("第 1 / 7 张" in _b, "显示「第 1 / 7 张」")
    chk("计算机科学与技术" in _b, "第 1 张打的是计算机科学与技术")

    # 侧栏要有讲解词，主区要没有（观众不该看到小抄）
    _sb = "\n".join(str(getattr(e, "value", "") or "")
                    for e in _w.sidebar.markdown)
    chk("可以这么说" in _sb, "侧栏有讲解词")
    chk("可以这么说" not in _b.replace(_sb, ""),
        "讲解词不在主区（观众看不到小抄）")

    # 一路点到底
    _seen = []
    for _i in range(1, 8):
        _b2 = blob(_w)
        _seen.append(_i)
        _label = "下一张 →" if _i < 7 else "收场"
        _btns = [x for x in _w.button if x.label == _label]
        if not _btns:
            chk(False, f"第 {_i} 步找不到「{_label}」按钮")
            break
        _btns[0].click().run()
        if _w.exception:
            chk(False, f"第 {_i} 步点击后报错："
                       f"{str(_w.exception[0].value)[:140]}")
            break
        if _i < 7:
            chk(f"第 {_i + 1} / 7 张" in blob(_w),
                f"点「下一张」走到了第 {_i + 1} 张")
    else:
        chk(True, "七步走完，每一步都点得动")
    # 收场后应回到逛模式
    _b3 = blob(_w)
    chk("志业镜 · 牌局" in _b3, "「收场」回到浏览模式")
else:
    chk(False, "模式开关里没有「课堂展示（7 步）」")

L.append("")
L.append("=== 8. 出口（职业那一侧）===")
# 目标是「卡片=专业、职业=出口」。出口原来只是一串职位名，
# 现在要能点开看到学历要求、重要课程、上升路径、薪酬结构。
# **这些数据在 _occ_detail.json 里一直有，只是没接进来。**
occ_block = _ns.get("occupations_block")
chk(callable(occ_block), "occupations_block 存在")
chk("OCC" in _ns and len(_ns.get("OCC") or {}) > 90,
    f"职业数据已内联（{len(_ns.get('OCC') or {})} 条）")
chk(len(_ns.get("OCC_ALIAS") or {}) > 200,
    f"职业别名表已建（{len(_ns.get('OCC_ALIAS') or {})} 个名字）")

def capture(fn, *args):
    """调 fn，把它写出的文字收回来。

    【为什么这里收的是 _f，而不是打补丁到 streamlit 模块】
    装配后的文件在 exec 时把当时的 streamlit 绑成了自己的全局 `st`。
    第 5 节为了让 exec 能跑，`sys.modules["streamlit"]` 换成了假对象 _f，
    之后就算把真模块还回 sys.modules，**`ns["st"]` 仍然是 _f**。
    我先前想用「给真 streamlit 打补丁」来收，结果 buf 永远是空的——
    因为那段代码根本没往真模块里写。

    而且这些本来就是既成的行为，所以直接读 _f 的账本最准。
    """
    _f.marked.clear()
    _f.captions.clear()
    fn(*args)
    # expander 的标题也要算，学历要求 / n_majors 就写在标题里
    return "\n".join(_f.marked) + "\n" + "\n".join(_f.captions)


if callable(occ_block):
    # ── 一个有官方登记的专业 ──
    _all = capture(occ_block, _ns["BY_NAME"]["软件工程"])
    # 把收到的文字记进报告，出问题时能直接看，不用再猜
    L.append(f"    [capture 收到 {len(_all)} 字]")
    for _ln in _all.split("\n")[:6]:
        L.append(f"      | {_ln[:110]}")
    L.append("      …（尾部）")
    for _ln in _all.split("\n")[-6:]:
        L.append(f"      | {_ln[:110]}")
    L.append(f"      「自评」在不在: {'自评' in _all}　"
             f"「薪酬满意度」在不在: {'薪酬满意度' in _all}")
    L.append(f"      ns['st'] is _f: {_ns.get('st') is _f}　"
             f"captions 条数 {len(_f.captions)}　"
             f"含「自评」的条数 {sum('自评' in x for x in _f.captions)}")
    for _i, _c in enumerate(_f.captions):
        L.append(f"        C{_i:>2}| {_c[:100]}")
    chk("学职平台" in _all, "标了出处")
    chk("考研" not in _all.split("另外还登记了")[0],
        "「考研」没混进职业列表（它不是职业，是去向）")
    chk("学历要求" in _all, "出口带学历要求")
    chk("重要的大学课程" in _all, "出口带「重要的大学课程」")
    chk("往上走的路径" in _all, "出口带上升路径")
    chk("薪酬怎么算的" in _all, "出口带薪酬结构")
    chk("这是自评，不是钱数" in _all, "薪酬说明是自评、不编数字")
    chk("个专业通向它" in _all or "特征出口" in _all,
        "说了这个出口有多宽（n_majors）")
    chk("学信网" in _all or "学职平台" in _all, "出口标了官方出处")

    # ── 官方没登记、但有 car 的：要兜底，且说清是推的 ──
    _bare = next((x for x in _ns["MAJORS"]
                  if not (x.get("chsi_jyfx") or [])
                  and (x.get("car") or [])), None)
    if _bare:
        _tt = capture(occ_block, _bare)
        chk("官方没登记" in _tt or "查不到这个专业" in _tt,
            f"（{_bare['n']}）如实说官方没记录")
        chk("是推的" in _tt or "不是官方登记" in _tt,
            "而且说清是推的、不是官方数据")
        chk(len(_tt) > 80, "用 car 兜底出内容，不是空着")
        # 【不许给一个点不动的列表】
        # 这 15 个专业在职业库里一条都查不到。原来会渲染出一串
        # 「这个职业没有独立页」——看着热闹，点开什么都没有。
        # 这种情况必须换一种说法，并且给出用户自己能验证的动作。
        _pointable = [j for j in (_bare.get("car") or [])
                      if j not in _ns["NOT_JOBS"]
                      and _ns["_occ_lookup"](j)]
        if not _pointable:
            chk("没有独立页" not in _tt,
                "一个都点不开时，不再刷一串「没有独立页」")
            chk("招聘网站" in _tt or "自己" in _tt,
                "而是给一个用户自己能做的验证动作")
    else:
        chk(False, "找不到「官方没登记但有 car」的专业")

    # ── 一份来源都没有的：如实空着 ──
    _none = next((x for x in _ns["MAJORS"]
                  if not (x.get("chsi_jyfx") or [])
                  and not (x.get("car") or [])), None)
    if _none:
        _t2 = capture(occ_block, _none)
        chk("不编" in _t2, f"（{_none['n']}）什么都没有时如实空着")
    else:
        chk(True, "库里没有「两份来源都空」的专业，跳过这一条")

    # ── 查不到职业页的，不许硬凑 ──
    #
    # 【这条原来太松，正好放过我这一轮要修的东西】
    # 原来写的是 `chk("没有独立页" in _tt or "学职平台上" in _tt, ...)`。
    # 但出口名单里「查不到」其实是**两种完全不同的情况**：
    #   ① 平台登记过这个职业、只是没做详情页（在 OCC_NODETAIL 里，
    #      59 个，比如「项目专员/助理」46 个专业通向它）
    #   ② 连平台都没登记，或者名字口径对不上
    # 原来两种都印同一句「没有独立页」——**把①这条官方信息降级成了缺口**，
    # 还丢掉了「N 个专业通向它」这个平台自己登记的数字。
    # 所以断言必须分开查，否则两类合并、哪种错法都能过。
    _miss = next((x for x in _ns["MAJORS"]
                  if any(j not in _ns["OCC_ALIAS"]
                         for j in (x.get("chsi_jyfx") or []))), None)
    if _miss:
        _tt = capture(occ_block, _miss)
        _nid = _ns["OCC_NODETAIL"]
        _its = [j for j in (_miss.get("chsi_jyfx") or [])
                if j not in _ns["OCC_ALIAS"]]
        _known = [j for j in _its if j in _nid]
        _blank = [j for j in _its if j not in _nid]
        chk("没有独立页" in _tt or "还没做详情页" in _tt,
            f"查不到职业页的（{_miss['n']}）说明为什么没有详情")
        if _known:
            # ① 平台登记过 → 必须说出「多少个专业都能走到这」
            chk("还没做详情页" in _tt and "个专业都能走到这" in _tt,
                f"（{_miss['n']}）平台登记过、只是没详情页的，"
                f"要说清它其实是一条通用出口（例：{_known[0]}）")
            chk("通用出口" in _tt,
                "并且提醒这是一条通用出口，不是这个专业的特征出口")
        if _blank:
            # ② 连平台都没有 → 不许硬说「平台没做详情页」
            chk(True, f"（{_miss['n']}）有 {len(_blank)} 个名字"
                      f"连官方职业库都没登记（例：{_blank[0]}）")
    else:
        chk(True, "所有就业方向都有职业页，跳过这一条")

    # ── OCC_NODETAIL 这张表本身 ──
    # 【为什么要单独验它】
    # 它决定「没详情页」这句话说不说得出口。
    # 如果它是空的，上面那条分支永远走不到，
    # 而断言会因为 `if _known` 为假**静默跳过**——看着绿，其实没测。
    _nid_all = _ns["OCC_NODETAIL"]
    chk(len(_nid_all) == 59,
        f"无详情职业表有 {len(_nid_all)} 个名字（应为 59）")
    _top = max(_nid_all.items(), key=lambda kv: len(kv[1]))
    chk(_top[0] == "项目专员/助理" and len(_top[1]) == 46,
        f"最宽的一条是「{_top[0]}」（{len(_top[1])} 个专业通向它）")
    chk(all(isinstance(v, list) for v in _nid_all.values()),
        "每个值都是专业名清单（不是数字）——用来判「你是其中之一」")

    # ── 课程对账：指标必须真的有区分度 ──
    # 【为什么要测这个】
    # 我第一版算的是「职业要求的课里，有几门不在本专业课程表上」，
    # 结果 1189 个组合**全部**报「你缺课」。一个永远报同一边的指标，
    # 等于什么都没说，而且在台上会显得很唬人。
    # 所以这里不看某一句话，看**整个分布**：认领率既不能全是 0，
    # 也不能全是满的，否则说明口径没对齐，这个指标不该给用户看。
    _split = _ns["_split_courses"]
    _ov = _ns["_course_overlap"]
    _rates = []
    for _m in _ns["MAJORS"]:
        _own = set(str(c) for c in (_m.get("core") or []))
        for _c in (_m.get("core_s") or "").replace("、", " ").split():
            if _c:
                _own.add(_c)
        if not _own:
            continue
        for _j in (_ns["_career_items"](_m)[0]):
            if _j in _ns["NOT_JOBS"]:
                continue
            _r = _ns["_occ_lookup"](_j)
            if not _r or not _r.get("courses"):
                continue
            _cs = _split(_r["courses"])
            if _cs:
                _rates.append(sum(_ov(c, _own) for c in _cs) / len(_cs))
    if _rates:
        _zero = sum(1 for x in _rates if x == 0) / len(_rates)
        _avg = sum(_rates) / len(_rates)
        L.append(f"    课程对账 {len(_rates)} 个组合："
                 f"全对不上 {_zero*100:.0f}%　平均认领 {_avg*100:.0f}%")
        chk(_zero < 0.95,
            f"「一门都对不上」不能是绝大多数（实际 {_zero*100:.0f}%）")
        chk(_avg > 0.03,
            f"平均认领率不能约等于 0（实际 {_avg*100:.1f}%）")
        chk(_avg < 0.9,
            f"平均认领率也不能接近满（实际 {_avg*100:.1f}%），"
            "否则说明口径已经对齐，这个指标没区分度")
    else:
        chk(False, "一个可对账的组合都没有")

L.append("")
L.append("=== 9. 课堂问答：直接跳到某个专业 ===")
# 【为什么两张页面都要有】
# 七步走完，老师问「那你看看临床医学」——这时候应用停在**结尾页**，
# 不是选牌页。只在选牌页放跳转，等于问答的那一刻它不在。
# 我第一版就只放了选牌页，测试找不到才发现。
chk(callable(_ns.get("jump_to_major")), "跳转抽成了函数（两张页面共用）")

_mode = [x for x in at.radio if x.key == "mode_switch"]
L.append(f"    [mode radio: {[(x.key, x.value) for x in at.radio]}]")
_s = at.session_state.filtered_state.get("s") or {}
L.append(f"    [当前页: s['mode'] = {_s.get('mode')!r}]")

# （a）结尾页也要有
# 【先把应用整个换成「牌已经发完」的状态】
# filtered_state 是拷贝，改它里面的字典不生效——**要整个对象替换**。
at.session_state["s"] = {
    "pool": ["计算机科学与技术"], "idx": 1, "deck": ["计算机科学与技术"],
    "passed": [], "nays": [], "notes": {}, "mode": "meet", "step": 0,
    "asked": {}, "ask": "keep", "heard": "", "last_major": "计算机科学与技术"}
at.run()
_end_jump = [x for x in at.selectbox if "跳到" in (x.label or "")]
L.append(f"    [结尾页：mode="
         f"{(at.session_state.filtered_state.get('s') or {}).get('mode')!r}"
         f"　selectbox={[x.label for x in at.selectbox]}]")
chk(len(_end_jump) == 1,
    f"结尾页有跳转入口（找到 {len(_end_jump)} 个，label="
    f"{[x.label for x in at.selectbox]}）")

# （b）选牌页也要有
_mode = [x for x in at.radio if x.key == "mode_switch"]
if _mode and _mode[0].value != "随便逛":
    _mode[0].set_value("随便逛").run()
_back0 = [x for x in at.button
          if "换个门类" in (x.label or "") or "回选牌页" in (x.label or "")]
if _back0:
    _back0[0].click()
    at.run()
_jump = [x for x in at.selectbox if "跳到" in (x.label or "")]
L.append(f"    [选牌页：按钮 {[x.label for x in at.button][:5]}　"
         f"selectbox {[x.label for x in at.selectbox]}]")
chk(len(_jump) == 1, f"选牌页也有跳转入口（找到 {len(_jump)} 个）")

if _jump:
    _opts = list(_jump[0].options or [])
    _n = len(_ns["MAJORS"])
    chk(len(_opts) == _n + 1,
        f"选项 = 全部 {_n} 个专业 + 占位（实际 {len(_opts)} 项）")
    chk(_opts[0] == "—", "第一项是占位，默认不跳")
    # 真跳一次：选中一个专业，看是不是只翻那一张
    if "临床医学" in _opts:
        _jump[0].set_value("临床医学").run()
        # 【跳转进的是「它先开口」，不是直接甩一张卡】
        # 课堂问答时老师说「那你看看临床医学」，直接出卡是冷场；
        # 让它先问一句，台上好接。所以这里要确认它**先开口**，
        # 再走过那一轮看牌。
        _b = blob(at)
        chk("志业镜" in _b and ("？" in _b or "?" in _b),
            "跳过去之后它先问一句，而不是直接甩卡")
        chk("临床医学" in _b or "给我看张牌" in _b,
            "跳转确实进了这个专业的流程")
        step_on(at, "给我看张牌")
        _b2 = blob(at)
        chk("临床医学" in _b2, "走过一轮之后卡片就是它")
        chk("第 1 / 1 张" in _b2,
            "跳过去只翻这一张（不是把它插进原来的队列）")
        chk(len(at.exception) == 0, "跳转过程零异常")
        # 【这一条是防死循环的】
        # selectbox 的控件状态会一直留着「临床医学」。翻完回到选牌页时
        # 它还在，如果不看「值有没有变」，就会立刻又跳一次——
        # 用户会以为自己回不去了。
        _back = [x for x in at.button if "换门类" in (x.label or "")]
        if _back:
            _back[0].click()
            at.run()
            chk(len(at.exception) == 0, "从跳转回到选牌页零异常")
            chk("志业镜 · 牌局" in blob(at),
                "回到选牌页后停住了，没有又被弹回那张卡")
    else:
        chk(False, "选项里没有临床医学")

L.append("")
L.append("=== 10. 出处必须逐条 ===")
# 目标是「数据以官方源为准并逐条标注出处」。
# 这里不看某句话写得漂不漂亮，看**卡片上的每一类事实有没有对应的来源行**。
if callable(_ns.get("sources_rows")):
    _sw = capture(_ns["sources_rows"], _ns["BY_NAME"]["软件工程"])
    for _what in ("分类·代码·学位", "就业方向", "出口详情",
                  "四维满意度", "三维星级", "推荐指数"):
        chk(_what in _sw, f"出处里有「{_what}」这一行")
    # 评级是人的判断，不能和官方数据混在一栏里
    chk("个人判断·不是数据" in _sw, "评级标明是个人判断，不是数据")
    chk("官方·学生自评" in _sw, "满意度标明是学生自评")
    chk("自评，不是钱数" in _sw, "薪酬相关标明是自评、不是钱数")

    # 【这一条是补一个真 bug】
    # sources_rows 原来只在 chsi_jyfx 有值时给「就业方向」出来源。
    # 那 16 个官方零记录的专业用的是库里整理的 car——
    # 于是它们列了出路，却在「来源与底细」里**一句出处都没有**。
    _bare2 = next((x for x in _ns["MAJORS"]
                   if not (x.get("chsi_jyfx") or [])
                   and (x.get("car") or [])), None)
    if _bare2:
        _sw2 = capture(_ns["sources_rows"], _bare2)
        chk("就业方向" in _sw2,
            f"（{_bare2['n']}）列的出路也有出处行")
        chk("不是官方登记" in _sw2 or "整理" in _sw2,
            "而且说明那不是官方登记")
        # 出口一个都点不开的专业不该出现「出口详情」这一行
        if not [j for j in (_bare2.get("car") or [])
                if j not in _ns["NOT_JOBS"]
                and _ns["_occ_lookup"](j)]:
            chk("出口详情" not in _sw2,
                "一个职业都点不开时，不虚报「出口详情」这个来源")

L.append("")
L.append("=== 11. 出口必须真的上过台 ===")
# 目标是「卡片=专业、职业=出口」。但出口原来是卡片里的一个折叠页签，
# 投影时台下只看到一条页签栏——**出口如果从头到尾没上过台，这一半就白做了。**
# 所以七步的主区里要把出口摊开，侧栏也要有对应的话。
for _i, _st in enumerate(_wt, 1):
    chk(_st.get("exit_note"), f"第 {_i} 步有出口批注")
    _m = _bn.get(_st["major"])
    if not _m:
        continue
    _items, _how = _ns["_career_items"](_m)
    _jobs = [j for j in _items if j not in _ns["NOT_JOBS"]]
    _pts = [j for j in _jobs if _ns["_occ_lookup"](j)]
    if _pts:
        chk(True, f"第 {_i} 步（{_st['major']}）有 {len(_pts)} 个可点出口")
    else:
        # 一个都点不开的专业，批注必须说清这件事
        chk("查不到" in _st["exit_note"] or "空" in _st["exit_note"],
            f"第 {_i} 步（{_st['major']}）出口为空，批注要说明")

# 真走一遍：主区要出现「它通向哪」，而且带学历信息
_mode2 = [x for x in at.radio if x.key == "mode_switch"]
if _mode2 and _mode2[0].value != "课堂展示（7 步）":
    _mode2[0].set_value("课堂展示（7 步）").run()
_demo = blob(at)
chk("它通向哪" in _demo, "展示模式主区有「它通向哪」")
chk("学历" in _demo, "主区出口带学历要求")
chk("没有结构化薪资数字，我不编" in _demo,
    "主区说明薪酬为什么不给金额")
chk(len(at.exception) == 0, "展示模式渲染出口零异常")

# 侧栏讲解词里也要有出口那一段（不然台上不知道什么时候往主区看）
_panel = "\n".join(str(getattr(e, "value", "") or "")
                   for e in at.sidebar.markdown)
chk("它通向哪" in _panel or "可以这么说" in _panel,
    "侧栏讲解词里有出口那一段")

L.append("")
L.append("=== 12. 官方目录对齐（2026 版）===")
# 【为什么要有这一节】
# 这一轮我发现：应用里写着「分类来自教育部《本科专业目录》」，
# 但库里的分类是旧的一版，而官方已经更新到 13 个门类 / 93 个专业类 /
# 883 个专业，**新增了「交叉学科」门类**。
# 界面写着「来自官方目录」而目录已过期，比不写更糟。
#
# 更糟的是我核对时连错两次：第一次拿 `set([None,…])` 当官方专业名，
# 得出「163 个全部命中」（假通过）；第二次用错字段名，得出
# 「163 个全部不在目录」（假失败）。**两次结论都是废的。**
# 所以现在把核对固化成测试，用真数据跑。
_e2026 = json.load(open("_official_2026_tree.json", encoding="utf-8"))
_off = {}
for _gn, _d in _e2026.items():
    for _cn, _cd in _d["classes"].items():
        for _x in _cd["majors"]:
            _off[_x["name"]] = (_gn, _cn, _x["code"])
chk(len(_off) == 883, f"官方 2026 索引建起来了（{len(_off)} 个专业）")
chk(len(_e2026) == 13, f"官方有 13 个门类（实际 {len(_e2026)}）")

_ismajor = [m for m in _ns["MAJORS"] if m["n"] in _off]
_isclass = [m for m in _ns["MAJORS"] if m["n"] not in _off]
L.append(f"    库内 {len(_ns['MAJORS'])} 条：{len(_ismajor)} 条是真专业，"
         f"{len(_isclass)} 条不是")
# 【这条原来写的是「绝大多数（>=160）」】
# 那是给自己留的余地，而余地正好掩盖了「有两张牌根本不是专业」这件事。
# 现在要求 100%：库里的每一张牌，名字都必须是官方目录里的真专业。
chk(not _isclass, f"每一张牌的名字都是官方目录里的真专业"
                  f"（{len(_isclass)} 条不是：{[m['n'] for m in _isclass]}）")
# 曾经被误当成专业的两个「专业类」名，必须真的没了
for _bad in ("公安学", "新闻传播学"):
    chk(all(m["n"] != _bad for m in _ns["MAJORS"]),
        f"「{_bad}」是专业类名，已经不在牌堆里")

# 门类/专业类/代码三项必须和官方一致
_bad = []
for _m in _ismajor:
    _gn, _cn, _code = _off[_m["n"]]
    if _cn == "-":
        _cn = "交叉工程类"          # 官方的数据 bug，见 _sync2026.py
    if (_m["gate"], _m["专业类"], _m.get("code")) != (_gn, _cn, _code):
        _bad.append((_m["n"], f"{_m['gate']}/{_m['专业类']}/{_m.get('code')}",
                     f"{_gn}/{_cn}/{_code}"))
chk(not _bad, f"门类·专业类·代码三项全对（{len(_bad)} 条不符：{_bad[:3]}）")

# 界面上写的官方总数，必须等于真实总数——手写的数字会过期。
# 【这里也对比着官方树算，不再抄第二份 883/13/93】
_off_gates = len(_e2026)
_off_classes = sum(len(d["classes"]) for d in _e2026.values())
_cm = _ns.get("CATALOG") or {}
chk(_cm.get("n_majors") == len(_off)
    and _cm.get("n_gates") == _off_gates
    and _cm.get("n_classes") == _off_classes,
    f"CATALOG 里的官方总数 = 官方树算出来的"
    f"（{_cm.get('n_gates')}/{_cm.get('n_classes')}/{_cm.get('n_majors')}）")
# 门类清单里必须有「交叉学科」，而且牌堆里真的有它的牌
chk("交叉学科" in _ns["GATES"], "门类清单里有「交叉学科」")
_x = [m for m in _ns["MAJORS"] if m["gate"] == "交叉学科"]
chk(len(_x) >= 2, f"交叉学科门类下有牌（{len(_x)} 张："
                  f"{[m['n'] for m in _x]}）")
# 【新检查：不能有空门类】
# 删掉两张牌之后，「公安学类」这类归属会不会留下一整个空门类？
# 界面上的门类下拉如果有一个点进去是空的，那不是「简洁」，那是坏掉。
_empty = [g for g in _ns["GATES"]
          if not any(m["gate"] == g for m in _ns["MAJORS"])]
chk(not _empty, f"没有空门类（空的：{_empty}）")
chk(len(_ns["GATES"]) == _off_gates,
    f"应用里的门类数 = 官方门类数（{len(_ns['GATES'])}）")

# 结尾页那段「底细」必须把这些事实说出来，而且数字要和 CATALOG 一致。
# 【不能靠 blob(at)】第 11 节把应用切到展示模式了，结尾页那时候没渲染。
# 我第一版就是这么误报的。
# 所以把结尾页抽成了 end_page(s)，这里直接把它跑出来。
_end_fn = _ns.get("end_page")
chk(callable(_end_fn), "结尾页抽成了函数（可以单独核对）")
if callable(_end_fn):
    _sx = _ns["new_state"]()
    _sx["mode"] = "end"
    _be2 = capture(_end_fn, _sx)
    chk("本科专业目录" in _be2, "结尾页说明分类来自官方目录")
    chk(f"{_cm.get('n_majors')} 个专业" in _be2,
        f"结尾页写明官方目录 {_cm.get('n_majors')} 个专业（不是手写的旧数字）")
    chk(f"{_cm.get('n_gates')} 个门类" in _be2,
        f"结尾页写明官方目录 {_cm.get('n_gates')} 个门类")
    # 已经删掉「专业类名当专业」那两条，所以那段话也该跟着消失——
    # 界面不该还在说一件已经不成立的事。
    chk("不是专业名" not in _be2,
        "结尾页不再提「名字其实是专业类名」这件已经修好的事")
    # 已有的边界说明不能在重构里丢掉
    for _t in ("没有选科要求数据", "联网查证"):
        chk(_t in _be2, f"结尾页仍然写着「{_t}」")

    # 【回归：deck 里出现库里没有的名字，不许把整页带走】
    # 这一条是我核「稿子承诺 vs 应用」时真撞见的：
    # `s["deck"]` 存在状态里，库是另一份东西。专业改名或撤掉之后，
    # 结尾页会在 `BY_NAME[nm]` 上抛 KeyError ——**而这是整局的最后一步**，
    # 等于走到终点才崩，而且崩在用户收了一堆牌、最期待结果的那一刻。
    # 实测：修之前这一屏只渲染出 316 字符（停在第一张卡）；
    #       修之后 1525 字符，未知名字单独说明。
    _sx2 = _ns["new_state"]()
    _sx2["mode"] = "end"
    _sx2["deck"] = ["临床医学", "这个专业不存在"]
    _sx2["passed"] = []
    _sx2["nays"] = []
    _be3 = capture(_end_fn, _sx2)
    chk("KeyError" not in _be3, "deck 里有未知名字时结尾页不抛异常")
    chk("这个专业不存在" in _be3,
        "deck 里的未知名字被如实说出来（不是静默丢掉）")
    chk("底细" in _be3,
        "有一个未知名字，结尾页的「底细」那一段仍然渲染出来")

    # 【回归：收下的专业和「能怎么试一下」不许错位】
    # 原来是 `zip(s["deck"], acts)`，而 acts 只收了 act_s 非空的那些，
    # 两个列表长度不一样 —— **zip 会把名字和事情配错**：
    # 出现「计算机：访谈一位建筑师」这种。改成按名字现查之后，
    # 每一行「- **专业**：事情」里的专业必须有那件事。
    _sx3 = _ns["new_state"]()
    _sx3["mode"] = "end"
    _sx3["deck"] = ["临床医学", "哲学", "建筑学"]
    _sx3["passed"] = []
    _sx3["nays"] = []
    _be4 = capture(_end_fn, _sx3)
    _pairs = _re.findall(r"^- \*\*(.+?)\*\*：(.+)$", _be4, _re.M)
    _byk = {m["n"]: m for m in _ns["MAJORS"]}
    _wrong = [(n, a) for n, a in _pairs
              if _byk.get(n, {}).get("act_s")
              and _byk[n]["act_s"].strip() != a.strip()]
    chk(not _wrong,
        f"「能怎么试一下」和专业名字对得上（错位的：{_wrong[:2]}）")
    L.append(f"    结尾页列了 {len(_pairs)} 条「专业：能怎么试」")

# 【覆盖度必须在界面上说】
# 官方 883 个专业，我只有 161 张牌。不说的话用户会以为
# 「搜不到 = 这个专业不存在」。但也不能只说个 161/883——
# 那个数字看起来像完成度，而真正要说的是：
# **缺席的牌不是因为它不好，是因为我没做。**
# 【侧栏抽成了 sidebar(s)】原来这里读的是 at.sidebar.caption，
# 但那时应用停在展示模式，读到的是过期内容——和 end_page 一样的坑。
_side_fn = _ns.get("sidebar")
chk(callable(_side_fn), "侧栏抽成了函数（可以单独核对）")
if callable(_side_fn):
    _ss = _ns["new_state"]()
    _ss["mode"] = "roster"
    _sbt = capture(_side_fn, _ss)
    chk(str(_cm.get("n_majors")) in _sbt,
        f"侧栏说明官方目录共 {_cm.get('n_majors')} 个专业")
    chk("还没做" in _sbt or "没做" in _sbt,
        "侧栏说明缺席的牌是因为「我还没做」，不是因为这个专业不好")
    # 侧栏是老用户抱怨过啰嗦的地方，量一下
    L.append(f"    侧栏正文 {len(_sbt)} 字")
    chk(len(_sbt) < 2600, f"侧栏不啰嗦（< 2600 字，实际 {len(_sbt)}）")

L.append("")
L.append("=== 13. 它得像在跟你说话（不是收表格）===")
# 用户原话：「其实这个纸牌版也是对话形式的，就像我和你一样」
# 原来翻牌页是「看牌 → 三个按钮」，收了原因、记了笔记，**什么都不回**。
# 这一节查的就是：它真的在听，还是只是把话存起来。
_hear = _ns["hear"]
for _t, _want, _why in [
    ("不想一直背", "记忆量", "「背」要听成记忆量"),
    ("不想背", "记忆量", "「不想背」里的关键是「背」，不是「不想」"),
    ("不喜欢做实验", "动手要求", "「实验」要听成动手要求"),
    ("我太粗心了", "细节分辨", "「粗心」要听成细节分辨"),
    ("没人管我就不行", "自驱要求", "「没人管」要听成自驱要求"),
    ("我怕一直失败", "挫折耐受", "「失败」要听成挫折耐受"),
    ("等不了那么久", "慢反馈耐受", "「太久」要听成慢反馈耐受"),
    ("没人管我就不行", "自驱要求", "「没人管」要听成自驱要求"),
]:
    _d, _r = _hear(_t)
    chk(_d == _want, f"听得懂「{_t}」→ {_want}（实际 {_d}）")

# **现实约束不许进对人的判断**
for _t in ["家里不支持", "学费太贵", "成绩够不上", "太卷了", "我身体不好"]:
    _d, _r = _hear(_t)
    chk(_d is None and _r, f"「{_t}」识别为现实约束，不转成维度")

# 回话必须真的引用这张牌的事实。
# 【我第一版这里写错了】我断言输出里出现「记忆量」，
# 但那句话用的是 DIM_PLAIN 的说法「要背的东西多」——**测的是我的记性**。
# 而且计算机的记忆量是 2/5（低），本来就不该引课程；
# 该拿它测的是「高维度会引课程」。
_cs = _bn["计算机科学与技术"]
_say = _ns["say_back"](_cs, False, "不想一直背", [])
chk("要背的东西多" in _say, "回话用大白话说出那个维度")
chk("2/5" in _say, "回话给出了这张牌该维度的真实分数")
# 计算机 自驱要求=5，这一支必须引用真实课程（原来它只说空话）
_say_z = _ns["say_back"](_cs, False, "没人管我就不行", [])
chk("5/5" in _say_z, "自驱要求 5/5 如实说满")
chk("数据结构" in _say_z, "自驱要求高时也引用这张牌的真实课程")
# 低维度**不该**引课程——低就是说它不重，扯课程是转移话题
chk("数据结构" not in _say, "低维度不引课程（那是在转移话题）")
chk("不重" in _say, "该维度只有 2/5，回话如实说「不重」")

# 高维度的情况：临床医学 记忆量=5
_cl = _bn["临床医学"]
_say2 = _ns["say_back"](_cl, False, "要背的太多了", [])
chk("5/5" in _say2, "临床医学记忆量 5/5，回话如实说满")
chk("确实要" in _say2, "该维度高时承认「确实要」，不回避")

# 现实约束的回话里**不许有任何评价他的句子**
_say3 = _ns["say_back"](_cs, False, "家里不支持我学这个", [])
chk("我不会拿它去判断" in _say3,
    "对现实约束明确说「不拿它判断你」")
for _bad in ("降低目标", "换个方向吧", "你要现实一点", "不适合你"):
    chk(_bad not in _say3, f"现实约束的回话里没有「{_bad}」")

# 没听懂时**要承认没听懂**，不许敷衍
_say4 = _ns["say_back"](_cs, True, "说不上来", [])
chk("我不猜" in _say4 or "没写" in _say4 or "你没说" in _say4,
    "没听懂/没写时不编，直接说「我不猜」")
# 【「我说不清」不许被当成一种倾向】
# 这条是我自己犯过的错：加词表时把「说不上来」映射成了「自驱要求」，
# 于是**一个明确的「我不知道」被系统解读成了结论**。
for _vt in ("说不上来", "就是没感觉", "不知道", "说不清", "没有为什么"):
    _vd, _vr = _ns["hear"](_vt)
    chk(_vd is None and not _vr,
        f"「{_vt}」是「我说不清」，不许被当成维度（实际 {_vd}）")
# 但「不想背，说不上来为什么」里有真信号——**该承认没听懂，不抓那个「背」字**
_vd2, _ = _ns["hear"]("不想背，说不上来为什么")
chk(_vd2 is None, "「说不上来」优先于维度词，不硬抓那个「背」字")
_say5 = _ns["say_back"](_cs, True, "不想背，说不上来为什么", [])
chk("5/5" not in _say5 and "2/5" not in _say5,
    "「我说不清」的时候不报分数（报了就是硬盖结论）")

# 问题必须换着问，不能反复问同一句
_asked = {}
_seen = []
for _ in range(5):
    _q, _qid = _ns["pick_question"](_cs, False, _asked, _ns["new_state"]())
    _seen.append(_qid)
chk(len(set(_seen)) == len(_seen), f"5 次问的是 5 个不同问题：{_seen}")
chk(len(_seen) == 5, f"问题池至少 5 个（实际 {len(_seen)}）")

# 收下和翻过去，问的必须是不同的问题
_ak, _pk = {}, {}
_qk, _ = _ns["pick_question"](_cs, True, _ak, _ns["new_state"]())
_qp, _ = _ns["pick_question"](_cs, False, _pk, _ns["new_state"]())
chk(_qk != _qp, "「收下」和「翻过去」问的不是同一句")

# 「翻过去」那一侧的问题要问得更细——立场是排除理由比喜欢理由可靠
chk(any("不想变成" in _q or "不想要" in _q for _q in
        [_ns["pick_question"](_cs, False, {}, _ns["new_state"]())[0]]),
    "翻过去那侧问的是「不想变成哪种人」这类问题")

# 它要记得他填过什么
_sx = _ns["new_state"]()
_sx["deck"] = ["计算机科学与技术", "软件工程"]
_sx["passed"] = ["临床医学"]
_sx["nays"] = ["要背太多", "要背太多", "学制太长"]
_line = _ns["card_counts_line"](_sx)
chk("2 张" in _line, "记得他收下几张")
chk("1 张" in _line, "记得他翻过去几张")
chk("要背太多、学制太长" in _line, "报出他说的原因，且去重")
chk("要背太多、要背太多" not in _line, "同一句原因不重复报")
chk(_ns["card_counts_line"](_ns["new_state"]()) == "",
    "什么都没做时不说废话")

# 真跑一轮：它先开口那一轮必须真的渲染出问题，而且能接上一轮的话
_mt = _ns.get("meet_turn")
_dt = _ns.get("deal_turn")
chk(callable(_mt), "meet_turn 抽成了函数")
chk(callable(_dt), "deal_turn 抽成了函数")
chk("ask_turn" not in _ns,
    "旧的 ask_turn 已删除（不留没人测的旧路径）")
# 第一屏：没有牌，只有它的话和问题
_s1 = _ns["new_state"]()
_s1["pool"] = ["计算机科学与技术"]
_s1["idx"] = 0
_s1["mode"] = "meet"
_out1 = capture(_mt, _s1)
chk(len(_out1) > 40, f"它确实开口了（{len(_out1)} 字）")
chk("？" in _out1 or "?" in _out1, "开场就是一个问句")
chk("学什么" not in _out1, "**第一屏没有卡片**——牌是回应，不是开场")
chk("给我看张牌" in _out1, "有往前走看牌的按钮")
# 第二轮：带着他刚说的话，必须先出现回应，再问下一句
_s2 = _ns["new_state"]()
_s2["pool"] = ["临床医学"]
_s2["idx"] = 1
_s2["mode"] = "meet"
_s2["ask"] = "pass"
_s2["last_major"] = "临床医学"
_s2["deck"] = ["计算机科学与技术"]
_s2["passed"] = ["软件工程"]
_s2["nays"] = ["要背太多"]
_s2["asked"] = {"o:last": True, "o:better": True, "o:mad": True}
_s2["heard"] = "不想一直背，要背的东西太多"
_out2 = capture(_mt, _s2)
chk("要背的东西多" in _out2, "第二轮真的回应了上一轮说的话")
chk("5/5" in _out2, "而且给出的是这张牌的真实分数")
chk("解剖" in _out2, "而且引用了这张牌的真实课程")
chk("记得的" in _out2, "它亮出自己记得什么")
chk("要背太多" in _out2, "记得的里面包含他说过的原因")
# 【上一轮是「翻过去」，问的就该是排除那一侧】
# 这里 idx=1 但 pool 只有 1 张，所以走的是「牌发完了」那条分支。
# 排除侧的问题要在**还有牌的时候**看，所以下面单独造一个状态。
chk("一直没跟人说过" in _out2 or "不想变成" in _out2,
    "牌发完之后问的是没问过的那几个（不再重复「再问一次」兜底）")

# 还有牌的时候，且上一轮是「翻过去」→ 问排除那一侧
_s2b = _ns["new_state"]()
_s2b["pool"] = ["计算机科学与技术", "临床医学"]
_s2b["idx"] = 1
_s2b["mode"] = "meet"
_s2b["ask"] = "pass"
_s2b["last_major"] = "临床医学"
_s2b["deck"] = ["计算机科学与技术"]
_s2b["passed"] = ["软件工程"]
_s2b["nays"] = ["要背太多"]
# 【不要预填 asked】我第一版预填的 key 是 "p:who" 这种，
# 而代码生成的 key 是 "p:谁"——**对不上，于是每一问都被当成问过了，
# 全部落到「again」兜底**，我就以为是「问错了问题」。
# 正确测法是让它第一次问，看它问的是哪一侧。
_s2b["asked"] = {"o:last": True, "o:better": True, "o:mad": True}
_s2b["heard"] = ""
_out2b = capture(_mt, _s2b)
chk("不想变成" in _out2b or "不想要" in _out2b or "三分之一" in _out2b
    or "真的碰过" in _out2b,
    "翻过去之后问的是排除那一侧，不是「它哪里吸引你」")
# 反过来：上一轮是「收下」，问的该是吸引那一侧。
# 【asked 必须是独立的副本】pick_question 会就地往 asked 里写字，
# 上面那一次已经写进了排除侧的 id。我第一版让 _s2c 复用同一个 dict，
# 于是吸引侧的问题也全被当成问过了，直接落到兜底——
# **测出来的是「共享状态」，不是「它问错了」。**
_s2c = _ns["new_state"]()
_s2c["pool"] = ["计算机科学与技术", "临床医学"]
_s2c["idx"] = 1
_s2c["mode"] = "meet"
_s2c["ask"] = "keep"
_s2c["last_major"] = "临床医学"
_s2c["deck"] = ["计算机科学与技术"]
_s2c["passed"] = []
_s2c["nays"] = []
_s2c["heard"] = ""
# 【必须赋值成一个新字典】new_state() 里那个 asked 是**字面量建的、
# 每次调用都会新建**，但 dict(...) 和 update() 都可能让它跟别处共享。
# 明确赋一个新字典最稳。
_s2c["asked"] = {"o:last": True, "o:better": True, "o:mad": True}
_out2c = capture(_mt, _s2c)
# 【查 asked 账本，不查渲染出来的文本】
# 我第一版查的是「输出里有没有『哪个字』」——DEBUG 打出来
# 它**明明在**，但断言还是失败：因为那句话在渲染里被换行/加粗拆开了
# （`**具体哪几个字**`），而我的子串是「哪个字」——
# 其实能匹配……真正的原因是**这里连着几轮都在查文本，
# 而文本会被格式影响**。问句的 id 是稳定的，直接查它。
chk("k:find" in _s2c["asked"] or "k:time" in _s2c["asked"]
    or "k:nobody" in _s2c["asked"] or "k:twenty" in _s2c["asked"],
    "收下之后问的是吸引那一侧（问句 id 记在账本里）")
chk(not any(k.startswith("p:") for k in _s2c["asked"]),
    "而且没有问排除那一侧的问题")
chk(len(at.exception) == 0, "它先开口这一层渲染零异常")

# deal_turn：牌出来的时候必须真的有牌，而且给三条路
_s3 = _ns["new_state"]()
_s3["pool"] = ["计算机科学与技术"]
_s3["idx"] = 0
_s3["mode"] = "deal"
_out3 = capture(_dt, _s3)
chk("这一张" in _out3, "发牌页说「这一张，你看一下」")
chk("学什么" in _out3, "牌上有「学什么」")
chk("收下" in _out3 and "翻过去" in _out3, "有收下/翻过去")
chk("先聊两句" in _out3,
    "看牌时还能「先聊两句」——**牌局本身就是对话**")

# 翻过去要先说为什么：这是排除理由的入口
# 【「就是没感觉」不该被听出维度】它属于「我说不清」那一类，
# 所以下面把它单独排除掉。
for _k, _t in _ns["NAY"]:
    _d2, _ = _ns["hear"](_t)
    if _k == "就是没感觉":
        chk(_d2 is None, f"「{_k}」属于「我说不清」，不硬套维度")
    else:
        chk(_d2 is not None, f"原因「{_k}」能被听出一个维度（实际 {_d2}）")
chk(len(_ns["NAY"]) >= 8, f"不想要的原因至少 8 条（实际 {len(_ns['NAY'])}）")
_nay_fn = _ns.get("ask_nays")
chk(callable(_nay_fn), "ask_nays 抽成了函数")
if callable(_nay_fn):
    _s4 = _ns["new_state"]()
    _s4["pool"] = ["计算机科学与技术"]
    _s4["idx"] = 0
    _s4["mode"] = "nay"
    _out4 = capture(_nay_fn, _s4, "临床医学")
    chk("不想要的原因" in _out4, "翻过去之后问「不想要的原因」")
    chk("记下" in _out4, "能记下原因再接着聊")

# 开场问必须好回答——不能上来就问「你的兴趣是什么」
_opens = [_ns["pick_open"]({})[0] for _ in range(3)]
chk(all("兴趣" not in q for q in _opens),
    "开场问不许上来就问「你的兴趣是什么」（那是没法回答的）")
chk(any("忘了时间" in q for q in _opens),
    "开场问的是「上一次做一件事做到忘了时间」这种能回想起来的事实")

L.append("")
L.append("=== 14. 模型层：能个性化，但不许碰事实 ===")
# 用户说「也许可以把 API 加进来，方便对话个性化」。
# 个性化是模型擅长的，规则层做不到。但**事实必须还是数据库说了算**：
# 161 个专业 × 每个 40 多个字段塞不进 prompt，硬塞它就会记错、会编。
# 所以设计是：模型只拿到这一张牌的确切数字 + 用户自己说的话，
# 它负责把话说得像人话；出来过一遍事实守卫，编了数字就整条丢掉。

# ── 没有 key 时必须是规则层，而且不报错 ──
chk(isinstance(_ns["api_key"](), str), "api_key() 能调用")
chk(_ns["get_client"]("") is None, "没有 key 时不建客户端（不抛异常）")
chk(_ns["get_client"]("   ") is None, "空白 key 也当没有")

# ── 事实守卫：编的数字必须被拦下 ──
_fg = _ns["fact_guard"]
_cs = _bn["计算机科学与技术"]
_ok, _why = _fg("这张牌每周大概要花 45 小时。", _cs)
chk(_ok, f"守卫放行数据里有的数字 45（{_why}）")
_ok2, _why2 = _fg("这个专业每周要花 60 小时，很累。", _cs)
chk(not _ok2, "守卫拦下数据里没有的 60")
chk("60" in _why2, f"拦下时说明是哪个数字（{_why2}）")
# 数据里的每一个数都该放行——守卫不能把真的也拦了
_facts = _ns["facts_of"](_cs)
import re as _re2
_bad_pass = [_n for _n in _re2.findall(r"\d+(?:\.\d+)?", _facts)
             if not _fg(f"这个数字是 {_n}。", _cs)[0]]
chk(not _bad_pass, f"数据里有的数字全部放行（被误拦：{_bad_pass}）")
_ok3, _ = _fg("你说的是要背的东西多，这确实是一件要认的事。", _cs)
chk(_ok3, "不含数字的话直接放行（守卫不充当文字狱）")

# ── 给模型的「唯一事实来源」必须真的有事实 ──
chk("七维画像_每项满分5" in _facts, "prompt 里带上七维画像")
chk("每周小时" in _facts, "prompt 里带上代价数字")
chk(_cs["n"] in _facts, "prompt 里带上专业名")
import json as _json2
_fd = _json2.loads(_facts)
chk(_fd["每周小时"] == _cs.get("cost_hours"),
    "prompt 里的每周小时 = 库里的值（模型看到的就是这个数）")
# 每张牌都要能生成事实——不能有牌一到这里就崩
_nofact = [m["n"] for m in _ns["MAJORS"]
           if not _ns["facts_of"](m).strip()]
chk(not _nofact, f"161 张牌都能生成事实文本（失败的：{_nofact[:3]}）")
# 模型看不到的东西，它就不可能编——确认别名/原始女字段没被塞进去
chk("chsi_specid" not in _facts and "specid" not in _facts,
    "prompt 里不带内部字段（模型看不到就不会编）")

# ── 模型层怎么坏，都不能把产品弄死 ──
_say0 = _ns["say_back"](_cs, False, "不想一直背", [])
_r, _how = _ns["model_speak"]("", _cs, False, "不想一直背", _say0)
chk(_r == _say0, "没有 key → 原样返回规则层的话")
chk(_how == "rules", f"并标明走的是规则层（{_how}）")
_r2, _how2 = _ns["model_speak"]("sk-not-a-real-key-000", _cs, False,
                                "不想一直背", _say0)
chk(isinstance(_r2, str) and _r2, "key 无效时也不崩，仍有话可说")
chk(isinstance(_how2, str), f"标明这一轮的来源（{_how2[:40]}）")

# ── 守卫词表：替用户下结论的话不许出现 ──
for _w in ("建议你选", "不适合你", "你能力不足", "以你的条件"):
    chk(_w in _ns["BANNED"], f"「{_w}」在守卫词表里")

# ── 界面上要说清楚「模型不许碰事实」 ──
_sbt2 = capture(_ns["sidebar"], _ns["new_state"]())
chk("规则层" in _sbt2, "没接模型时如实说明在用规则层")
# 【覆盖度不能被接不接模型决定】
# 官方 883 个专业、这里 161 张牌，这句话在**两种情况下都要在**——
# 真正会拿给别人看的那台机器是接了 key 的。
chk("883" in _sbt2 and "161" in _sbt2,
    "没接模型时也说清覆盖率")
# 接上 key 之后必须换一句话，并且说清模型的边界
import os as _os3
_os3.environ["DEEPSEEK_API_KEY"] = "sk-test-key-for-sidebar-only"
try:
    _sbt3 = capture(_ns["sidebar"], _ns["new_state"]())
finally:
    del _os3.environ["DEEPSEEK_API_KEY"]
chk("模型层已开" in _sbt3, "接了 key 时说明模型层已开")
chk("来自库" in _sbt3, "接了 key 时说明事实一律来自库")
chk("拦下" in _sbt3 or "编" in _sbt3,
    "接了 key 时说明模型编的数字会被拦下")
chk("883" in _sbt3 and "161" in _sbt3,
    "接了 key 时**仍然**说清覆盖率（这句和模型无关）")
chk("API Key" not in _sbt3, "设了环境变量就不显示 key 输入框")

# ── 三段「有数据但界面从没读过」的字段，现在必须真的上卡 ──
# 【这一段的来历：我把「有数据」和「代码读过」做了差集】
# 差集里有三个字段既不是废数据、也不是量太少：
#     avoid 66/161（什么情况会让你想跑）
#     ir    94/161（不可替代四维）
#     tilt  94/161（AI 影响）
# 三个都有出处、都对准这个产品的立场，**却一个都没上过卡**。
# 我前两次是靠猜（猜 avoid 没过白名单、猜它被清洗坏），两次都猜错。
# 所以这一节的检查全部对着**差集脚本算出来的事实**写。
_APP = _ns["MAJORS"]
# 【循环变量绝不能叫 _f】
# 全局的 `_f` 是那个假 streamlit，`capture()` 就靠它的账本。
# 我第一版写成 `for _f, _label in (...)`，**直接把假对象覆盖成了字符串**，
# 于是下面第一个 capture 就报 'str' object has no attribute 'marked'。
# 这个报错看起来像代码 bug，其实是我起的变量名撞了。
# 教训：这个文件里 `_f` 是**保留名**。
for _fld, _label in (("avoid", "想跑的理由"), ("ir", "不可替代四维"),
                     ("tilt", "AI 影响")):
    _n = sum(1 for m in _APP if m.get(_fld) not in (None, "", [], {}))
    chk(_n > 0, f"库里 {_label}（{_fld}）有材料：{_n}/{len(_APP)}")
    L.append(f"    {_fld} 覆盖 {_n}/{len(_APP)}")

# 有数据的必须真渲染出来
_r1 = capture(_ns["avoid_block"], _ns["BY_NAME"]["建筑学"])
chk("什么情况会让你想跑" in _r1,
    "有 avoid 的专业，卡片上说得出「什么情况会让你想跑」")
for _lab in ("长时间无反馈", "体力消耗"):
    chk(_lab in _r1, f"avoid 的标签「{_lab}」出现在卡上")
chk("不是「这个专业不好」" in _r1,
    "avoid 那段说明了「这不是说专业不好」——防止被读成缺点清单")

_r2 = capture(_ns["ai_block"], _ns["BY_NAME"]["临床医学"])
chk("AI" in _r2, "有 ir/tilt 的专业，卡片上讲 AI 位置")
chk("/3" in _r2, "不可替代四维带分数")
chk("增强" in _r2 or "压缩" in _r2, "AI 影响说清了是增强还是压缩")

_r3 = capture(_ns["path_block"], _ns["BY_NAME"]["临床医学"])
chk("这个专业的路怎么走" in _r3, "有 path 的专业，卡片上讲路怎么走")
chk("规培" in _r3, "path 的阶段（规培）出现在卡上")
chk("执业医师资格证" in _r3, "path 要考的证出现在卡上")

# 【没数据时不许留空标题】
# 孤立标题是最难看的一种：只写「**往上走的路径**」下面什么都没有，
# 用户会以为数据加载失败了。
_EMPTY = {}
for _nm in ("逻辑学", "哲学"):
    _mm = _ns["BY_NAME"][_nm]
    for _fn, _title in (("avoid_block", "**什么情况会让你想跑**"),
                        ("path_block", "**这个专业的路怎么走**"),
                        ("ai_block", "**这个方向在 AI 面前是什么位置**")):
        _o = capture(_ns[_fn], _mm)
        if _title in _o and len(_o.replace(_title, "").strip()) < 8:
            _EMPTY.setdefault(_nm, []).append(_fn)
chk(not _EMPTY, f"没数据时不留空标题（问题：{_EMPTY}）")

# 【标题不许和职业块撞】
# `occupations_block` 里已经有一句「**往上走的路径**」（职业的晋升级梯）。
# 专业这一侧讲的是另一件事（读几年、要不要读研、考什么证）。
# 两处同名会让人以为是同一件事——我第一版就是这么撞上的。
chk("往上走的路径" not in _r3,
    "专业的路不和职业块的「往上走的路径」撞名")

# 【那批「有数据但代码从不读」不许再长回来】
# 这份名单是脚本算出来的（_audit_unused_fields.py），不是我写的。
# 剩下几个我都判断过为什么不上卡：
#   class_conf 内部标记 / risk 全库都是「中」没有区分度 /
#   cost_tier, dims_tier 是等级标记（已经写进说明文字）/
#   land 3 条 / cap, daily, bottleneck, ai_note, mean, manifest 各 6 条
#     ——这几个是手写的高质量画像，**故意不再推**，因为推就得伪造质感。
_KNOWN_UNUSED = {"class_conf", "risk", "cost_tier", "cap", "daily",
                 "bottleneck", "ai_note", "mean", "manifest", "land",
                 "dims_tier"}
_with_data = set()
for _m in _APP:
    for _k, _v in _m.items():
        if _v not in (None, "", [], {}):
            _with_data.add(_k)
_src_app = open(os.path.join(ROOT, "_专业游乐场.build-check.py"),
                encoding="utf-8").read()
_read = set(_re.findall(r"""\bm\[['"](\w+)['"]\]""", _src_app))
_read |= set(_re.findall(r"""\bm\.get\(['"](\w+)['"]""", _src_app))
_read |= set(_re.findall(r"""\bmaj\.get\(['"](\w+)['"]""", _src_app))
_new_unused = sorted((_with_data - _read) - _KNOWN_UNUSED)
chk(not _new_unused,
    f"没有新的「有数据但代码从不读」的字段（新出现的：{_new_unused}）")

L.append("")

# ── 新加的两块，出处不能少、也不能标错 ──
# 【为什么「标错」比「不标」更严重】
# 不标只是没给证据；标错是**给了一个假证据**。
# 那 6 个专业的 avoid 是**逐个访谈核实过**的（avoid_tier=C1），
# 其余 60 个是公开资料整理（C2）。如果区分字段到不了界面，
# 6 个会被一律标成「没有核实」——**把最强的证据说成最弱的。**
# 这条正是装配守卫抓出来的：我写完 `m.get("avoid_tier")`，
# 守卫立刻报「代码引用但白名单没放行」。
_src_bad = []
_src_n = 0
for _m in _ns["MAJORS"]:
    if _m.get("avoid"):
        _t = capture(_ns["sources_rows"], _m)
        _line = next((x for x in _t.split("\n")
                      if "什么情况会让你想跑" in x), "")
        if not _line:
            _src_bad.append((_m["n"], "没有出处行"))
        else:
            _said_c1 = "访谈核实" in _line
            _is_c1 = _m.get("avoid_tier") == "C1"
            if _said_c1 != _is_c1:
                _src_bad.append((_m["n"], f"说{_said_c1}实际{_is_c1}"))
            else:
                _src_n += 1
chk(not _src_bad,
    f"「想跑」那一块逐条有出处，且等级标对（问题：{_src_bad[:5]}）")
L.append(f"    「想跑」出处标注核对通过 {_src_n} 个")
_c1 = sum(1 for _m in _ns["MAJORS"]
          if _m.get("avoid") and _m.get("avoid_tier") == "C1")
chk(_c1 == 6, f"标「访谈核实」的正好 6 个（实际 {_c1}）")

# 有 ir/tilt 的也要有出处，而且必须写明「是评估不是实测」
_ai_bad = []
for _m in _ns["MAJORS"]:
    if _m.get("ir") or _m.get("tilt") is not None:
        _t = capture(_ns["sources_rows"], _m)
        if "AI 位置" not in _t:
            _ai_bad.append(_m["n"])
        elif "不是实测" not in _t and "不是量出来" not in _t:
            _ai_bad.append((_m["n"], "没写明是判断"))
chk(not _ai_bad, f"AI 位置也有出处、且写明是评估（问题：{_ai_bad[:5]}）")

# 【出处行不许把无说成有】
# 哲学没有 avoid，就不该出现「想跑」那一行——出现了就是在编出处。
_ph = capture(_ns["sources_rows"], _ns["BY_NAME"]["哲学"])
chk("什么情况会让你想跑" not in _ph,
    "没有 avoid 的专业，出处里也不出现这一行")

L.append("")

# ── 讲解词和主区不许错位（台上空指） ──
# 【这一类事故为什么必须交叉核对】
# 讲解词是给**台上的人**看的提示：「主区『X』那段，可以这么说」。
# 如果主区里根本没有 X，台上就会**对着空气指**：
# 投影上是别的东西，嘴里在讲这一段。
# 而这件事**不会有任何报错**——讲解词写得好好、数据也在，只是两边错位。
# 所以判据必须是「两边互相验」，不能是各自自查。
_bad_align = []
_bad_note = []
for _i in range(len(_ns["WALKTHROUGH"])):
    _st = _ns["new_state"]()
    _st["mode"] = "demo"
    _st["step"] = _i
    _m = _ns["BY_NAME"].get(_ns["WALKTHROUGH"][_i]["major"])
    _MAIN = capture(_ns["demo_step"], _st)
    _SIDE = capture(_ns["demo_presenter_panel"], _st)
    # 讲解词指到主区哪一段，那一段就得在主区里
    for _ref in _re.findall(r"主区「([^」]+)」那段", _SIDE):
        if _ref not in _MAIN:
            _bad_align.append((_i + 1, _ref))
    # 主区有「想跑」这一块，讲解词就必须提，否则台上不知道说什么
    if "什么情况会让你想跑" in _MAIN and "什么情况会让你想跑" not in _SIDE:
        _bad_note.append(_i + 1)
    # 反过来：讲解词说有，主区也得真的有
    if "什么情况会让你想跑" in _SIDE and "什么情况会让你想跑" not in _MAIN:
        _bad_align.append((_i + 1, "什么情况会让你想跑"))
    # 有 avoid 数据的步骤，必须配一段讲解词
    if _m is not None and _m.get("avoid") and not _ns["WALKTHROUGH"][_i].get(
            "avoid_note"):
        _bad_note.append(_i + 1)
chk(not _bad_align,
    f"讲解词指到的主区段落都真的在（缺：{_bad_align}）")
chk(not _bad_note,
    f"主区出现「想跑」的每一步都有讲解词（缺：{_bad_note}）")
chk(len(_ns["WALKTHROUGH"]) == 7,
    f"七步都在（实际 {len(_ns['WALKTHROUGH'])} 步）")
# 【第 7 步是唯一没有 avoid 数据的，两边都必须安静】
# 主区冒出一块、讲解词不提，或者讲解词提了、主区没有——都算错位。
_m7 = _ns["BY_NAME"].get(_ns["WALKTHROUGH"][6]["major"])
if _m7 is not None and not _m7.get("avoid"):
    _st7 = _ns["new_state"]()
    _st7["mode"] = "demo"
    _st7["step"] = 6
    _M7 = capture(_ns["demo_step"], _st7)
    _S7 = capture(_ns["demo_presenter_panel"], _st7)
    chk("什么情况会让你想跑" not in _M7,
        "没有 avoid 数据的那一步，主区不出现空白块")
    chk("什么情况会让你想跑" not in _S7,
        "没有 avoid 数据的那一步，讲解词也不提它")

L.append("")

# ── 讲解词不许进主区（投影时台下会看到小抄） ──
# 【为什么这条必须进测试】
# `demo_presenter_panel` 的注释写着「放侧栏，投影时观众看不到」。
# 它一旦进了主区，**内容上没有任何报错、没有任何异常**——
# 只是台下多看了几行「可以这么说」「然后指这一条」。
# 没有人会因此收到警报，所以只能靠测。
#
# 【但这条检查我第一版写错了，值得记下来】
# 我用 `AT.markdown` 当「主区」，判定「讲解词在主区」。
# 先做了个 5 行最小实验才明白：
#     AT.markdown         = 'MAIN_ONLY\nSIDEBAR_ONLY'
#     AT.sidebar.markdown = 'SIDEBAR_ONLY'
# **`AT.markdown` 把侧栏也算进来了。** 真主区得自己扣。
# 不做那个实验，我就会去改一段没坏的代码——那一轮我已经这么错过一次。
_at_b = mk_app(90)
_at_b.run()
for _r in _at_b.sidebar.radio:
    _o = [str(x) for x in _r.options]
    _h = [x for x in _o if "展示" in x]
    if _h:
        _r.set_value(_h[0])
        _at_b.run()
        break


def _vals_top(container, kind):
    _out = []
    for _e in getattr(container, kind, []) or []:
        try:
            if kind in ("button", "selectbox", "radio", "multiselect",
                        "text_area", "text_input", "checkbox"):
                _v = getattr(_e, "label", "")
                if _v:
                    _out.append(str(_v))
            else:
                _out.append(str(_e.value))
        except Exception:
            pass
    return _out


def split_main_side(kind):
    _top = _vals_top(_at_b, kind)
    _side = _vals_top(_at_b.sidebar, kind)
    _rest = list(_top)
    for _s in _side:
        if _s in _rest:
            _rest.remove(_s)
    return "\n".join(_rest), "\n".join(_side)


_main_parts, _side_parts = [], []
for _k in ("markdown", "caption", "info", "warning", "error", "success",
           "button", "selectbox", "radio", "multiselect", "text_area",
           "text_input", "checkbox"):
    _a, _b2 = split_main_side(_k)
    _main_parts.append(_a)
    _side_parts.append(_b2)
_MAIN = "\n".join(_main_parts)
_SIDE = "\n".join(_side_parts)

for _t in ("可以这么说：", "然后指这一条：",
           "侧栏只有你看得到。主区是给台下看的。"):
    chk(_t not in _MAIN, f"讲解词不进主区：「{_t[:14]}」")
    chk(_t in _SIDE, f"讲解词在侧栏里：「{_t[:14]}」")
for _t in ("学什么", "代价", "它通向哪", "第 1 / 7 张"):
    chk(_t in _MAIN, f"台下的主区里有「{_t}」")
_small = [w for w in ("可以这么说", "然后指", "记得说", "你该") if w in _MAIN]
chk(not _small, f"主区里没有小抄语气词（发现的：{_small}）")
L.append(f"    主区 {len(_MAIN)} 字　侧栏 {len(_SIDE)} 字")

# ── 展示模式七步必须都能走 ──
# 这是课堂真正会用的那条路。七步里任何一步崩了，台上就断在那儿。
_at_c = mk_app(90)
_at_c.run()
for _r in _at_c.sidebar.radio:
    _o = [str(x) for x in _r.options]
    _h = [x for x in _o if "展示" in x]
    if _h:
        _r.set_value(_h[0])
        _at_c.run()
        break
_steps = 0
for _ in range(12):
    _blob_c = "\n".join(
        [str(e.value) for e in _at_c.markdown]
        + [str(getattr(e, "label", "")) for e in _at_c.button])
    if f"第 {_steps + 1} / 7 张" in _blob_c:
        _steps += 1
    _moved = False
    for _bb in list(_at_c.button):
        if "下一张" in (getattr(_bb, "label", "") or ""):
            _bb.click()
            _at_c.run()
            _moved = True
            break
    if not _moved:
        break
chk(_steps == 7, f"展示模式七步都渲染出来（实际 {_steps} 步）")
chk(_at_c.exception == [] or not _at_c.exception,
    f"展示模式走完没有异常（{_at_c.exception}）")

L.append("")

# ── 查一个「还没做成牌」的专业 ──
# 【这是用户原话里的场景】「老师问『那你看看临床医学』」——
# 自由问答问到的专业，大概率不在这 161 张牌里（官方目录 883 个）。
# 原来只能说「不在库里」，等于把话堵死。
# 现在从官方目录里现查：门类·专业类·专业代码·官方满意度，四个可核字段。
#
# 【判据全部从数据生成，不手写】
# 这一节我手写期望错了两次：
#   · 以为「研究生方向：算法」该给建议（其实该说查不到）
#   · 以为「数据科学与大数据技术」不在库里（其实有卡）
# 两次都差点让我去改没坏的代码。所以下面逐个角色都用**真实数据**驱动。
_res = _ns["resolve_major"]
_CAT = _ns["CAT_MAJOR"]
_CLS = _ns["CAT_CLASS"]

# ① 官方目录 883 个，个个都要解析得出来（不能落到 none）
_fell = [nm for nm in _CAT if _res(nm)[0] not in ("card", "catalog")]
chk(not _fell, f"官方目录 {len(_CAT)} 个专业个个查得到（落空：{_fell[:5]}）")

# ② 库里每张牌都要认成 card（自己做的牌不能被自己判成「没有」）
_confused = [m["n"] for m in _ns["MAJORS"] if _res(m["n"])[0] != "card"]
chk(not _confused, f"{len(_ns['MAJORS'])} 张牌都认得出（认错：{_confused[:5]}）")

# ③ 93 个专业类名都要认成 class（带不带「类」都认）
_cbad = [c for c in _CLS if _res(c)[0] != "class"]
chk(not _cbad, f"{len(_CLS)} 个专业类名都认得出（认错：{_cbad[:5]}）")
_cbad2 = [c for c in list(_CLS)[:40] if _res(c + "类")[0] != "class"]
chk(not _cbad2, f"专业类名加「类」也认（认错：{_cbad2[:5]}）")

# ④ 打错字要给建议——**用真名字去掉一个字自动生成**
_typo_bad = []
for _nm in list(_CAT):
    if len(_nm) >= 5 and _nm not in _ns["BY_NAME"]:
        _k, _p = _res(_nm[:-1])
        if not (_k == "near" and _nm in _p):
            _typo_bad.append((_nm[:-1], _k))
    if len(_typo_bad) >= 3:
        break
chk(not _typo_bad, f"打错字会给建议（没给：{_typo_bad}）")

# ⑤ 【最容易犯的错：瞎写一个也给建议】
# 第一版就是这里错的：「完全不存在的东西」给出了「辐射防护与核安全」，
# 因为「东西」两个字撞上了。**给出看起来像猜的建议，
# 比直接说「查不到」糟糕得多。**
_junk = ["完全不存在的东西", "研究生方向：算法", "asdfghjkl",
         "？？？", "12345"]
_jbad = [(t, _res(t)[0]) for t in _junk if _res(t)[0] != "none"]
chk(not _jbad, f"瞎写的名字如实说查不到（乱给建议：{_jbad}）")
chk(_res("")[0] == "none" and _res("   ")[0] == "none",
    "空输入不当成专业名")

# ⑥ 专业类分支要报出「下面有几个专业」
_k, _p = _res("临床医学类")
chk(_k == "class" and _p[2] == 7,
    f"「临床医学类」报出 7 个专业（实际 {_p if _k == 'class' else _k}）")

# ⑦ catalog 分支的四个字段必须都来自官方目录，不许自己造
_k2, _p2 = _res("世界语")
chk(_k2 == "catalog", "「世界语」走官方目录分支")
if _k2 == "catalog":
    chk(_p2[0] == "文学", f"门类对（{_p2[0]}）")
    chk(_p2[1].endswith("类"), f"专业类对（{_p2[1]}）")
    chk(_p2[2] == "050241", f"专业代码对（{_p2[2]}）")
    chk(_p2[3] == "0.0", f"满意度原样带出、没有自己填数（{_p2[3]}）")

# ⑧ 界面四种分支都要渲染、不崩，而且不许少说「没有材料就不编」
for _q, _need in (("世界语", ("文学", "050241", "不编")),
                  ("临床医学", ("我有这张牌",)),
                  ("临床医学类", ("专业类",)),
                  ("计算机科学与技术x", ("你是不是想说",)),
                  ("完全不存在的东西", ("不等于它不存在",))):
    # 【_Fake 是这个测试文件自己的类，不在 _ns 里】
    # 我第一版写 `_ns["_Fake"]`，直接 KeyError。
    # 而且 `lookup_block` 要用到 `st.text_input`——
    # 装配后 mini 应用的 `st` 是 `_ns["st"]`，所以两边都要换成这个可控的假对象。
    class _Q(_Fake):
        def text_input(self, *a, **k):
            return _q

    _saved_st = _ns["st"]
    _saved_mod = sys.modules.get("streamlit")
    _qf = _Q()
    sys.modules["streamlit"] = _qf
    _ns["st"] = _qf
    try:
        _ns["lookup_block"]()
        _blob = "\n".join(_qf.marked) + "\n" + "\n".join(_qf.captions)
    except Exception as _e:
        _blob = f"__CRASH__{type(_e).__name__}: {_e}"
    finally:
        sys.modules["streamlit"] = _saved_mod
        _ns["st"] = _saved_st
    chk("__CRASH__" not in _blob, f"查「{_q}」界面不崩")
    if "__CRASH__" not in _blob:
        for _w in _need:
            chk(_w in _blob, f"查「{_q}」时说了「{_w}」")

L.append("")

# ── 它反过来问你（访谈层） ──
# 【这一层最容易出的错】
#   ① 把「没答」当成低分——那等于替用户判他的能力
#   ② 「落差」和「证据不足」混成一堆——两件事意思相反
#   ③ 七问和七维对不上——题面问的和它记的不是一件事
_ASK, _OPT = _ns["ASK"], _ns["OPTIONS"]
_IR = _ns["interview_result"]
_DN = _ns["DIM_NAMES"]

# ① 七问必须正好覆盖七维，不重不漏
_asked = [d for _, d in _ASK]
chk(sorted(_asked) == sorted(_DN),
    f"七问正好覆盖七维（问到的：{_asked}）")

# ② 每一维都要有「不知道」这条路
# 我第一版只有第一维有，于是「证据不足」那整条分支**用户永远走不到**，
# 从没被执行过——一条走不到的分支等于没写。
_no_none = [d for d in _DN
            if not any(o[0] is None for o in _OPT.get(d, []))]
chk(not _no_none, f"每一维都有「不知道」选项（缺：{_no_none}）")

# ③ 分数合法
_bad_sc = [(d, [o[0] for o in _OPT[d]]) for d in _DN
           if not all(o[0] is None or 1 <= o[0] <= 5 for o in _OPT[d])]
chk(not _bad_sc, f"每个选项的分数都在 1—5 或「不知道」（越界：{_bad_sc}）")

# ④ 【最要紧的一条】没答的项绝不能造成落差
_M = [m for m in _ns["MAJORS"] if m.get("dims")]
_r_none = _IR([None] * 7, _M)
chk(not _r_none["agree"] and not _r_none["gap"],
    f"七项全没答时不给任何结论（却给了 一致{len(_r_none['agree'])} "
    f"落差{len(_r_none['gap'])}）")
chk(len(_r_none["unknown"]) == len(_M),
    f"七项全没答时全部归入「证据不足」（{len(_r_none['unknown'])}/{len(_M)}）")
_r_1none = _IR([None] + [5] * 6, _M)
chk(not _r_1none["gap"],
    f"只一项没答、其余全 5 时没有落差（却有 {len(_r_1none['gap'])} 个）")

# ⑤ 三堆互斥、且加起来正好等于有画像的专业数
for _ans in ([5] * 7, [1] * 7, [5, None, 3, None, 5, 3, None],
             [4, 4, 4, 4, 4, 4, None]):
    _r = _IR(_ans, _M)
    _tot = (len(_r["agree"]) + len(_r["gap"]) + len(_r["unknown"]))
    if _tot != len(_M):
        chk(False, f"三堆之和 {_tot} ≠ 有画像的专业数 {len(_M)}"
                   f"（输入 {_ans}）")
        break
    _ids = [id(x[0]) for k in ("agree", "gap", "unknown") for x in _r[k]]
    if len(set(_ids)) != len(_ids):
        chk(False, f"有专业同时落在两堆里（输入 {_ans}）")
        break
else:
    chk(True, "三种答案下，三堆互斥且加起来正好是有画像的专业数")

# ⑥ 落差算法逐条手工核（抽 6 个专业）
_wrong = []
for _m in _M[:6]:
    _a = [3] * 7
    _r = _IR(_a, _M)
    _where = None
    for _k in ("gap", "unknown", "agree"):
        for _rec in _r[_k]:
            if _rec[0] is _m:
                _where = (_k, [g[0] for g in (_rec[2] or [])])
    _manual = [i for i in range(7) if _a[i] < _m["dims"][i]]
    if sorted(_manual) != sorted(_where[1] if _where else []):
        _wrong.append((_m["n"], _manual, _where))
chk(not _wrong, f"落差算法和手工核一致（不一致：{_wrong}）")

# ⑦ 问句和选项里不许出现结论性的话
_blob = "\n".join(q for q, _ in _ASK) + "\n" + "".join(
    o[2] for d in _OPT for o in _OPT[d])
_BAN = ("你适合", "推荐你", "最适合你", "你应该选", "你的匹配度")
_hit = [w for w in _BAN if w in _blob]
chk(not _hit, f"访谈里不出现结论性的话（出现了：{_hit}）")

# ⑧ 界面两条路径都要渲染
for _fn, _need in (("interview_turn", ("合法答案",)),
                   ("interview_page", ("不知道你喜欢什么", "没有校准"))):
    _st = dict(_ns["new_state"]())
    _st["iv_ans"] = [5, None, 3, None, 5, 3, None]
    _st["iv_asked"] = True
    _q = _Fake()
    _saved_mod = sys.modules.get("streamlit")
    _saved_st2 = _ns["st"]
    sys.modules["streamlit"] = _q
    _ns["st"] = _q
    try:
        _ns[_fn](_st)
        _blob2 = "\n".join(_q.marked + _q.captions + _q.err + _q.warn)
    except Exception as _e:
        _blob2 = f"__CRASH__{type(_e).__name__}: {_e}"
    finally:
        sys.modules["streamlit"] = _saved_mod
        _ns["st"] = _saved_st2
    chk("__CRASH__" not in _blob2,
        f"{_fn} 不崩（实际：{_blob2[:150] if '__CRASH__' in _blob2 else ''}）")
    if "__CRASH__" not in _blob2:
        for _w in _need:
            chk(_w in _blob2, f"{_fn} 里说了「{_w}」")

# ⑨ 没答过就不许进对照页（否则用户会看到一个基于空白的结果）
chk(_ns["new_state"]()["iv_asked"] is False,
    "新开局是「没答过」——对照页进不去")

L.append("")
L.append(f"结果：{sum(R)}/{len(R)} 项通过 " + ("✓" if all(R) else "✗"))
open("_majors_uitest.txt", "w", encoding="utf-8").write("\n".join(L))
