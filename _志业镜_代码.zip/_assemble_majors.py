# -*- coding: utf-8 -*-
"""校验 `_majors_src.py` 能拼成一个完整应用（**不再落盘成产品**）"""
import ast, io, json, os, re, sys

# 【根目录自己找，不写死】
# 见 `_root.py`：先看环境变量，再从本文件往上走，最后才用已知路径。
# 写死的后果不是报错，是**静默操作另一个目录**——
# 而在我自己的机器上，写死和不写死的行为完全一样，所以发现不了。
#
# 【为什么必须 `import os` 和 `import sys`，不能用 `import os as _os`】
# 替换出来的代码写的是 `os.path.join(ROOT, ...)`；
# 只导入 `os as _os` 的话，**运行时**才报 `NameError`。
# 这种错 `compile()` 查不出来——它不是语法错。
#
# 【为什么同时绑 `os`/`sys` 和 `_os`/`_sys` 两套名字】
# 替换出来的代码写 `os.path.join(ROOT, ...)`，需要真名 `os`；
# 而下面这段自己用 `_os`/`_sys` 更保险，不会跟本文件原有的
# `import sys` 之类打架。**两套都绑，谁都不会缺名字。**
# 我上一版只绑 `_os`/`_sys`，于是文件下面的 `sys.stdout = ...`
# 报 `NameError: name sys is not defined`——又是运行时才炸。
#
# 【为什么要往上走，不能只用本目录】
# `_审计/` 里的脚本 `dirname(__file__)` 是 `_审计/`，不是根。
# 所以把本目录和各级上层的目录**都**放进 sys.path，
# 直到 `_root` 真的能 import 为止。多放几条无害。
#
# 【为什么必须插在所有用到 ROOT 的地方之前】
# 有的脚本第 9 行就 `sys.path.insert(0, ROOT)`，
# 那时 import 还没结束；插在「最后一个 import 之后」就太晚了。
import os, sys
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.abspath(__file__))
for _ in range(4):
    if _d not in _sys.path:
        _sys.path.insert(0, _d)
    _up = _os.path.dirname(_d)
    if _up == _d:
        break
    _d = _up
from _root import find_root as _find_root
ROOT = _find_root()
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
def strip_module_docstring(s, name):
    """把文件级 docstring 改成注释。

    【为什么必须做】拼接进来之后，文件级 docstring 就是一条**裸表达式语句**，
    Streamlit 会把它当 st.write 渲染出来——用户会看到我的开发笔记。
    对话版那边已经踩过这个坑（而且我当时那条自检是假的，没抓到）。

    【为什么这个应用也需要 _mirror_core】
    卡片的「7 维需求」要用 DIM_NAMES 和 DIM_PLAIN 说人话。
    上一轮我给 dims_block 加了人话，却**忘了把镜像核心内联进来**，
    于是运行时 NameError。而且我没重跑这个测试，所以没发现。
    **两个应用应该共用同一份维度定义，不能各写一套。**
    """
    tree = ast.parse(s)
    if not tree.body:
        return s
    first = tree.body[0]
    if not (isinstance(first, ast.Expr)
            and isinstance(first.value, ast.Constant)
            and isinstance(first.value.value, str)):
        return s
    lines = s.split("\n")
    a, b = first.lineno - 1, first.end_lineno
    body = lines[a:b]
    if len(body) >= 2:
        body = body[1:-1]
    commented = ["# " + x if x.strip() else "#" for x in body]
    return "\n".join(
        lines[:a]
        + [f"# --- 以下原为 {name} 的文件级说明，改成注释以免被渲染 ---"]
        + commented + lines[b:])


src = strip_module_docstring(
    open(f"{ROOT}/_majors_src.py", encoding="utf-8").read(), "_majors_src")
data = json.load(open(f"{ROOT}/_majors_game.json", encoding="utf-8"))
mirror = strip_module_docstring(
    open(f"{ROOT}/_mirror_core.py", encoding="utf-8").read(), "_mirror_core")

# 皮肤：`_theme_core.py` 里一份结构 + 两套配色。牌局用 "ink"。
_theme_src = open(f"{ROOT}/_theme_core.py", encoding="utf-8").read()
_theme_ns = {}
exec(compile(_theme_src, "_theme_core.py", "exec"), _theme_ns)  # noqa: S102
theme_css = _theme_ns["css"]
# 【要断言的是「两套配色不一样」，不是「两次调用不一样」】
# 我第一版写的是 `theme_css("ink") != theme_css("rose")`——现在是了，
# 但这条断言本身写得很弱：真正要防的是「有人把某个主题的配色抄成另一套」。
assert theme_css("ink") != theme_css("rose"), "两套配色不该长得一样"
assert theme_css("ink") == theme_css("ink"), "同一个主题必须可重复"
# 职业那一侧也要进应用 —— 目标是「职业=出口」，出口不能只是名字
occ = json.load(open(f"{ROOT}/_occ_detail.json", encoding="utf-8"))
occ_blob = json.dumps(occ, ensure_ascii=False, separators=(",", ":"))
assert '"""' not in occ_blob, "职业数据里有三引号"

# 【第三类要有自己的名字，不能再当纯文本】
# `occ_no_id` 是学职平台**自己列了、但还没做详情页的 59 个职业**：
#   算法工程师、项目专员/助理（46 个专业通向它）、绘画（17 个）、
#   科研人员（15 个）……
# 它们和「有 id 的 97 个」在数据里是两张表，但出口名单里是同一种字符串。
# 原来的渲染遇到查不到的，就印一句「这个职业在学职平台上没有独立页」——
# **和「这职业不存在」看起来一模一样**，而且丢掉了最有用的那句：
# 「项目专员/助理」有 46 个专业通向它。
# 那是平台自己登记的数字，就在手边。
_occ_no_id = json.load(
    open(f"{ROOT}/_occ_index.json", encoding="utf-8")).get("occ_no_id") or {}
# 要两个方向：
#   职业名 → 多少个专业通向它（说给用户听：这是通用出口还是特征出口）
#   专业名 → 它通向哪些没详情页的职业（用来判断「你是其中之一」）
_nid_blob = json.dumps(_occ_no_id, ensure_ascii=False,
                       separators=(",", ":"))
assert '"""' not in _nid_blob, "无详情职业数据里有三引号"

# 清掉纯文本字段里的 markdown 标记（原文有加粗，直接显示会露出 **）
PURE = ("hook", "fun", "weary", "suits", "core_s", "car_s", "act_s",
        "dark", "val", "src")
n_clean = 0
for m in data["majors"]:
    for k in PURE:
        v = m.get(k)
        if isinstance(v, str) and "**" in v:
            m[k] = re.sub(r"\*\*", "", v)
            n_clean += 1
    for k in ("avoid", "core", "fit", "act", "car", "mis", "xfer", "cross"):
        if isinstance(m.get(k), list):
            m[k] = [re.sub(r"\*\*", "", x) if isinstance(x, str) else x
                    for x in m[k]]
    if isinstance(m.get("shrink"), dict):
        for k, v in list(m["shrink"].items()):
            if isinstance(v, str):
                m["shrink"][k] = re.sub(r"\*\*", "", v)

# 只保留界面需要的字段，减小体积。
# 【踩过的坑】第一版这里漏了 `gate_icon`，界面取它时报 KeyError。
# **把数据裁成白名单，就得保证白名单和界面用到的字段一一对上**——
# 裁剪是省体积，但它会静默丢掉界面依赖的字段。
KEEP = ("n", "gate", "gate_icon", "门类", "专业类", "学位", "years",
        "code", "in_official", "hook", "fun", "weary", "suits",
        # is_class_name：这条名字其实是「专业类」名，不是专业名。
        # 界面要据此说明，所以必须放行。
        "is_class_name",
        "core_s", "car_s", "act_s", "lvl", "src", "class_conf", "risk",
        # 【这两个是列表版，card 和 occupations_block 真要用的是它们】
        # core_s/car_s 只是渲染好的字符串。少了 core 和 car：
        #   · 16 个新专业的「出口」兜底永远走不到（库里明明有 car）
        #   · 课程对账（职业要求的课 vs 本专业的课）也永远算不出来
        # 我写了两段依赖它们的代码，字段却没过白名单——**代码看着对，跑起来是死的。**
        "core", "car",
        # 【act 和 学制 又漏了一次】
        # 模型层要拿这张牌的确切事实去生成 prompt（facts_of），
        # 里面引用了 act（动手试试的三条）和 学制（4 年 / 5 年）。
        # 库里 161/161 都有，白名单没有——**和 core/car 完全一样的坑，
        # 而且这次是守卫替我发现它的，不是我自己看出来的。**
        # 守卫值这个钱：它抓的是「代码写了但数据到不了」这类静默失效。
        "act", "学制",
        "rating", "rec_index", "enroll", "note845", "cls_desc",
        "chsi_sat", "chsi_xsgm", "chsi_jyfx", "chsi_kyfx",
        "chsi_ratio", "chsi_desc", "chsi_specid",
        # 志业镜的需求画像 —— **这是让每张卡手感不同的东西**，
        # 忘了加进白名单就等于把「好玩」裁掉了
        "dims", "dims_tier", "cost_hours", "cost_years",
        "cost_feedback_months", "cost_reversible", "cost_note",
        "cost_tier", "cost_templated", "ir", "tilt", "land", "avoid", "cap", "daily",
        "bottleneck", "ai_note", "mean", "manifest", "path",
        # 【avoid_tier：不给它放行，出处就会标错】
        # `sources_rows` 按它区分「访谈核实」和「公开资料整理·没有逐一核实」。
        # 字段到不了，那 6 个 **逐个访谈核实过** 的专业会被一律标成「没有核实」。
        # **把出处标错比不标更糟——不标只是没证据，标错是给了一个假证据。**
        # 这个字段是装配守卫抓出来的，不是我自己看出来的：
        # 我写完 `m.get("avoid_tier")` 就跑了装配，它直接报「静默失效」。
        "avoid_tier")
data["majors"] = [{k: m.get(k) for k in KEEP if k in m}
                  for m in data["majors"]]
_got = set(data["majors"][0].keys())
# 【判据要看全部专业，不能只看第 0 个】
# 有些字段是**部分专业才有**的（cost_templated 只有模板代价的那 88 个有）。
# 只看第 0 个会把这类字段误判成「没放行」，我的第一版就误报了 cost_templated。
_got_all = set()
for _m in data["majors"]:
    _got_all |= set(_m.keys())
_need = {"n", "gate", "gate_icon", "门类", "专业类", "学位", "years",
         "hook", "fun", "weary", "suits", "core_s", "car_s",
         # 这两个是列表版，occupations_block / card 真要用的是它们
         "core", "car"}
_missing = sorted(_need - _got)
print(f"  白名单缺字段：{_missing or '无 ✓'}")
assert not _missing, f"白名单缺字段，相关功能会静默失效：{_missing}"

# 【更强的检查：专业字段必须真的在数据里】
# 这一轮的教训是：occupations_block 里的兜底用了 car，card 里的课程对账
# 用了 core，两个字段都没过白名单——**代码看着对，跑起来那段是死的**，
# 而且不报错，只是默默不做那件事。
#
# 【这里只查专业字段，不查别的字典 —— 试过，查不了】
# 我加了「代码引用的顶层字段也要存在」，结果误报 23 条：
# 那些 `.get()` 是打在职业记录 r、讲解稿 step、满意度 sat 上的，
# 而它们来自另外两份数据，正则分不清接收者是哪个字典。
# **一个会误报的检查，会训练我去忽略它——那比没有检查更糟。**
# 所以范围缩到它能可靠判断的那一层：专业字段。
_prof_fields = set(re.findall(r"""\bm\.get\(['"](\w+)['"]\)""", src))
_prof_fields |= set(re.findall(r"""\bm\[['"](\w+)['"]\]""", src))
_hollow = sorted(f for f in _prof_fields if f not in _got_all)
print(f"  代码引用但专业数据里没有的字段：{_hollow or '无 ✓'}")
assert not _hollow, (
    f"这些字段被代码引用，但白名单没放行，相关功能会静默失效：{_hollow}")

blob = json.dumps(data, ensure_ascii=False, separators=(",", ":"))

# ── 官方目录全表（883 个专业） ──
# 【为什么要嵌这一份，明明已经有 161 个专业的卡了】
# 用户的原话是「老师问『那你看看临床医学』」那种场景——
# 而课堂自由问答问到的专业，**大概率不在这 161 个里**。
# 现在遇到这种情况只能说「不在库里」，等于把话堵死了。
#
# 【为什么不借机把 722 个专业也做成卡】
# 做卡需要课程、代价、画像、出口——那些材料我没有，
# 硬做就是编。所以这条路只答**官方目录里确定有的东西**：
# 门类、专业类、专业代码、官方满意度，**四个字段，全部可核**。
# 答不了的部分（学什么、贵不贵）就明说不做。
#
# 【体积】883 条 × 约 36 字符 ≈ 32KB，占现在文件的 5.5%。
# 重名 0 个（实测），所以可以用名字直接当键。
_tree = json.load(open(f"{ROOT}/_official_2026_tree.json", encoding="utf-8"))
_deg = data.get("deg_by_gate") or {}
_cat = {}
_cls_count = {}
for _gate, _gv in _tree.items():
    for _cls, _cv in (_gv.get("classes") or {}).items():
        _ms = _cv.get("majors") or []
        _cls_count[_cls] = len(_ms)
        for _mj in _ms:
            _cat[_mj["name"]] = [_gate, _cls, _mj.get("code") or "",
                                 _mj.get("zymyd") or ""]
# 专业类名也要能查（用户可能只说「临床医学类」）
_cat_cls = {_c: [_g, _cls_count.get(_c, 0)] for _c, _g in
            ((_cls, _gate) for _gate, _gv in _tree.items()
             for _cls in (_gv.get("classes") or {}))}
_cat_blob = json.dumps({"_major": _cat, "_class": _cat_cls},
                       ensure_ascii=False, separators=(",", ":"))
assert '"""' not in _cat_blob, "目录数据里有三引号"
assert len(_cat) == 883, f"目录只收到 {len(_cat)} 个专业，应该是 883"

out = src.replace("__MAJOR_DATA__", blob)
out = out.replace("__MIRROR_CODE__", mirror)
out = out.replace("__OCC_DATA__", occ_blob)
out = out.replace("__OCC_NODETAIL__", _nid_blob)
out = out.replace("__CATALOG__", _cat_blob)
# 【皮肤也是注入的，不是各写一份】
# 牌局和对话共用 `_theme_core.py` 里的同一份结构，
# 只换一组颜色值。各写一份的话，迟早一份改了一份没改——
# 这个仓库里因为「两份靠检查同步」栽过好几次。
out = out.replace("__THEME__", theme_css("ink"))
assert "__MAJOR_DATA__" not in out
assert "__MIRROR_CODE__" not in out
assert "__OCC_DATA__" not in out
assert "__OCC_NODETAIL__" not in out
assert "__CATALOG__" not in out
assert "__THEME__" not in out
assert "__C_" not in out, "配色占位符没替换干净"
ast.parse(out)
# 顶层不许有裸字符串，否则 Streamlit 会把开发笔记渲染给用户
_bare = [n.lineno for n in ast.parse(out).body
         if isinstance(n, ast.Expr) and isinstance(n.value, ast.Constant)
         and isinstance(n.value.value, str)]
assert not _bare, f"顶层有裸字符串，会被渲染出来：第 {_bare} 行"

# ==================================================================
# 【不再生成 专业游乐场.py —— 产品合并成一个应用了】
# ==================================================================
# 用户要的是一个应用：「对话为主，翻牌做进对话里」。
# 对话版（志业镜.py）现在通过共享的 `_cards_core.py` 就能翻牌了。
#
# **但源文件 `_majors_src.py` 必须留着**，因为两件事还靠它：
#   · 讲稿流水线 `_deck_facts.py` 和 `_deck_claim_check.py` 读它的内容
#   · 访谈工作台 `_iv_workbench.py` 和 `_test_majors.py` 的覆盖度断言引用它
# 所以这里改成**只做校验、不落盘**：拼一遍、断言干净，
# 然后告诉调用方「这个是源，不是要发布的应用」。
#
# 【为什么要保留这一步校验】
# `_majors_src.py` 还在被读，如果它悄悄坏掉（占位符没换、语法错），
# 讲稿和工作台会在更难查的地方炸。让它在这里炸。
open(f"{ROOT}/_专业游乐场.build-check.py", "wb").write(out.encode("utf-8"))

print("已校验 _majors_src.py 能拼成一个完整应用（**不再生成 专业游乐场.py**）")
print("  · 产品现在只有一个应用：志业镜.py")
print("  · 拼出来的这份只用于校验，落在 _专业游乐场.build-check.py")
print("  · 讲稿流水线改读 _majors_src.py 本身")
print(f"  行数   {out.count(chr(10)) + 1}")
print(f"  字节   {len(out.encode('utf-8'))}")
print(f"  专业   {len(data['majors'])} / 门类 {len(data['gates'])}")
print(f"  清理 markdown {n_clean} 处")
print(f"  BOM    {'有 ✗' if out.startswith(chr(0xFEFF)) else '无 ✓'}")

bad = [m["n"] for m in data["majors"]
       if not m.get("hook") or not m.get("fun") or not m.get("weary")]
print(f"  字段完整 {'✓' if not bad else '✗ ' + str(bad)}")
off = sum(1 for m in data["majors"] if m.get("in_official"))
print(f"  官方目录命中 {off}/{len(data['majors'])}")
stars = [m["n"] for m in data["majors"]
         if "**" in "".join(str(v) for v in m.values() if isinstance(v, str))]
print(f"  无 markdown 残留 {'✓' if not stars else '✗ ' + str(stars[:5])}")
