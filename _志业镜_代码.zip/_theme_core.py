# -*- coding: utf-8 -*-
"""两个应用共用的一套皮肤。**结构一份，配色两份。**

【为什么要做成「一份结构 + 两套配色」】
原来两个应用的样式是各写各的：牌局那一版**一行 CSS 都没有**
（用户看到的「朴素」是字面意义上的没有设计），
对话那一版只有几张卡片。两边各写一份，迟早一份改了一份没改——
这个仓库里已经因为「两份靠检查同步」栽过好几次
（出处行 161 个专业只对上 4 个那次）。

所以这里只放一份样式表，用 CSS 变量做配色。每个应用只声明
**自己那几个颜色值**，结构、圆角、间距、字体全部共用。

【两套配色的性格】
  牌局（ink）—— 墨色纸面 + 黄铜。像在桌上的旧卡片，翻牌这动作要有点手感。
  对话（rose）—— 温润的粉墨。像一个肯听你说话的人，不该有桌子的硬边。
两套都用低饱和的颜色和很轻的阴影：**这个产品的内容密度高，
背景一旦抢眼，四百个字的卡片就没法读了。**

【不做的事】
不写死字体文件、不引外链（离线也能跑，课上不会因为网断了变样）。
只调 streamlit 已有的元素和自定义的那几个 class。
"""
import json

# 【配色变量为什么分成两组】
#   --mirror 是「镜子」这一个品牌色，两套里都是它，只是色相不同
#   --good   是「对得上」的绿，两个应用语义相同，所以可以共用
STRUCTURE = """<style>
:root{
  --ink:__C_INK__; --muted:__C_MUTED__; --line:__C_LINE__;
  --paper:__C_PAPER__; --panel:__C_PANEL__;
  --mirror:__C_MIRROR__; --brass:__C_BRASS__; --good:#2f9e6b;
  --shadow:__C_SHADOW__;
  --serif:"Songti SC","STSong","Source Han Serif SC","Noto Serif CJK SC",
          "SimSun",Georgia,serif;
  --sans:-apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC",
         "Hiragino Sans GB","Microsoft YaHei","Noto Sans CJK SC",
         "Helvetica Neue",Arial,sans-serif;
}

/* -- 底：一层很轻的光，不是一块死色 ------------------------- */
.stApp{
  background:
    radial-gradient(1100px 620px at 12% -8%, var(--panel) 0%,
                    rgba(0,0,0,0) 62%),
    var(--paper);
}
.stApp, .stApp p, .stApp li, .stApp td, .stApp label{
  font-family:var(--sans);
  color:var(--ink);
  -webkit-font-smoothing:antialiased;
}

/* -- 标题走衬线，和正文分开。这是这套皮肤的「特色」所在 ------ */
.stApp h1, .stApp h2, .stApp h3{
  font-family:var(--serif);
  font-weight:600;
  letter-spacing:.01em;
  color:var(--ink);
}
.stApp h1{
  font-size:2.15rem;
  padding-bottom:.42rem;
  /* 标题下面那道渐变横线：从镜子色淡出，比一条实线轻 */
  border-bottom:1px solid var(--line);
  background-image:linear-gradient(90deg,
    var(--mirror) 0%, rgba(0,0,0,0) 68%);
  background-repeat:no-repeat;
  background-size:132px 2px;
  background-position:0 100%;
}
.stApp h3{font-size:1.16rem;}

/* -- 正文的行距和段距：读四百字的卡片，靠这个 -------------- */
.stApp p, .stApp li{line-height:1.78;}
.stApp .stMarkdown p{margin-bottom:.42rem;}

/* -- 引用块：这一版拿它装「这个专业自己的话」 ---------------- */
.stApp blockquote{
  border-left:3px solid var(--mirror);
  background:var(--panel);
  padding:.6rem .9rem;
  border-radius:0 8px 8px 0;
  margin:.5rem 0;
}

/* -- 控件：给它一点手感，别是浏览器默认的样子 --------------- */
.stApp .stButton>button, .stApp .stDownloadButton>button{
  border-radius:10px;
  border:1px solid var(--line);
  font-family:var(--sans);
  font-weight:500;
  transition:border-color .16s ease, box-shadow .16s ease,
             transform .12s ease;
}
.stApp .stButton>button:hover{
  border-color:var(--mirror);
  box-shadow:0 3px 12px var(--shadow);
  transform:translateY(-1px);
}
/* 主按钮：整页只有一两个，用黄铜色点出来 */
.stApp .stButton>button[kind="primary"]{
  border-color:var(--brass);
  color:var(--brass);
}

/* 选项：这是访谈那一页的主要交互，做成一排能点的卡片 */
.stApp [data-testid="stRadio"] label{
  border:1px solid var(--line);
  border-radius:9px;
  padding:.4rem .7rem;
  margin:.16rem 0;
  background:var(--panel);
  transition:border-color .16s ease, background .16s ease;
  width:100%;
}
.stApp [data-testid="stRadio"] label:hover{border-color:var(--mirror);}

.stApp [data-testid="stExpander"]{
  border:1px solid var(--line);
  border-radius:11px;
  background:var(--panel);
}

.stApp code{
  background:var(--panel);
  border:1px solid var(--line);
  border-radius:5px;
  padding:1px 5px;
  font-size:.86em;
}
.stApp hr{border-color:var(--line);opacity:.7;}

/* 提示条：颜色跟镜子色走，别用默认那几种高饱和 */
.stApp [data-testid="stAlert"]{
  border-radius:10px;
  border:1px solid var(--line);
  background:var(--panel);
}

/* -- 侧栏：比主区沉一点，像桌边那一叠底牌 ------------------- */
.stApp [data-testid="stSidebar"]{
  background:var(--panel);
  border-right:1px solid var(--line);
}
.stApp [data-testid="stSidebar"] .stMarkdown p{font-size:.9rem;}

/* -- 卡片（对话版用；牌局版用同一套变量，所以颜色自动一致） -- */
.mcard{
  border:1px solid var(--line);
  border-left:4px solid var(--mirror);
  border-radius:12px;
  padding:14px 16px;
  margin:10px 0;
  background:var(--panel);
  box-shadow:0 2px 10px var(--shadow);
}
.mt{font-family:var(--serif);font-size:1.3rem;font-weight:600;
    margin-bottom:2px;}
.ms{font-size:.78rem;color:var(--muted);margin-bottom:9px;}
.mh{font-size:1rem;font-weight:600;margin:8px 0 11px;padding-left:10px;
    border-left:3px solid var(--mirror);}
.mg{font-size:.9rem;margin:7px 0;line-height:1.6;}
.mk{font-size:.88rem;margin:9px 0;padding:9px 11px;line-height:1.72;
    background:rgba(128,128,128,.07);border-radius:8px;}
.ma{font-size:.9rem;margin:10px 0 4px;padding:9px 11px;font-weight:600;
    background:rgba(47,158,107,.13);border-radius:8px;}
.dim{color:var(--muted);font-size:.83rem;}
.muted{color:var(--muted);}
.rule{height:1px;background:var(--line);margin:.9rem 0;}
</style>"""


def css(theme="ink"):
    """按主题返回一段**可直接嵌进源码的 Python 字符串字面量**。

    返回的是 `'<style>...'` 这种**带引号的一整块**，不是裸 CSS。
    【为什么带引号，这个坑我踩了两次】
    组装器用的是逐字符 `replace("__THEME__", css(...))`：
      1. 源码里写 `st.markdown(__THEME__, ...)` → 换进去的是裸 CSS，
         而 **CSS 不是合法 Python** → 拼出来第 2782 行
         `invalid character '：'`。
      2. 改成源码写 `st.markdown(\"\"\"__THEME__\"\"\", ...)` → 那一行里含
         **两处** `__THEME__`，CSS 被塞进两遍，中间那些引号把字符串切断，
         报的还是同一个错。**同一个错报两次，因为我一直在治症状。**
    正解：让占位符**自己就是一个完整字面量**，源码里光写 `__THEME__`。

    【两个主题的颜色都是挑过的，不是随手取的】
    都是低饱和 + 暖灰系，因为它们要和大量正文共存。
    【这几个数字是算出来的，不是写上去的】
    我第一版在注释里写了「对比度都过 4.5:1」，一量发现**两套都不够**
    （牌局的次要文字 4.20、对话 3.97，对话在面板上只有 3.73）。
    **注释里的承诺和代码里的颜色不是一回事。** 现在：
      正文 / 底        牌局 14.14　对话 14.45（AAA 要求 7）
      次要 / 底        牌局  4.79　对话  4.91（AA 要求 4.5）
      次要 / 面板       牌局  4.58　对话  4.61（面板更亮，是最坏情况）
    次要文字取的是**刚好过标的最浅那一档**（`#63717f` / `#766b79`），
    再浅一档就掉到 4.2 / 4.4。闸门 `_check_theme.py` 每次都验这六个数。
    """
    P = {
        # 牌局：墨色纸面 + 黄铜。像桌上的旧卡片。
        "ink": dict(
            ink="#1f2933", muted="#63717f", line="#dde2e8",
            paper="#fbfaf7", panel="#f3f5f8",
            mirror="#3f6a9c", brass="#b8863b",
            shadow="rgba(31,41,51,.07)",
        ),
        # 对话：温润的粉墨。像一个肯听你说话的人。
        "rose": dict(
            ink="#2b2530", muted="#766b79", line="#ece4ea",
            paper="#fdfbfc", panel="#f8f3f6",
            mirror="#8a6a9c", brass="#c08a6a",
            shadow="rgba(43,37,48,.07)",
        ),
    }[theme]
    out = STRUCTURE
    for k, v in P.items():
        out = out.replace(f"__C_{k.upper()}__", v)
    # 【占位符必须全部被替换掉】漏一个就会在页面上出现 `__C_XXX__`，
    # 而且它长得像正常文本，肉眼很难发现。所以这里直接断言。
    assert "__C_" not in out, f"{theme} 还有没替换的配色占位符"
    # 【用 json.dumps 生成字面量，而不是自己拼引号】
    # CSS 里可能有引号、反斜杠；`json.dumps` 会正确转义，
    # 而且产出的就是一个合法的 Python 字符串表达式。
    return json.dumps(out, ensure_ascii=False)
