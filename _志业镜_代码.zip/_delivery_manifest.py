# -*- coding: utf-8 -*-
"""要交付的那些文件。**打包器和 `_check_delivery.py` 共用这一份清单**——
两份清单就会漂移，而漂移的表现是「闸门说齐了、包里其实没有」。
"""

# ── 跑起来 + 要改的（全部平铺在包根，和开发目录同构）────────
PRODUCT = [
    "志业镜.py",              # 唯一应用（拼装产物）
    "_serve.py",              # 起服务，端口 8503
    "README.md",
]

SOURCES = [
    "_agent2_src.py",         # 对话版外壳：开场白、后置守卫、撞墙补料
    "_majors_src.py",         # 牌局与卡片源
    "_prompt_core.py",        # 系统提示词全文
    "_cards_core.py",         # 卡片渲染（两版共用）
    "_interview_core.py",     # 访谈界面（共用）
    "_mirror_core.py",        # 需求画像、七维、题目、打分
    "_tools_core.py",         # 17 个工具 + 唯一的打分路径
    "_theme_core.py",         # 主题与配色
    "_assemble_agent2.py",    # 拼装器：源 → 志业镜.py
    "_assemble_majors.py",    # 拼装器（牌局那份，闸门要用）
    "_majors_src_loader.py",  # 加载器（闸门与测试共用）
    "_root.py",               # 行定位模块：不依赖被放在哪儿
    "_find_python.py",        # 找出装了 streamlit / pptx 的解释器
    "_mark_dir.py",           # 开场记号文件在哪儿（唯一一处定义）
    "_delivery_manifest.py",  # 交付清单（闸门要读它）
    "_iv_workbench.py",       # 访谈素材工作台（闸门要用）
    # 【生成数据的那些也带上】
    # 不带的话，用户拿到手就**没法重新生成数据**，只能吃我这一份——
    # 而这一份是有缺口的（67/161 没有画像）。留着他就能自己补。
    "_build_major_game.py",
    "_build_game_data.py",
    "_sync2026.py",
]

DATA = [
    "_majors_game.json",      # 161 张专业卡
    "_majors.json",           # 卡片底表
    "_occ_detail.json",       # 职业详情
    "_occ_index.json",        # 职业索引
    "_official_2026_tree.json",   # 教育部 2026 官方目录
    "_careers_game.json",
    "_feed_ratings.json",
    # 【这两个是查出来的，不是我记起来的】
    # 我上一版凭记忆列清单，漏了它们，表现是「解到别处 16 个闸门不过」，
    # 而缺的文件名字根本不在报错里——只在某个闸门的间接依赖里。
    "_chsi_detail.json",
    "_major_interviews.json",
    "_子智能体学习库.json",
]

TESTS = [
    "_test_agent2.py",
    "_test_tools.py",
    "_test_mirror.py",
    "_test_majors.py",        # 最大的一套（400+ 项）
]

# 【这个看着像产品，其实不是——但必须带】
# 它是 `_assemble_majors.py` 拼出来的**校验产物**（1.3 MB）。
# 闸门靠 `_majors_src_loader` 读它来测数据；不带的话，
# 每个闸门第一次跑都得先现场拼一遍，又慢又容易在缺文件时误报。
PREBUILT = ["_专业游乐场.build-check.py"]

# 闸门和少数测试住在 `_审计/` 里
GATE_DIR = "_审计"
TESTS_IN_GATE_DIR = ["_test_cards_core.py", "_cards_core_data.py"]

# 【早期原型，但闸门要拿它做对照】
# `_check_name_clash.py` 查的是「两个应用里有没有同名常量」——
# 少了它就查不出东西。所以它是**测试素材**，不是产品。
FIXTURES = ["职业游乐场.py"]
